import os
data = os.listdir(u"D:/user")

print(data)
