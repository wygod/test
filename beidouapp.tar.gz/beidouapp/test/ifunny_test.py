# -*-coding:utf-8-*-

from __future__ import absolute_import
# import multiprocessing
# from multiprocessing.pool import ThreadPool

from beidousynthesize.ifunny import *
from beidoudistribution.celery import app

from beidouloginstance.loginstance import BeibouLog
from beidoudatastore.appredisdatastore import RedisObject

from beidouconf.baseconf.beidouredisconf import ifunny_spider_host, ifunny_spider_port, \
    ifunny_spider_password, ifunny_push_host, ifunny_push_port, ifunny_push_password

log_instance = BeibouLog()

# thread_pool = ThreadPool(multiprocessing.cpu_count())

push_obj = RedisObject(host=ifunny_push_host, port=ifunny_push_port, password=ifunny_push_password)

redis_obj = RedisObject(host=ifunny_spider_host, port=ifunny_spider_port, password=ifunny_spider_password)


def ifunny_init_app(user_agent,authorization):
    log = log_instance.beidou_create_log("ifunny_init_app")

    ifunny_spider = IfunnyInitSpider(redis_obj=redis_obj,
                                     log=log, authorization=authorization,
                                     user_agent=user_agent)

    ifunny_spider.ifunny_init_spider()


def ifunny_spider_user(account, user_agent,authorization):
    log = log_instance.beidou_create_log("ifunny_spider_user")

    ifunny_spider = IfunnyInitSpider(redis_obj=redis_obj,
                                     log=log,
                                     user_agent=user_agent,
                                     authorization=authorization)

    ifunny_spider.ifunny_init_user_spider(account=account)

def ifunny_business_friend(account,
                           password,
                           user_agent,
                           authorization):
    log = log_instance.beidou_create_log("ifunny_spider_friend")
    ifunny_friend = IfunnyBusinessFriend(log=log,
                                         redis_obj=redis_obj,
                                         authorization=authorization,
                                         user_agent=user_agent)

    ifunny_friend.ifunny_add_friend(account=account, password=password)

def ifunny_business_push(account,
                         password,
                         user_agent,
                         authorization):
    log = log_instance.beidou_create_log("ifunny_spider_push")

    account_login = redis_obj.redis_client(account_login_db)

    ifunny_login = LoginInfo(log)

    if not account_login.get(account + ":login_info"):
        ifunny_login.ifunny_login(account=account,
                                  password=password,
                                  authorization=authorization,
                                  user_agent=user_agent,
                                  redis_num=account_login)

        account_login.set(account + ":login_info", "1")

        account_login.expire(account + ":login_info", 24 * 60 * 60)

    ifunny_push = IfunnyPush(authorization=authorization,
                             log=log,
                             user_agent=user_agent,
                             redis_obj=redis_obj,push_obj=push_obj)

    ifunny_push.ifunny_add_push(account=account, login_func=ifunny_login, bother="all")


if __name__ == "__main__":

    from beidouconf.beidoudeviceconf.deviceconf import ifunny_device_match

    from beidouconf.baseconf.beidouredisconf import ifunny_spider_host, ifunny_spider_port, ifunny_spider_password

    redis_obj = RedisObject(host=ifunny_spider_host, port=ifunny_spider_port, password=ifunny_spider_password)

    account_lock = BeiDouBase(redis_obj)

    account_lock.base_process_lock(["2667946747@qq.com"])

    # base_authorization, user_agent = random.choice(ifunny_device_match)
    #
    # ifunny_init_app(user_agent,authorization=base_authorization)

    # redis_obj = RedisObject(host=ifunny_spider_host, port=ifunny_spider_port, password=ifunny_spider_password)
    #
    # ifunny_conn = RedisObject(host=ifunny_spider_host, port=ifunny_spider_port, password=ifunny_spider_password)
    #
    # ifunny_list = ifunny_conn.redis_client(uuid_db)
    #
    # keys_list = ifunny_list.smembers("uuidcontrol")
    #
    # for uuid in keys_list:
    #     base_authorization, user_agent = random.choice(ifunny_device_match)
    #
    #     ifunny_spider_user(uuid.decode("utf-8"), user_agent, base_authorization)
    # -*-coding:utf-8-*-

    # from beidouconf.beidouaccount.accountpassword import ifunny_account_add_list
    #
    # for account_password in ifunny_account_add_list:
    #     account, password = account_password
    #
    #     base_authorization, user_agent = random.choice(ifunny_device_match)
    #
    #     ifunny_business_friend(account, password,user_agent, base_authorization)

    # for account_password in [("2667946747@qq.com","sunking,09")]:
    #     account, password = account_password
    #
    #     basic, user_agent = random.choice(ifunny_device_match)
    #
    #     ifunny_business_push(account, password, user_agent, basic)
