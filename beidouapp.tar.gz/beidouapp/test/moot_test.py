# -*-coding:utf-8-*-

from __future__ import absolute_import

import os
# import multiprocessing
# from multiprocessing.pool import ThreadPool
import sys
sys.path.append("/home/server/beidouapp")
from beidoudatastore.appredisdatastore import RedisObject
from beidouloginstance.loginstance import BeibouLog
from beidousynthesize.moot import *
from beidoulogin.login import LoginInfo
from beidoudistribution.celery import app
from beidouotherscript.moot_script import MootOtherJavaScript
from beidouconf.baseconf.beidouredisconf import moot_push_host, moot_push_port, moot_push_password, moot_spider_host, \
    moot_spider_port, moot_spider_password

from beidouconf.baseconf.beidouredisdb import push_moot_user_db, push_moot_uuid_db,uuid_assigned_db

log_instance = BeibouLog()

push_obj = RedisObject(host=moot_push_host, port=moot_push_port, password=moot_push_password)

redis_obj = RedisObject(host=moot_spider_host, port=moot_spider_port, password=moot_spider_password)

app_token_signature = MootOtherJavaScript()


def moot_init_app(user_agent, device_id, game):
    log = log_instance.beidou_create_log("moot_init")

    moot_spider = MootRunSpider(redis_obj=redis_obj,
                                log=log,
                                user_agent=user_agent,
                                device_id=device_id,
                                app_token_signature=app_token_signature,
                                app_name="moot_init")

    moot_spider.moot_init_spider(game=game)


def moot_spider_user(user_agent, device_id, uuid, use_uuid):
    log = log_instance.beidou_create_log("moot_user")

    moot_spider = MootRunSpider(
        redis_obj=redis_obj,
        log=log,
        user_agent=user_agent,
        device_id=device_id,
        app_token_signature=app_token_signature,
        app_name="moot_user")

    moot_spider.moot_get_user(account=uuid, use_uuid=use_uuid)


def moot_business_friend(account,
                         password,
                         user_agent,
                         device_id):
    log = log_instance.beidou_create_log("moot_friend")

    app_data = LoginInfo(log)

    base_header = {
        "deviceId": device_id,
        "DEVICE-TIME-ZONE-ID": "Asia/Shanghai",
        "country": "CN",
        "User-agent": user_agent,
        "version": "20140411",
        "DEVICE-TIME-ZONE-MS-OFFSET": "28800000",
        "language": "zh_CN",
        "Accept-Encoding": "gzip",
        "Host": "usw-api.moot.us",
        "Connection": "Keep-Alive"
    }

    user_no, tokens, data_login = app_data.moot_login(account=account,
                                                      password=password,
                                                      device_id=device_id,
                                                      user_agent=user_agent,
                                                      app_token_signature=app_token_signature)

    moot_friend = MootRunFriend(log=log,
                                redis_obj=redis_obj,
                                user_agent=user_agent,
                                app_name="moot_business",
                                app_token_signature=app_token_signature,
                                device_id=device_id)

    moot_friend.moot_add_friend(account=account,
                                account_user_no=user_no,
                                tokens=tokens,
                                base_header=base_header)


def moot_business_push(account,
                       password,
                       device_id,
                       user_agent):
    log = log_instance.beidou_create_log("moot_push")

    base_header = {
        "deviceId": device_id,
        "DEVICE-TIME-ZONE-ID": "Asia/Shanghai",
        "country": "CN",
        "User-agent": user_agent,
        "version": "20140411",
        "DEVICE-TIME-ZONE-MS-OFFSET": "28800000",
        "language": "zh_CN",
        "Accept-Encoding": "gzip",
        "Host": "usw-api.moot.us",
        "Connection": "Keep-Alive"
    }

    moot_push = MootRunPush(app_name="moot_push",
                            redis_obj=redis_obj,
                            log=log,
                            user_agent=user_agent,
                            device_id=device_id,
                            app_token_signature=app_token_signature)

    app_data = LoginInfo(log)

    user_no, tokens, data_login = app_data.moot_login(account=account,
                                                      password=password,
                                                      device_id=device_id,
                                                      user_agent=user_agent,
                                                      app_token_signature=app_token_signature)

    push_account_filter = push_obj.redis_client(push_moot_user_db)

    push_uuid_filter = push_obj.redis_client(push_moot_uuid_db)

    accunt_uuid = redis_obj.redis_client(uuid_assigned_db)

    moot_push.moot_push(account=account,
                        account_user_no=user_no,
                        tokens=tokens,
                        push_account_filter=push_account_filter,
                        push_uuid_filter=push_uuid_filter,
                        is_use_account=True,
                        source_redis=accunt_uuid,
                        base_header = base_header
                        )


if __name__ == "__main__":

    # -*-coding:utf-8-*- ok
    # import random

    # from beidoudistribution import mootcelery
    # from beidouconf.beidoudeviceconf.deviceconf import moot_machine_match
    # from beidouallocation.beidouallocation import BeiDouBase
    # from beidouconf.beidouaccount.accountpassword import ifunny_account_add_list
    #
    # from beidouconf.baseconf.beidouredisconf import moot_spider_host, moot_spider_port, moot_spider_password
    #
    # redis_obj = RedisObject(host=moot_spider_host, port=moot_spider_port, password=moot_spider_password)
    #
    # account_lock = BeiDouBase(redis_obj)
    #
    # account_lock.base_process_lock(["2667946747@qq.com"])
    #
    # for account_password in ifunny_account_add_list:
    #     account, password = account_password
    #
    #     device_id, user_agent = random.choice(moot_machine_match)
    #
    #     moot_business_friend(account,
    #                             password,
    #                             user_agent,
    #                             device_id)

        # mootcelery.moot_business_friend(args=[account,
        #                                                   password,
        #                                                   user_agent,
        #                                                   device_id],
        #                                             queue="moot_friend", routing_key="moot_friend")



    # # # -*-coding:utf-8-*-
    # import random ok
    # # import multiprocessing
    # # from multiprocessing.pool import ThreadPool
    # #
    # # from beidoudistribution import mootcelery
    # # from beidouspider.mootspider import MootSpider
    # # from beidouloginstance.loginstance import BeibouLog
    # # from beidoudatastore.appredisdatastore import RedisObject
    # from beidouconf.baseconf.beidouredisdb import account_login_db
    # # from beidouotherscript.moot_script import MootOtherJavaScript
    # from beidouconf.beidoudeviceconf.deviceconf import moot_machine_match
    # from beidouconf.baseconf.beidouredisconf import moot_spider_host, moot_spider_port, moot_spider_password
    #
    # log_instance = BeibouLog()
    # #
    # # thread_pool = ThreadPool(multiprocessing.cpu_count())
    #
    # # app_token_signature = MootOtherJavaScript()
    #
    # moot_conn = RedisObject(host=moot_spider_host, port=moot_spider_port, password=moot_spider_password)
    #
    # moot_list = moot_conn.redis_client(account_login_db)
    #
    # device_id, user_agent = random.choice(moot_machine_match)
    #
    # log = log_instance.beidou_create_log("moot_spider_game")
    #
    # moot_init = MootSpider(app_token_signature=app_token_signature,
    #                        device_id=device_id,
    #                        log=log,
    #                        redis_obj=moot_conn,
    #                        user_agent=user_agent)
    #
    # if b"init_moot_game" not in moot_list.keys():
    #     moot_init.moot_spider_game(moot_list, "init_moot_game")
    #
    # game_id_list = moot_list.hgetall("init_moot_game")
    #
    # for keys, value in game_id_list.items():
    #     moot_init_app(user_agent, device_id, keys.decode("UTF-8"))
    #     # mootcelery.moot_init_app.apply_async(args=[user_agent, device_id, keys],
    #     #                                      queue="moot_init_app", routing_key="moot_init_app")
    #

    # -*-coding:utf-8-*-
    import random

    from beidoudistribution import mootcelery

    from beidouconf.beidoudeviceconf.deviceconf import moot_machine_match
    from beidouconf.beidouaccount.accountpassword import ifunny_account_add_list

    for account_password in ifunny_account_add_list:
        account, password = account_password

        device_id, user_agent = random.choice(moot_machine_match)

        moot_business_push(account,
                                                        password,
                                                        device_id,
                                                        user_agent)
        #
        # mootcelery.moot_business_push.apply_async(args=[account,
        #                                                 password,
        #                                                 device_id,
        #                                                 user_agent],
        #                                           queue="moot_push", routing_key="moot_push")

    # -*-coding:utf-8-*- ok
    # import random
    #
    # from beidoudistribution import mootcelery
    # from beidouconf.baseconf.beidouredisdb import uuid_db
    # from beidoudatastore.appredisdatastore import RedisObject
    #
    # from beidouconf.beidoudeviceconf.deviceconf import moot_machine_match
    # from beidouconf.baseconf.beidouredisconf import moot_spider_host, moot_spider_port, moot_spider_password
    #
    # moot_conn = RedisObject(host=moot_spider_host, port=moot_spider_port, password=moot_spider_password)
    #
    # moot_list = moot_conn.redis_client(uuid_db)
    #
    # keys_list = moot_list.smembers("uuidcontrol")
    #
    # for uuid in keys_list:
    #     device_id, user_agent = random.choice(moot_machine_match)
    #
    #     moot_spider_user(user_agent, device_id, uuid, True)
    #
    #     # mootcelery.moot_spider_user.apply_async(args=[user_agent, device_id, uuid, True],
    #     #                                         queue="moot_spider", routing_key="moot_spider")
