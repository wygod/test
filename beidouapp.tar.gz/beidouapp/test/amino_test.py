# -*-coding:utf-8-*-

from __future__ import absolute_import

from beidousynthesize.amino import *

log_instance = BeibouLog()

push_obj = RedisObject(host=amino_push_host, port=amino_push_port, password=amino_push_password)

redis_obj = RedisObject(host=amino_spider_host, port=amino_spider_port, password=amino_spider_password)


def amino_spider_user(ndcdeviceid,
                      smdeviceid,
                      user_agent):
    log = log_instance.beidou_create_log("amino_spider_user")

    amino_spider = AminoSpider(ndcdeviceid=ndcdeviceid,
                               smdeviceid=smdeviceid,
                               log=log,
                               user_agent=user_agent)

    amino_business = AminoBusiness(ndcdeviceid=ndcdeviceid,
                                   smdeviceid=smdeviceid,
                                   log=log,
                                   user_agent=user_agent)

    amino_spider_info = AminoSpiderInfo(amino_spider=amino_spider,
                                        amino_business=amino_business,
                                        amino_ndc=ndcdeviceid,
                                        amino_sm=smdeviceid,
                                        amino_user_agent=user_agent,
                                        log=log,
                                        redis_obj=redis_obj)

    amino_spider_info.run_init()


def amino_business_friend(account,
                          password,
                          ndcdeviceid,
                          smdeviceid,
                          user_agent):
    log = log_instance.beidou_create_log("amino_friend")

    amino_friend = AminoBusinessFriend(log=log, redis_obj=redis_obj)

    amino_business_down = AminoBusiness(log=log,
                                        ndcdeviceid=ndcdeviceid,
                                        smdeviceid=smdeviceid,
                                        user_agent=user_agent)

    amino_friend.amino_friend(account=account,
                              password=password,
                              amino_ndc=ndcdeviceid,
                              amino_smd=smdeviceid,
                              user_agent=user_agent,
                              amino_business_down=amino_business_down)


def amino_business_push(account,
                        password,
                        ndcdeviceid,
                        smdeviceid,
                        user_agent):
    log = log_instance.beidou_create_log("amino_spider_push")

    amino_spider = AminoSpider(ndcdeviceid=ndcdeviceid,
                               smdeviceid=smdeviceid,
                               log=log,
                               user_agent=user_agent)

    amino_business = AminoBusiness(ndcdeviceid=ndcdeviceid,
                                   smdeviceid=smdeviceid,
                                   log=log,
                                   user_agent=user_agent)

    amino_push = AminoPush(amino_spider=amino_spider,
                           amino_business=amino_business,
                           amino_ndc=ndcdeviceid,
                           amino_sm=smdeviceid,
                           amino_user_agent=user_agent,
                           log=log,
                           redis_obj=redis_obj,
                           push=push_obj)

    amino_push.amino_push_run(account=account, password=password)


if __name__ == "__main__":

    # -*-coding:utf-8-*-
    import time
    import random
    from beidoudistribution import aminocelery
    from beidouconf.beidouaccount.accountpassword import amino_account_push_list
    from beidouconf.beidoudeviceconf.deviceconf import amino_ndcdeviceid_and_smdeviceid

    for account_password in amino_account_push_list:
        account, password = account_password

        ndcdeviceid, smdeviceid, user_agent = random.choice(amino_ndcdeviceid_and_smdeviceid)
        amino_business_push(account, password, ndcdeviceid,smdeviceid, user_agent)

        # aminocelery.amino_business_push.apply_async(args=[account, password, ndcdeviceid,
        #                                                   smdeviceid, user_agent],
        #                                             queue="amino_push", routing_key="amino_push")

    # -*-coding:utf-8-*- ok
    # import random
    #
    # from beidoudatastore.appredisdatastore import RedisObject
    # from beidoudistribution import aminocelery
    #
    # from beidouallocation.beidouallocation import BeiDouBase
    # from beidouconf.beidouaccount.accountpassword import amino_account_add_list, amino_account_list
    # from beidouconf.beidoudeviceconf.deviceconf import amino_ndcdeviceid_and_smdeviceid
    # from beidouconf.baseconf.beidouredisconf import ifunny_spider_host, ifunny_spider_port, ifunny_spider_password
    #
    # redis_obj = RedisObject(host=ifunny_spider_host, port=ifunny_spider_port, password=ifunny_spider_password)
    #
    # account_lock = BeiDouBase(redis_obj)
    #
    # account_lock.base_process_lock(["2667946747@qq.com"])
    #
    # for account_password in [("2667946747@qq.com","sunking09")]:
    #     account, password = account_password
    #
    #     ndcdeviceid, smdeviceid, user_agent = random.choice(amino_ndcdeviceid_and_smdeviceid)
    #     amino_business_friend(account,
    #                           password,
    #                           ndcdeviceid,
    #                           smdeviceid,
    #                           user_agent)

        # aminocelery.amino_business_friend.apply_async(args=[account,
        #                                                     password,
        #                                                     ndcdeviceid,
        #                                                     smdeviceid,
        #                                                     user_agent],
        #                                               queue="amino_friend", routing_key="amino_friend")

    # # -*-coding:utf-8-*-ok
    # import random
    #
    # from beidoudistribution import aminocelery
    #
    # from beidouconf.beidoudeviceconf.deviceconf import amino_ndcdeviceid_and_smdeviceid
    # from beidouconf.beidouaccount.accountpassword import amino_account_push_list
    #
    # for account_password in amino_account_push_list:
    #
    #     account, password = account_password
    #
    #     ndcdeviceid, smdeviceid, user_agent = random.choice(amino_ndcdeviceid_and_smdeviceid)
    #
    #     amino_spider_user(ndcdeviceid, smdeviceid, user_agent)
    #     #
    #     # aminocelery.amino_spider_user.apply_async(args=[ndcdeviceid, smdeviceid, user_agent],
    #     #                                           queue="amino_spider", routing_key="amino_spider")
