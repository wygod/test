# -*-coding:utf-8-*-
import multiprocessing
from multiprocessing.pool import ThreadPool

from beidoubusiness.wegamersbusiness import WeGameSocket
from beidoudistribution import wegamercelery
from beidousynthesize.wegamers import *
from beidoulogin.login import WegamersLoginInfo
from beidoudistribution.celery import app
from beidouloginstance.loginstance import BeibouLog
from beidouspider.wegamerspider import WegameSpider
from beidoudatastore.appredisdatastore import RedisObject
from beidouconf.baseconf.beidouredisdb import account_login_db
from beidouconf.baseconf.beidouredisconf import wegamers_spider_host, wegamers_spider_port, wegamers_spider_password, \
    wegamers_push_host, wegamers_push_port, wegamers_push_password

log_instance = BeibouLog()

thread_pool = ThreadPool(multiprocessing.cpu_count())
push_obj = RedisObject(host=wegamers_push_host, port=wegamers_push_port, password=wegamers_push_password)

redis_obj = RedisObject(host=wegamers_spider_host, port=wegamers_spider_port, password=wegamers_spider_password)

wegamer_list = redis_obj.redis_client(account_login_db)

wegame_init = WegameSpider(redisObject=redis_obj)

log = log_instance.beidou_create_log("wegamer_spider_test")


def wegamer_init_app(init_game):
    log = log_instance.beidou_create_log("wegamer_init")

    wegamer_spider = WeGameRunSpider(redis_obj=redis_obj,
                                     log=log,
                                     app_name="wegamer_init")

    wegame_s = WegameSpider(redisObject=redis_obj)

    wegamer_spider.get_context(base_func=wegame_s.get_user_text,
                               init_game_id=init_game,
                               redis_conn=None,
                               context=True)


def wegamer_spider_user(uin, context, log, redis_obj):
    wegamer_spider = WeGameRunSpider(redis_obj=redis_obj,
                                     log=log,
                                     app_name="wegamer_init")

    redis_num = redis_obj.redis_client(account_login_db)

    wegame_s = WegameSpider(redisObject=redis_obj)

    wegamer_spider.get_context(base_func=wegame_s.get_all_fans,
                               init_game_id=uin,
                               redis_conn=redis_num,
                               context=context)


def wegamer_business_friend(account,
                            password,
                            host_tcp,
                            port_tcp):
    log = log_instance.beidou_create_log("wegamer_friend")

    we_gamer_socket = WeGameSocket(host=host_tcp, port=port_tcp)

    try:

        app_data = WegamersLoginInfo(we_gamer_socket)

        wegame_run = WeGameRunBusiness(app_name="wegamer_friend",
                                       log=log,
                                       redis_obj=redis_obj,
                                       we_gamer_socket=we_gamer_socket)

        have_login = app_data.login_info(account, password)

        if have_login:

            wegame_run.we_game_add_user(account=account)

        we_gamer_socket.close()

    except Exception as e:

        print(e)

        we_gamer_socket.close()

    finally:

        we_gamer_socket.close()


def wegamer_business_push(account,
                          password,
                          host_tcp,
                          port_tcp):
    log = log_instance.beidou_create_log("wegamer_friend")

    we_gamer_socket = WeGameSocket(host=host_tcp, port=port_tcp)

    try:

        wegamer_push = WeGamePush(app_name="wegamer_push",
                                  redis_obj=redis_obj,
                                  log=log,
                                  push_obj=push_obj,
                                  we_gamer_socket=we_gamer_socket)

        app_data = WegamersLoginInfo(we_gamer_socket)

        have_login = app_data.login_info(account, password)

        if have_login:

            wegamer_push.run_init(account)

        we_gamer_socket.close()

    except Exception as e:

        print(e)

        we_gamer_socket.close()

    finally:

        we_gamer_socket.close()


if __name__ == "__main__":

    pass

    # base_topic = b'init_game'
    #
    # if base_topic not in wegamer_list.keys():
    #     wegame_init.get_game_abb()
    #
    #     print("init end")
    #
    # init = wegamer_list.hgetall(base_topic.decode("utf-8"))
    #
    # for keys in init:
    #     wegamer_init_app(keys)

    # # -*-coding:utf-8-*- ok
    # import random
    # import multiprocessing
    # from multiprocessing.pool import ThreadPool
    #
    # from beidoudistribution import wegamercelery
    # from beidoubusiness.wegamersbusiness import WeGameSocket
    # from beidouloginstance.loginstance import BeibouLog
    # from beidoudatastore.appredisdatastore import RedisObject
    # from beidouconf.beidoudeviceconf.deviceconf import wegame_host_tcp
    # from beidouconf.beidouaccount.accountpassword import wegamer_account_add_list
    # from beidouconf.baseconf.beidouredisconf import wegamers_spider_host, wegamers_spider_port, wegamers_spider_password
    #
    # redis_obj = RedisObject(host=wegamers_spider_host, port=wegamers_spider_port, password=wegamers_spider_password)
    #
    # account_lock = BeiDouBase(redis_obj)
    #
    # account_lock.base_process_lock(["2667946747@qq.com"])
    # for account_password in [("2667946747@qq.com","sunking09")]:#wegamer_account_add_list:
    #     account, password = account_password
    #
    #     # host_tcp, port_tcp = random.choice(wegame_host_tcp)
    #
    #     wegamer_business_friend(account, password, host_tcp="192.168.100.134", port_tcp=4966)
    #     #
    #     # wegamercelery.wegamer_business_friend.apply_async(args=[account,
    #     #                                                         password],
    #     #                                                   queue="wegamers_friend", routing_key="wegamers_friend")
    # #
    # -*-coding:utf-8-*-
    #ok
    # import random
    #
    # from beidoudistribution import wegamercelery
    #
    # from beidouconf.beidoudeviceconf.deviceconf import wegame_host_tcp
    # from beidouconf.beidouaccount.accountpassword import wegamer_account_push_list
    #
    # for account_password in [("2667946747@qq.com","sunking09")]:
    #     account, password = account_password
    #
    #     host_tcp, port_tcp = random.choice(wegame_host_tcp)
    #     wegamer_business_push(account,password,host_tcp="192.168.100.134", port_tcp=4966)
    #     wegamercelery.wegamer_business_push.apply_async(args=[account,
    #                                                           password,host_tcp,port_tcp],
    #                                                     queue="wegamers_push", routing_key="wegamers_push")

    # # -*-coding:utf-8-*-
    # import random
    # import multiprocessing
    # from multiprocessing.pool import ThreadPool
    # from beidoudistribution import wegamercelery
    # from beidouloginstance.loginstance import BeibouLog
    # from beidouconf.baseconf.beidouredisdb import uuid_db
    # from beidoudatastore.appredisdatastore import RedisObject
    # from beidouconf.baseconf.beidouredisconf import wegamers_spider_host, wegamers_spider_port, wegamers_spider_password, \
    #     wegamers_push_host, wegamers_push_port, wegamers_push_password
    #
    # log_instance = BeibouLog()
    #
    # thread_pool = ThreadPool(multiprocessing.cpu_count())
    #
    # redis_obj = RedisObject(host=wegamers_spider_host, port=wegamers_spider_port, password=wegamers_spider_password)
    #
    # wegamer_conn = RedisObject(host=wegamers_spider_host, port=wegamers_spider_port, password=wegamers_spider_password)
    #
    # wegamer_list = wegamer_conn.redis_client(uuid_db)
    #
    # keys_list = wegamer_list.smembers("uuidcontrol")
    #
    # log = log_instance.beidou_create_log("wegamer_spider")
    #
    # for uuid in keys_list:
    # #     wegamercelery.wegamer_spider_user.apply_async(args=[uuid.decode("utf-8"),
    # #                                                         False, log,
    # #                                                         redis_obj, thread_pool],
    # #                                                   queue="wegamers_friend", routing_key="wegamers_friend")
