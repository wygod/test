# -*- coding:utf-8 -*-
import sys

sys.path.append("/home/server/tumbler")
import time
import random
import json
import requests
import jpype
import uuid
from urllib import parse
import time

from tumbler_config import *

from tumbler_clean import Clean

from tumbler_dispatch import TumblerDispatch

from tumbler_save import BaseDataRedisOpertion

class TumblerBaseJava:

    def __init__(self):

        for i_java in java_package:

            jpype.addClassPath(i_java)

        if not jpype.isJVMStarted():

            jpype.startJVM(java_base_path,"-Xmx1024M", "-Xms512M")

        java_class = jpype.JClass('com.xp.lib.RequestHeaderSdk')

        self.request_header_sdk = java_class()

    def tumbler_make_login(self,email, password):

        handle_string = self.request_header_sdk.makeLogin(email, password)

        return handle_string


    def tumbler_sig(self,handle_str,args=""):

        sig = self.request_header_sdk.makeSignature(handle_str, args)

        return sig

    def tumbler_oauth_nonce(self):

        oauth_nonce = str(self.request_header_sdk.getPyOauthNonce())

        return oauth_nonce

    def tumbler_make_user_info(self,oauth_token):

        return self.request_header_sdk.makeGetUserInfo(oauth_token)

    def tumbler_make_auth_url(self,email):

        return self.request_header_sdk.makeAuthUrl(email)

    def tumbler_login(self,email, password):

        login_string = self.request_header_sdk.makeLogin(email, password)

        return self.tumbler_sig(login_string)

    def tumbler_following_list(self,token, offset):

        return self.request_header_sdk.makeGetFollowing(token, offset)

    def tumbler_follow_user(self,oauth_token,url,placement_id,context):

        return self.request_header_sdk.makeFollowSomeone(oauth_token,url,placement_id,context)

    def tumbler_blog(self,oauth_token, username,offset):

        return self.request_header_sdk.makeGetSomeoneBlogs(oauth_token, username,offset)

    def tumbler_blog_comment(self,oauth_token, username, blog_id):

        return self.request_header_sdk.makeGetBlogComments(oauth_token, username, blog_id)

    def tumbler_make_get_info(self,oauth_token, username):

        return self.request_header_sdk.makeGetInfo(oauth_token, username)

    def tumbler_participant_info(self,oauth_token, participants, q):

        return self.request_header_sdk.makeParticipantInfo(oauth_token, participants, q)

    def tumbler_participant(self):

        return self.request_header_sdk.getM_Participant()

    def tumbler_get_m(self):

        return self.request_header_sdk.getM_q()

    def tumbler_send_message(self,oauth_token, msg, participants, q,context="TEXT"):

        return self.request_header_sdk.makeSendMessage(oauth_token, msg, participants, q, context)

    def tumbler_timestamp(self):

        return self.request_header_sdk.getPyTimestamp()

class TumblerLoginInfo:

    def __init__(self,tumblerBaseJava):

        self.header = {
            "user-agent": "Tumblr/Android/14.9.0.00",
            # "Host": "api.tumblr.com",
            "x-version": "device/14.9.0.00/0/6.0.1/tumblr/",
            "x-identifier": "370f2ba6-79ee-4a75-a845-652a2c8fee9f",  # java ramdom uuid
            "x-identifier-date": "",  # timestamp
            "accept-language": "zh-CN",
            "pragma": "no-cache",
            "yx": "63bop7ata0i3i",
            "x-yuser-agent": "YMobile/1.0 (com.tumblr/14.9.0.00; Android/6.0.1; MTC20F; angler; Huawei; Nexus 6P; 5.41; 2392x1440;)",
            "di": "DI/1.0 (; ; [WIFI])",
            "x-background": "false",
            "x-s-id": "NGUxODZlODgtYTFiOS00NDFhLTkxMTUtNGYzM2IyOTE4ZjVj",  # adv_id is constant
            "x-s-id-enabled": "false",
            "authorization": "OAuth oauth_consumer_key=\"BUHsuO5U9DF42uJtc8QTZlOmnUaJmBJGuU1efURxeklbdiLn9L\", oauth_nonce=\"-8662737014390362079\", oauth_signature=\"uwjKKmGWv0e2CfaOT8TS6%2BXpQGQ%3D\", oauth_signature_method=\"HMAC-SHA1\", oauth_timestamp=\"1577955467\", oauth_version=\"1.0\"",
            "content-type": "application/x-www-form-urlencoded",
        }

        self.tumbler_base_java = tumblerBaseJava

        self.redis_object = BaseDataRedisOpertion()

        self.redis_con = self.redis_object.redis_client(1)

    def auth_email(self,email,password):

        from_data = {"force_mode": 1, 'email': email}

        tumbler_header = self.header

        tumbler_header['x-identifier'] = str(uuid.uuid4())

        handle_string = self.tumbler_base_java.tumbler_make_login(email,password)

        sig = self.tumbler_base_java.tumbler_sig(handle_string)

        oauth_nonce = str(self.tumbler_base_java.tumbler_oauth_nonce())

        tumbler_header[
            'authorization'] = "OAuth oauth_consumer_key=\"BUHsuO5U9DF42uJtc8QTZlOmnUaJmBJGuU1efURxeklbdiLn9L\", oauth_nonce=\""\
                               + oauth_nonce + "\", oauth_signature=\"" + sig + \
                               "\", oauth_signature_method=\"HMAC-SHA1\", oauth_timestamp=\"" + \
                               str(self.tumbler_base_java.tumbler_timestamp()) +\
                               "\", oauth_version=\"1.0\""

        response = requests.post("https://api.tumblr.com/v2/auth", headers=tumbler_header,
                                     data=parse.urlencode(from_data), verify=False)

        if response.status_code == 200:

            return True

    def get_user_info(self,email):

        this_header = self.header

        oauth_token = self.redis_con.get(email + ":oauth_token").decode("utf-8")

        oauth_token_secret = self.redis_con.get(email + ":oauth_token_secret").decode("utf-8")

        handle_string = self.tumbler_base_java.tumbler_make_user_info(oauth_token)

        sig = self.tumbler_base_java.tumbler_sig(handle_string, oauth_token_secret)

        oauth_nonce = str(self.tumbler_base_java.tumbler_oauth_nonce())

        this_header[
            'authorization'] = "OAuth oauth_consumer_key=\"BUHsuO5U9DF42uJtc8QTZlOmnUaJmBJGuU1efURxeklbdiLn9L\",oauth_nonce=\"" +\
                               oauth_nonce + "\", oauth_signature=\"" + sig + \
                               "\", oauth_signature_method=\"HMAC-SHA1\", oauth_timestamp=\"" + \
                               str(self.tumbler_base_java.tumbler_timestamp()) + \
                               "\", oauth_token=\"" + oauth_token + "\", oauth_version=\"1.0\""

        this_header['x-identifier-date'] = str(time.time())

        this_header['x-identifier'] = str(uuid.uuid4())

        response = requests.get("https://api.tumblr.com/v2/user/info?force_oauth=false&private_blogs=true",
                                headers=this_header, verify=False)

        if response.status_code == 200:

            response_dict = json.loads(response.text)

            g_participants = response_dict['response']['user']['crm_uuid']

            self.redis_con.set(email+":uuid",g_participants)

    def login_by_email(self,email, password):

        handle_string = self.tumbler_base_java.tumbler_make_login(email, password)

        sig = self.tumbler_base_java.tumbler_sig(handle_string, "")

        login_header = self.header
        oauth_nonce = str(self.tumbler_base_java.tumbler_oauth_nonce())

        login_header[
            'authorization'] = "OAuth oauth_consumer_key=\"BUHsuO5U9DF42uJtc8QTZlOmnUaJmBJGuU1efURxeklbdiLn9L\", oauth_nonce=\""+ oauth_nonce + "\", oauth_signature=\"" + sig +"\", oauth_signature_method=\"HMAC-SHA1\", oauth_timestamp=\"" +str(self.tumbler_base_java.tumbler_timestamp()) + "\", oauth_version=\"1.0\""

        login_header['x-identifier-date'] = str(int(time.time()))

        from_data = {"x_auth_username": email, "x_auth_password": password, 'x_auth_mode': 'client_auth'}

        response = requests.post("https://www.tumblr.com/oauth/access_token",
                                 headers=login_header,
                                 data=parse.urlencode(from_data), verify=False)

        if response.status_code == 200:

            token_data = response.text.split("&")

            oauth_token = token_data[0].split("=")[1]

            oauth_token_secret = token_data[1].split("=")[1]

            self.redis_con.set(email+":oauth_token",oauth_token)

            self.redis_con.set(email+":oauth_token_secret",oauth_token_secret)

class TumblerBaseUserInfo:

    def __init__(self,tumblerBaseJava):

        self.base_header =  {
            "user-agent": "Tumblr/Android/14.9.0.00",
            "Host": "api.tumblr.com",
            "x-version": "device/14.9.0.00/0/6.0.1/tumblr/",
            "x-identifier": "370f2ba6-79ee-4a75-a845-652a2c8fee9f",  # java ramdom uuid
            "x-identifier-date": "",  # timestamp
            "accept-language": "zh-CN",
            "pragma": "no-cache",
            "yx": "63bop7ata0i3i",
            "x-yuser-agent": "YMobile/1.0 (com.tumblr/14.9.0.00; Android/6.0.1; MTC20F; angler; Huawei; Nexus 6P; 5.41; 2392x1440;)",
            "di": "DI/1.0 (; ; [WIFI])",
            "x-background": "false",
            "x-s-id": "NGUxODZlODgtYTFiOS00NDFhLTkxMTUtNGYzM2IyOTE4ZjVj",  # adv_id is constant
            "x-s-id-enabled": "false",
            "authorization": "OAuth oauth_consumer_key=\"BUHsuO5U9DF42uJtc8QTZlOmnUaJmBJGuU1efURxeklbdiLn9L\", oauth_nonce=\"-8662737014390362079\", oauth_signature=\"uwjKKmGWv0e2CfaOT8TS6%2BXpQGQ%3D\", oauth_signature_method=\"HMAC-SHA1\", oauth_timestamp=\"1577955467\", oauth_version=\"1.0\"",
            "content-type": "application/x-www-form-urlencoded",
        }

        self.blog_user = Clean()

        self.tumbler_base_java = tumblerBaseJava

        self.time = self.tumbler_base_java.tumbler_timestamp()

        self.tumbler_base_java = TumblerBaseJava()

        self.redis_object = BaseDataRedisOpertion()

        self.redis_con = self.redis_object.redis_client(1)

        self.redis_cache = self.redis_object.redis_client(13)



    def spider_init_data(self,func,items="trending"):

        offset = 0

        page = 1

        limit = 20

        if self.redis_cache.hget(items,page):

            page = self.redis_cache.hget(items,"page").decode("utf-8")

            offset = self.redis_cache.hget(items,"offset").decode("utf-8")

        while True:

            time.sleep(random.randint(1,5)/10)

            print("/////////////")

            print(offset, page, limit, items)

            print("||||||||||")

            if offset<0:

                break

            spider_url = "https://www.tumblr.com/svc/discover/posts?offset={}&\
            askingForPage={}&limit={}&type={}&withFormKey=true".format(offset,page,limit,items)

            spider_header = {
                "accept":"*/*",
                "accept-encoding":"gzip, deflate",
                "accept-language":"zh-CN,zh;q=0.9",
                "referer":"https://www.tumblr.com/explore/{}".format(items),
                "sec-fetch-mode":"cors",
                "sec-fetch-site":"same-origin",
                "user-agent":"Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/76.0.3809.132 Safari/537.36",
                "x-requested-with":"XMLHttpRequest"
            }

            data = requests.get(url=spider_url,headers=spider_header,verify=False)

            result = json.loads(data.text)

            if result["meta"]["status"] != 200 or len(result["response"]["DiscoveryPosts"]["posts"]) == 0:

                break

            data_html = result["response"]["DiscoveryPosts"]["posts"]

            data_clean_blog = self.blog_user.clean_blog(data_html,items)

            func(game_list_data=data_clean_blog)

            offset = result["response"]["DiscoveryPosts"]["nextOffset"]

            self.redis_cache.hset(items,"page",page)

            self.redis_cache.hset(items,"offset",offset)

            page = page + 1

    def spider_hot_user(self,func,name,product_id,items):

        hot_user_header = {
            "accept":"application/json, text/javascript, */*; q=0.01",
            "accept-encoding":"gzip, deflate",
            "accept-language":"zh-CN,zh;q=0.9",
            "referer":"https://www.tumblr.com/explore/{}".format(items),
            "sec-fetch-mode":"cors",
            "sec-fetch-site":"same-origin",
            "user-agent":"Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/76.0.3809.132 Safari/537.36",
            "x-requested-with":"XMLHttpRequest",
            "x-tumblr-form-key":"!1231578629431|2bPzQ1eIA5eD40HtanRItEKi5IE"
        }

        hot_user_url = "https://www.tumblr.com/svc/tumblelog/{}/{}/notes?mode=rollup".format(name, product_id)

        if self.redis_cache.hget(hash(name),"url"):

            hot_user_url = self.redis_cache.hget(hash(name),"url").decode("utf-8")

        while True:

            time.sleep(random.randint(1,5)/10)

            hot_user_data = requests.get(url=hot_user_url, headers=hot_user_header, verify=False)

            result = json.loads(hot_user_data.text)

            if result["meta"]["status"] != 200 or (not "_links" in result["response"].keys()):

                break

            data_html = result["response"]["notes"]

            data_clean_blog = self.blog_user.clean_hot_use(data_html)

            func(game_list_data=data_clean_blog)

            sub_url = result["response"]["_links"]["next"]["href"]

            hot_user_url = "https://www.tumblr.com"+sub_url

            self.redis_cache.hset(hash(name), "total_notes", result["response"]["total_notes"])

            self.redis_cache.hset(hash(name),"url",hot_user_url)

    def get_user_follow_list(self,email):

        offset = 0

        oauth_token = self.redis_con.get(email+":oauth_token").decode("utf-8")

        oauth_token_secret = self.redis_con.get(email+":oauth_token_secret").decode("utf-8")

        while True:

            handle_string = self.tumbler_base_java.tumbler_following_list(oauth_token, offset)

            sig = self.tumbler_base_java.tumbler_sig(handle_string, oauth_token_secret)

            user_follow_header = self.base_header

            oauth_nonce = str(self.tumbler_base_java.tumbler_oauth_nonce())

            user_follow_header[
                'authorization'] = "OAuth oauth_consumer_key=\"BUHsuO5U9DF42uJtc8QTZlOmnUaJmBJGuU1efURxeklbdiLn9L\", oauth_nonce=\""\
                                   + oauth_nonce + "\", oauth_signature=\"" + sig +\
                                   "\", oauth_signature_method=\"HMAC-SHA1\", oauth_timestamp=\"" + str(self.time) + \
                                   "\", oauth_token=\"" + oauth_token + "\", oauth_version=\"1.0\""

            user_follow_header['x-identifier-date'] = str(self.time)

            user_url = "https://api-http2.tumblr.com/v2/blog/ironplaidcolorprofessor.tumblr.com/following?limit=20&\
            sort=recency"

            if offset != 0:

                user_url = "https://api-http2.tumblr.com/v2/blog/ironplaidcolorprofessor.tumblr.com/following?limit=20&\
                sort=recency&offset={}".format(offset)

            response = requests.get(user_url, headers=user_follow_header,verify=False)

            if response.status_code != 200:

                break

    def add_user(self,email,url,placement_id,context):

        oauth_token = self.redis_con.get(email + ":oauth_token").decode("utf-8")

        oauth_token_secret = self.redis_con.get(email + ":oauth_token_secret").decode("utf-8")

        handle_string = self.tumbler_base_java.tumbler_follow_user(oauth_token, url, placement_id, context)

        sig = self.tumbler_base_java.tumbler_sig(handle_string, oauth_token_secret)

        add_user_header = {
            "user-agent": "Tumblr/Android/14.9.0.00",
            # "Host": "api.tumblr.com",
            "x-version": "device/14.9.0.00/0/6.0.1/tumblr/",
            "x-identifier": "370f2ba6-79ee-4a75-a845-652a2c8fee9f",  # java ramdom uuid
            "x-identifier-date": "",  # timestamp
            "accept-language": "zh-CN",
            "pragma": "no-cache",
            "yx": "63bop7ata0i3i",
            "x-yuser-agent": "YMobile/1.0 (com.tumblr/14.9.0.00; Android/6.0.1; MTC20F; angler; Huawei; Nexus 6P; 5.41; 2392x1440;)",
            "di": "DI/1.0 (; ; [WIFI])",
            "x-background": "false",
            "x-s-id": "NGUxODZlODgtYTFiOS00NDFhLTkxMTUtNGYzM2IyOTE4ZjVj",  # adv_id is constant
            "x-s-id-enabled": "false",
            "authorization": "OAuth oauth_consumer_key=\"BUHsuO5U9DF42uJtc8QTZlOmnUaJmBJGuU1efURxeklbdiLn9L\", oauth_nonce=\"-8662737014390362079\", oauth_signature=\"uwjKKmGWv0e2CfaOT8TS6%2BXpQGQ%3D\", oauth_signature_method=\"HMAC-SHA1\", oauth_timestamp=\"1577955467\", oauth_version=\"1.0\"",
            "content-type": "application/x-www-form-urlencoded",
        }


        oauth_nonce = self.tumbler_base_java.tumbler_oauth_nonce()

        add_user_header[
            'authorization'] = "OAuth oauth_consumer_key=\"BUHsuO5U9DF42uJtc8QTZlOmnUaJmBJGuU1efURxeklbdiLn9L\", oauth_nonce=\""\
                               + oauth_nonce + "\", oauth_signature=\"" + sig +\
                               "\", oauth_signature_method=\"HMAC-SHA1\", oauth_timestamp=\"" + str(self.tumbler_base_java.tumbler_timestamp()) +\
                               "\", oauth_token=\"" + oauth_token + "\", oauth_version=\"1.0\""

        add_user_header['x-identifier-date'] = str(int(time.time()))

        from_data = {'url': url, 'placement_id': placement_id, 'context': context}

        response = requests.post("https://api-http2.tumblr.com/v2/user/follow",
                                 headers=add_user_header, data=parse.urlencode(from_data),
                                 verify=False)

        if response.status_code == 200:

            return True

        else:

            return False

    def get_user_blog(self,email,username):

        oauth_token = self.redis_con.get(email + ":oauth_token").decode("utf-8")

        oauth_token_secret = self.redis_con.get(email + ":oauth_token_secret").decode("utf-8")

        offset = 0

        while True:

            handle_string = self.tumbler_base_java.tumbler_blog(oauth_token, username, offset)

            sig = self.tumbler_base_java.tumbler_sig(handle_string, oauth_token_secret)

            blog_header = {
                "user-agent": "Tumblr/Android/14.9.0.00",
                # "Host": "api.tumblr.com",
                "x-version": "device/14.9.0.00/0/6.0.1/tumblr/",
                "x-identifier": "370f2ba6-79ee-4a75-a845-652a2c8fee9f",  # java ramdom uuid
                "x-identifier-date": "",  # timestamp
                "accept-language": "zh-CN",
                "pragma": "no-cache",
                "yx": "63bop7ata0i3i",
                "x-yuser-agent": "YMobile/1.0 (com.tumblr/14.9.0.00; Android/6.0.1; MTC20F; angler; Huawei; Nexus 6P; 5.41; 2392x1440;)",
                "di": "DI/1.0 (; ; [WIFI])",
                "x-background": "false",
                "x-s-id": "NGUxODZlODgtYTFiOS00NDFhLTkxMTUtNGYzM2IyOTE4ZjVj",  # adv_id is constant
                "x-s-id-enabled": "false",
                "authorization": "OAuth oauth_consumer_key=\"BUHsuO5U9DF42uJtc8QTZlOmnUaJmBJGuU1efURxeklbdiLn9L\", oauth_nonce=\"-8662737014390362079\", oauth_signature=\"uwjKKmGWv0e2CfaOT8TS6%2BXpQGQ%3D\", oauth_signature_method=\"HMAC-SHA1\", oauth_timestamp=\"1577955467\", oauth_version=\"1.0\"",
                "content-type": "application/x-www-form-urlencoded",
            }

            oauth_nonce = self.tumbler_base_java.tumbler_oauth_nonce()

            blog_header[
                'authorization'] = "OAuth oauth_consumer_key=\"BUHsuO5U9DF42uJtc8QTZlOmnUaJmBJGuU1efURxeklbdiLn9L\", oauth_nonce=\"" \
                                   + oauth_nonce + "\", oauth_signature=\"" + sig + \
                                   "\", oauth_signature_method=\"HMAC-SHA1\", oauth_timestamp=\"" + str(
                self.tumbler_base_java.tumbler_timestamp()) + \
                                   "\", oauth_token=\"" + oauth_token + "\", oauth_version=\"1.0\""

            blog_header['x-identifier-date'] = str(int(time.time()))

            response = requests.get(
                "https://api-http2.tumblr.com/v2/blog/" + username + \
                ".tumblr.com/posts?reblog_info=true&filter=clean&before_id=&layout=regular",
                headers=blog_header, verify=False)

            if response.status_code != 200:

                pass

    def get_blog_comment(self,email,username, blog_id):

        oauth_token = self.redis_con.get(email + ":oauth_token").decode("utf-8")

        oauth_token_secret = self.redis_con.get(email + ":oauth_token_secret").decode("utf-8")

        while True:

            handle_string = self.tumbler_base_java.tumbler_blog_comment(oauth_token, username, str(blog_id))

            sig = self.tumbler_base_java.tumbler_sig(handle_string, oauth_token_secret)

            oauth_nonce = str(self.tumbler_base_java.tumbler_oauth_nonce())

            blog_comment_header = {
                "user-agent": "Tumblr/Android/14.9.0.00",
                # "Host": "api.tumblr.com",
                "x-version": "device/14.9.0.00/0/6.0.1/tumblr/",
                "x-identifier": "370f2ba6-79ee-4a75-a845-652a2c8fee9f",  # java ramdom uuid
                "x-identifier-date": "",  # timestamp
                "accept-language": "zh-CN",
                "pragma": "no-cache",
                "yx": "63bop7ata0i3i",
                "x-yuser-agent": "YMobile/1.0 (com.tumblr/14.9.0.00; Android/6.0.1; MTC20F; angler; Huawei; Nexus 6P; 5.41; 2392x1440;)",
                "di": "DI/1.0 (; ; [WIFI])",
                "x-background": "false",
                "x-s-id": "NGUxODZlODgtYTFiOS00NDFhLTkxMTUtNGYzM2IyOTE4ZjVj",  # adv_id is constant
                "x-s-id-enabled": "false",
                "authorization": "OAuth oauth_consumer_key=\"BUHsuO5U9DF42uJtc8QTZlOmnUaJmBJGuU1efURxeklbdiLn9L\", oauth_nonce=\"-8662737014390362079\", oauth_signature=\"uwjKKmGWv0e2CfaOT8TS6%2BXpQGQ%3D\", oauth_signature_method=\"HMAC-SHA1\", oauth_timestamp=\"1577955467\", oauth_version=\"1.0\"",
                "content-type": "application/x-www-form-urlencoded",
            }

            oauth_nonce = self.tumbler_base_java.tumbler_oauth_nonce()

            blog_comment_header[
                'authorization'] = "OAuth oauth_consumer_key=\"BUHsuO5U9DF42uJtc8QTZlOmnUaJmBJGuU1efURxeklbdiLn9L\", oauth_nonce=\"" \
                                   + oauth_nonce + "\", oauth_signature=\"" + sig + \
                                   "\", oauth_signature_method=\"HMAC-SHA1\", oauth_timestamp=\"" + str(
                self.tumbler_base_java.tumbler_timestamp()) + \
                                   "\", oauth_token=\"" + oauth_token + "\", oauth_version=\"1.0\""

            blog_comment_header['x-identifier-date'] = str(int(time.time()))


            response = requests.get(
                "https://api-http2.tumblr.com/v2/blog/" + username + "/post/" + str(
                    blog_id) + "/notes/timeline?fields%5Bblogs%5D=name%2Cuuid%2Ctheme%2Cis_adult%2C%3Ffollowed",
                headers=blog_comment_header, verify=False)

            #add save

    def get_q(self, email, username):

        oauth_token = self.redis_con.get(email + ":oauth_token").decode("utf-8")

        oauth_token_secret = self.redis_con.get(email + ":oauth_token_secret").decode("utf-8")

        handle_string = self.tumbler_base_java.tumbler_make_get_info(oauth_token, username)

        sig = self.tumbler_base_java.tumbler_sig(handle_string, oauth_token_secret)

        get_q_header = {
            "user-agent": "Tumblr/Android/14.9.0.00",
            # "Host": "api.tumblr.com",
            "x-version": "device/14.9.0.00/0/6.0.1/tumblr/",
            "x-identifier": "370f2ba6-79ee-4a75-a845-652a2c8fee9f",  # java ramdom uuid
            "x-identifier-date": "",  # timestamp
            "accept-language": "zh-CN",
            "pragma": "no-cache",
            "yx": "63bop7ata0i3i",
            "x-yuser-agent": "YMobile/1.0 (com.tumblr/14.9.0.00; Android/6.0.1; MTC20F; angler; Huawei; Nexus 6P; 5.41; 2392x1440;)",
            "di": "DI/1.0 (; ; [WIFI])",
            "x-background": "false",
            "x-s-id": "NGUxODZlODgtYTFiOS00NDFhLTkxMTUtNGYzM2IyOTE4ZjVj",  # adv_id is constant
            "x-s-id-enabled": "false",
            "authorization": "OAuth oauth_consumer_key=\"BUHsuO5U9DF42uJtc8QTZlOmnUaJmBJGuU1efURxeklbdiLn9L\", oauth_nonce=\"-8662737014390362079\", oauth_signature=\"uwjKKmGWv0e2CfaOT8TS6%2BXpQGQ%3D\", oauth_signature_method=\"HMAC-SHA1\", oauth_timestamp=\"1577955467\", oauth_version=\"1.0\"",
            "content-type": "application/x-www-form-urlencoded",
        }

        oauth_nonce = self.tumbler_base_java.tumbler_oauth_nonce()

        get_q_header[
                'authorization'] = "OAuth oauth_consumer_key=\"BUHsuO5U9DF42uJtc8QTZlOmnUaJmBJGuU1efURxeklbdiLn9L\", oauth_nonce=\"" \
                                   + oauth_nonce + "\", oauth_signature=\"" + sig + \
                                   "\", oauth_signature_method=\"HMAC-SHA1\", oauth_timestamp=\"" + str(
                self.tumbler_base_java.tumbler_timestamp()) + \
                                   "\", oauth_token=\"" + oauth_token + "\", oauth_version=\"1.0\""

        get_q_header['x-identifier-date'] = str(int(time.time()))

        response = requests.get("https://api-http2.tumblr.com/v2/blog/"+username+".tumblr.com/info?is_full_blog_info=false&blog_name=iwannafuckyexiu&prefetch%5B0%5D=&fields%5Bblogs%5D=name%2Cdescription%2Ctitle%2Ctheme%2Cis_nsfw%2Cis_adult%2Cshare_following%2Cshare_likes%2C%3Ffollowed%2C%3Fcan_message%2Cuuid%2C%3Fis_blocked_from_primary%2C%3Fask%2C%3Fask_anon%2C%3Fcan_submit%2C%3Fcan_send_fan_mail%2C%3Fcan_subscribe%2Csubscribed%2C%3Fsubmission_page_title%2C%3Fsubmission_terms%2Cseconds_since_last_activity%2C%3Favatar",
                headers=get_q_header, verify=False)

        print(response.text)

        return json.loads(response.text)

class TumblerMessage:

    def __init__(self,tumblerBaseJava):
        self.base_header = {
            "user-agent": "Tumblr/Android/14.9.0.00",
            "Host": "api.tumblr.com",
            "x-version": "device/14.9.0.00/0/6.0.1/tumblr/",
            "x-identifier": "370f2ba6-79ee-4a75-a845-652a2c8fee9f",  # java ramdom uuid
            "x-identifier-date": "",  # timestamp
            "accept-language": "zh-CN",
            "pragma": "no-cache",
            "yx": "63bop7ata0i3i",
            "x-yuser-agent": "YMobile/1.0 (com.tumblr/14.9.0.00; Android/6.0.1; MTC20F; angler; Huawei; Nexus 6P; 5.41; 2392x1440;)",
            "di": "DI/1.0 (; ; [WIFI])",
            "x-background": "false",
            "x-s-id": "NGUxODZlODgtYTFiOS00NDFhLTkxMTUtNGYzM2IyOTE4ZjVj",  # adv_id is constant
            "x-s-id-enabled": "false",
            "authorization": "OAuth oauth_consumer_key=\"BUHsuO5U9DF42uJtc8QTZlOmnUaJmBJGuU1efURxeklbdiLn9L\", oauth_nonce=\"-8662737014390362079\", oauth_signature=\"uwjKKmGWv0e2CfaOT8TS6%2BXpQGQ%3D\", oauth_signature_method=\"HMAC-SHA1\", oauth_timestamp=\"1577955467\", oauth_version=\"1.0\"",
            "content-type": "application/x-www-form-urlencoded",
        }

        self.tumbler_base_java = tumblerBaseJava

        self.redis_object = BaseDataRedisOpertion()

        self.redis_con = self.redis_object.redis_client(1)

        self.time = self.tumbler_base_java.tumbler_timestamp()

    def send_pre_send_massage(self,email,participants, q):

        oauth_token = self.redis_con.get(email + ":oauth_token").decode("utf-8")

        oauth_token_secret = self.redis_con.get(email + ":oauth_token_secret").decode("utf-8")

        handle_string = self.tumbler_base_java.tumbler_participant_info(oauth_token, participants, q)

        sig = self.tumbler_base_java.tumbler_sig(handle_string, oauth_token_secret)

        pre_send_massage_header = {
            "user-agent": "Tumblr/Android/14.9.0.00",
            # "Host": "api.tumblr.com",
            "x-version": "device/14.9.0.00/0/6.0.1/tumblr/",
            "x-identifier": "370f2ba6-79ee-4a75-a845-652a2c8fee9f",  # java ramdom uuid
            "x-identifier-date": "",  # timestamp
            "accept-language": "zh-CN",
            "pragma": "no-cache",
            "yx": "63bop7ata0i3i",
            "x-yuser-agent": "YMobile/1.0 (com.tumblr/14.9.0.00; Android/6.0.1; MTC20F; angler; Huawei; Nexus 6P; 5.41; 2392x1440;)",
            "di": "DI/1.0 (; ; [WIFI])",
            "x-background": "false",
            "x-s-id": "NGUxODZlODgtYTFiOS00NDFhLTkxMTUtNGYzM2IyOTE4ZjVj",  # adv_id is constant
            "x-s-id-enabled": "false",
            "authorization": "OAuth oauth_consumer_key=\"BUHsuO5U9DF42uJtc8QTZlOmnUaJmBJGuU1efURxeklbdiLn9L\", oauth_nonce=\"-8662737014390362079\", oauth_signature=\"uwjKKmGWv0e2CfaOT8TS6%2BXpQGQ%3D\", oauth_signature_method=\"HMAC-SHA1\", oauth_timestamp=\"1577955467\", oauth_version=\"1.0\"",
            "content-type": "application/x-www-form-urlencoded",
        }

        oauth_nonce = self.tumbler_base_java.tumbler_oauth_nonce()

        pre_send_massage_header[
            'authorization'] = "OAuth oauth_consumer_key=\"BUHsuO5U9DF42uJtc8QTZlOmnUaJmBJGuU1efURxeklbdiLn9L\", oauth_nonce=\"" \
                               + oauth_nonce + "\", oauth_signature=\"" + sig + \
                               "\", oauth_signature_method=\"HMAC-SHA1\", oauth_timestamp=\"" + str(
            self.tumbler_base_java.tumbler_timestamp()) + \
                               "\", oauth_token=\"" + oauth_token + "\", oauth_version=\"1.0\""

        pre_send_massage_header['x-identifier-date'] = str(int(time.time()))

        participants = self.tumbler_base_java.tumbler_participant()

        q = self.tumbler_base_java.tumbler_get_m()

        response = requests.get(
            "https://api-http2.tumblr.com/v2/conversations/participant_info?participant=" + \
            participants + "&" + "q=" + q,
            headers=pre_send_massage_header, verify=False)

        if response.status_code == 200:

            return True

        else:
            return False

    def list_message_list(self,email,participant):

        chat_url = "https://api-http2.tumblr.com/v2/conversations?participant={}".format(participant.replace(":","%"))

        oauth_token = self.redis_con.get(email + ":oauth_token").decode("utf-8")

        oauth_token_secret = self.redis_con.get(email + ":oauth_token_secret").decode("utf-8")

        handle_string = self.tumbler_base_java.tumbler_participant_info(oauth_token, participants, q)

        sig = self.tumbler_base_java.tumbler_sig(handle_string, oauth_token_secret)

        send_massage_header = {
            "user-agent": "Tumblr/Android/14.9.0.00",
            "Host": "api.tumblr.com",
            "x-version": "device/14.9.0.00/0/6.0.1/tumblr/",
            "x-identifier": "370f2ba6-79ee-4a75-a845-652a2c8fee9f",  # java ramdom uuid
            "x-identifier-date": "",  # timestamp
            "accept-language": "zh-CN",
            "pragma": "no-cache",
            "yx": "63bop7ata0i3i",
            "x-yuser-agent": "YMobile/1.0 (com.tumblr/14.9.0.00; Android/6.0.1; MTC20F; angler; Huawei; Nexus 6P; 5.41; 2392x1440;)",
            "di": "DI/1.0 (; ; [WIFI])",
            "x-background": "false",
            "x-s-id": "NGUxODZlODgtYTFiOS00NDFhLTkxMTUtNGYzM2IyOTE4ZjVj",  # adv_id is constant
            "x-s-id-enabled": "false",
            "authorization": "OAuth oauth_consumer_key=\"BUHsuO5U9DF42uJtc8QTZlOmnUaJmBJGuU1efURxeklbdiLn9L\", oauth_nonce=\"-8662737014390362079\", oauth_signature=\"uwjKKmGWv0e2CfaOT8TS6%2BXpQGQ%3D\", oauth_signature_method=\"HMAC-SHA1\", oauth_timestamp=\"1577955467\", oauth_version=\"1.0\"",
            "content-type": "application/x-www-form-urlencoded",
        }

        oauth_nonce = self.tumbler_base_java.tumbler_oauth_nonce()

        send_massage_header[
            'authorization'] = "OAuth oauth_consumer_key=\"BUHsuO5U9DF42uJtc8QTZlOmnUaJmBJGuU1efURxeklbdiLn9L\", oauth_nonce=\"" \
                               + oauth_nonce + "\", oauth_signature=\"" + sig + \
                               "\", oauth_signature_method=\"HMAC-SHA1\", oauth_timestamp=\"" + str(
            self.tumbler_base_java.tumbler_timestamp()) + \
                               "\", oauth_token=\"" + oauth_token + "\", oauth_version=\"1.0\""

        send_massage_header['x-identifier-date'] = str(int(time.time()))

        response = requests.get(chat_url,
            headers=send_massage_header, verify=False)

        if response.status_code == 200:

            print(response.text)

            chat_list = json.loads(response.text)

            return chat_list

        else:

            return None

    def send_message_to_someone(self,email,participants, q, msg):

        send_pre_send_message = self.send_pre_send_massage(email,participants, q)

        oauth_token = self.redis_con.get(email + ":oauth_token").decode("utf-8")

        oauth_token_secret = self.redis_con.get(email + ":oauth_token_secret").decode("utf-8")

        if send_pre_send_message:

            handle_string = self.tumbler_base_java.tumbler_send_message(oauth_token, msg, participants, q, "TEXT")

            sig = self.tumbler_base_java.tumbler_sig(handle_string, oauth_token_secret)

            send_to_message_header = {
                "user-agent": "Tumblr/Android/14.9.0.00",
                # "Host": "api.tumblr.com",
                "x-version": "device/14.9.0.00/0/6.0.1/tumblr/",
                "x-identifier": "370f2ba6-79ee-4a75-a845-652a2c8fee9f",  # java ramdom uuid
                "x-identifier-date": "",  # timestamp
                "accept-language": "zh-CN",
                "pragma": "no-cache",
                "yx": "63bop7ata0i3i",
                "x-yuser-agent": "YMobile/1.0 (com.tumblr/14.9.0.00; Android/6.0.1; MTC20F; angler; Huawei; Nexus 6P; 5.41; 2392x1440;)",
                "di": "DI/1.0 (; ; [WIFI])",
                "x-background": "false",
                "x-s-id": "NGUxODZlODgtYTFiOS00NDFhLTkxMTUtNGYzM2IyOTE4ZjVj",  # adv_id is constant
                "x-s-id-enabled": "false",
                "authorization": "OAuth oauth_consumer_key=\"BUHsuO5U9DF42uJtc8QTZlOmnUaJmBJGuU1efURxeklbdiLn9L\", oauth_nonce=\"-8662737014390362079\", oauth_signature=\"uwjKKmGWv0e2CfaOT8TS6%2BXpQGQ%3D\", oauth_signature_method=\"HMAC-SHA1\", oauth_timestamp=\"1577955467\", oauth_version=\"1.0\"",
                "content-type": "application/x-www-form-urlencoded",
            }

            oauth_nonce = self.tumbler_base_java.tumbler_oauth_nonce()

            send_to_message_header[
                'authorization'] = "OAuth oauth_consumer_key=\"BUHsuO5U9DF42uJtc8QTZlOmnUaJmBJGuU1efURxeklbdiLn9L\", oauth_nonce=\"" \
                                   + oauth_nonce + "\", oauth_signature=\"" + sig + \
                                   "\", oauth_signature_method=\"HMAC-SHA1\", oauth_timestamp=\"" + str(
                self.tumbler_base_java.tumbler_timestamp()) + \
                                   "\", oauth_token=\"" + oauth_token + "\", oauth_version=\"1.0\""

            send_to_message_header['x-identifier-date'] = str(int(time.time()))

            form_data = {"participant": participants, "participants[1]": participants, "participants[0]": q,
                         "message": msg, "type": "TEXT"}

            time.sleep(random.randint(2,5))

            response = requests.post(
                "https://api-http2.tumblr.com/v2/conversations/messages", data=parse.urlencode(form_data),
                headers=send_to_message_header, verify=False)

            j_result = json.loads(response.text)

            if j_result["meta"]["status"] == 429:

                return False,429

            if response.status_code == 200 and j_result["meta"]["status"] == 200:

                return True,0

            else:

                return False,0

            #add data

if __name__=="__main__":

    from functools import partial
    import multiprocessing
    import threadpool

    cpu_thread = multiprocessing.cpu_count() - 2 if multiprocessing.cpu_count() > 2 else multiprocessing.cpu_count()
    tu = TumblerBaseJava()
    thread_pool = threadpool.ThreadPool(cpu_thread)

    tumbler = TumblerBaseUserInfo(tu)

    # redis_object = BaseDataRedisOpertion()

    # tumbler_dispatch = TumblerDispatch(redis_object)
    #thread_pool,func

    # func_save = partial(tumbler_dispatch.open_func,thread_pool=thread_pool,func=tumbler_dispatch.save_func)
    #
    # tumbler.spider_init_data(func=func_save)
    user_name = "gametest666@163.com"

    user_password = "SLkVxPD76vD2e5hj"

    tumbler_login_info = TumblerLoginInfo(tu)

    is_have_value = tumbler_login_info.auth_email(user_name,user_password)

    if is_have_value:

        tumbler_login_info.login_by_email("gametest666@163.com", "SLkVxPD76vD2e5hj")

        tumbler_login_info.get_user_info(user_name)

