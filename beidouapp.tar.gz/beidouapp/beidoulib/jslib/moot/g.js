function c(e, t) {
	
    var n = (65535 & e) + (65535 & t);
    return (e >> 16) + (t >> 16) + (n >> 16) << 16 | 65535 & n
	
}
function o(e, t, n, r, i, a) {
    return c((s = c(c(t, e), c(r, a))) << (o = i) | s >>> 32 - o, n);
    var s, o
}
function h(e, t, n, r, i, a, s) {
    return o(t & n | ~t & r, e, t, i, a, s)
}
function f(e, t, n, r, i, a, s) {
    return o(t & r | n & ~r, e, t, i, a, s)
}
function p(e, t, n, r, i, a, s) {
    return o(t ^ n ^ r, e, t, i, a, s)
}
function m(e, t, n, r, i, a, s) {
    return o(n ^ (t | ~r), e, t, i, a, s)
}
function u(e, t) {
    var n, r, i, a, s;
    e[t >> 5] |= 128 << t % 32,
    e[14 + (t + 64 >>> 9 << 4)] = t;
    var o = 1732584193
      , u = -271733879
      , d = -1732584194
      , l = 271733878;
    for (n = 0; n < e.length; n += 16)
        u = m(u = m(u = m(u = m(u = p(u = p(u = p(u = p(u = f(u = f(u = f(u = f(u = h(u = h(u = h(u = h(i = u, d = h(a = d, l = h(s = l, o = h(r = o, u, d, l, e[n], 7, -680876936), u, d, e[n + 1], 12, -389564586), o, u, e[n + 2], 17, 606105819), l, o, e[n + 3], 22, -1044525330), d = h(d, l = h(l, o = h(o, u, d, l, e[n + 4], 7, -176418897), u, d, e[n + 5], 12, 1200080426), o, u, e[n + 6], 17, -1473231341), l, o, e[n + 7], 22, -45705983), d = h(d, l = h(l, o = h(o, u, d, l, e[n + 8], 7, 1770035416), u, d, e[n + 9], 12, -1958414417), o, u, e[n + 10], 17, -42063), l, o, e[n + 11], 22, -1990404162), d = h(d, l = h(l, o = h(o, u, d, l, e[n + 12], 7, 1804603682), u, d, e[n + 13], 12, -40341101), o, u, e[n + 14], 17, -1502002290), l, o, e[n + 15], 22, 1236535329), d = f(d, l = f(l, o = f(o, u, d, l, e[n + 1], 5, -165796510), u, d, e[n + 6], 9, -1069501632), o, u, e[n + 11], 14, 643717713), l, o, e[n], 20, -373897302), d = f(d, l = f(l, o = f(o, u, d, l, e[n + 5], 5, -701558691), u, d, e[n + 10], 9, 38016083), o, u, e[n + 15], 14, -660478335), l, o, e[n + 4], 20, -405537848), d = f(d, l = f(l, o = f(o, u, d, l, e[n + 9], 5, 568446438), u, d, e[n + 14], 9, -1019803690), o, u, e[n + 3], 14, -187363961), l, o, e[n + 8], 20, 1163531501), d = f(d, l = f(l, o = f(o, u, d, l, e[n + 13], 5, -1444681467), u, d, e[n + 2], 9, -51403784), o, u, e[n + 7], 14, 1735328473), l, o, e[n + 12], 20, -1926607734), d = p(d, l = p(l, o = p(o, u, d, l, e[n + 5], 4, -378558), u, d, e[n + 8], 11, -2022574463), o, u, e[n + 11], 16, 1839030562), l, o, e[n + 14], 23, -35309556), d = p(d, l = p(l, o = p(o, u, d, l, e[n + 1], 4, -1530992060), u, d, e[n + 4], 11, 1272893353), o, u, e[n + 7], 16, -155497632), l, o, e[n + 10], 23, -1094730640), d = p(d, l = p(l, o = p(o, u, d, l, e[n + 13], 4, 681279174), u, d, e[n], 11, -358537222), o, u, e[n + 3], 16, -722521979), l, o, e[n + 6], 23, 76029189), d = p(d, l = p(l, o = p(o, u, d, l, e[n + 9], 4, -640364487), u, d, e[n + 12], 11, -421815835), o, u, e[n + 15], 16, 530742520), l, o, e[n + 2], 23, -995338651), d = m(d, l = m(l, o = m(o, u, d, l, e[n], 6, -198630844), u, d, e[n + 7], 10, 1126891415), o, u, e[n + 14], 15, -1416354905), l, o, e[n + 5], 21, -57434055), d = m(d, l = m(l, o = m(o, u, d, l, e[n + 12], 6, 1700485571), u, d, e[n + 3], 10, -1894986606), o, u, e[n + 10], 15, -1051523), l, o, e[n + 1], 21, -2054922799), d = m(d, l = m(l, o = m(o, u, d, l, e[n + 8], 6, 1873313359), u, d, e[n + 15], 10, -30611744), o, u, e[n + 6], 15, -1560198380), l, o, e[n + 13], 21, 1309151649), d = m(d, l = m(l, o = m(o, u, d, l, e[n + 4], 6, -145523070), u, d, e[n + 11], 10, -1120210379), o, u, e[n + 2], 15, 718787259), l, o, e[n + 9], 21, -343485551),
        o = c(o, r),
        u = c(u, i),
        d = c(d, a),
        l = c(l, s);
    return [o, u, d, l]
}
function d(e) {
    var t, n = "", r = 32 * e.length;
    for (t = 0; t < r; t += 8)
        n += String.fromCharCode(e[t >> 5] >>> t % 32 & 255);
    return n
}
function l(e) {
    var t, n = [];
    for (n[(e.length >> 2) - 1] = void 0,
    t = 0; t < n.length; t += 1)
        n[t] = 0;
    var r = 8 * e.length;
    for (t = 0; t < r; t += 8)
        n[t >> 5] |= (255 & e.charCodeAt(t / 8)) << t % 32;
    return n
}
function r(e) {
    var t, n, r = "0123456789abcdef", i = "";
    for (n = 0; n < e.length; n += 1)
        t = e.charCodeAt(n),
        i += r.charAt(t >>> 4 & 15) + r.charAt(15 & t);
    return i
}
function n(e) {
    return unescape(encodeURIComponent(e))
}
function i(e) {
    return d(u(l(t = n(e)), 8 * t.length));
    var t
}
function a(e, t) {
    return function(e, t) {
        var n, r, i = l(e), a = [], s = [];
        for (a[15] = s[15] = void 0,
        16 < i.length && (i = u(i, 8 * e.length)),
        n = 0; n < 16; n += 1)
            a[n] = 909522486 ^ i[n],
            s[n] = 1549556828 ^ i[n];
        return r = u(a.concat(l(t)), 512 + 8 * t.length),
        d(u(s.concat(r), 640))
    }(n(e), n(t))
}
function t(e, t, n) {
    return t ? n ? a(t, e) : r(a(t, e)) : n ? i(e) : r(i(e))
}

function S(e, t, n) {
    return t ? n ? a(t, e) : r(a(t, e)) : n ? i(e) : r(i(e))
}

getTimeGap = function(b_tg) {
	//return -810;
    //var e = "undefined" != typeof window ? window.b_timegap : parseInt(b_tg));
	var e = parseInt(b_tg);
    return isNaN(e) ? 0 : e
}
btoa = function(e){
	return Buffer.from(e, 'binary').toString('base64')
}
var M = {};
M.a = function(e) {
    return "function" == typeof btoa ? btoa(e) : "function" == typeof t ? (e instanceof t ? e : new t(e.toString(),"binary")).toString("base64") : e
}
getSignature = function(b_tg) {
    var e = (new Date).getTime() + this.getTimeGap(b_tg)
      , t = S(e + "#hJlVFFmLnmZ8C48AlVo+LNuZ2AUe9Qa2fSjCWLky3EM#dLOs6KgD8U0E4BZcIP7SG6GLAXg9rnI/xk8z7c5jrLU");
    return Object(M.a)(e + "#" + t)
}

