# -*-coding:utf-8-*-

from __future__ import absolute_import
import multiprocessing

from multiprocessing.pool import ThreadPool

from beidousynthesize.ifunny import *
from beidoudistribution.celery import app

thread_pool = ThreadPool(5)

def f(x):

    return str(x)+":src"

@app.task
def add(x):

    print(x)

    fd = []



    for i in range(x):
        temp_th = ThreadPool(1)

        fd.append(temp_th.apply_async(f,args=[i]).get())
        # fd.append(f(i))
        # fd.append(thread_pool.apply_async(f,[i]).get())
        temp_th.terminate()

    print("task")

    return "n".join(fd)
