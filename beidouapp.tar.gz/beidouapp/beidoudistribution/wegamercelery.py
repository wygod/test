# -*-coding:utf-8-*-

from __future__ import absolute_import


from beidousynthesize.wegamers import *
from beidoulogin.login import WegamersLoginInfo
from beidoudistribution.celery import app
from beidouspider.wegamerspider import WegameSpider
from beidouconf.baseconf.beidouredisdb import account_login_db
from beidoudatastore.appredisdatastore import RedisObject
from beidoubusiness.wegamersbusiness import WeGameSocket
from beidouloginstance.loginstance import BeibouLog
from beidouconf.baseconf.beidouredisconf import wegamers_push_host, wegamers_push_port, wegamers_push_password, \
    wegamers_spider_host, wegamers_spider_port, wegamers_spider_password

log_instance = BeibouLog()

push_obj = RedisObject(host=wegamers_push_host, port=wegamers_push_port, password=wegamers_push_password)

redis_obj = RedisObject(host=wegamers_spider_host, port=wegamers_spider_port, password=wegamers_spider_password)


@app.task
def add(x):

    print(x)

    return x

@app.task
def wegamer_init_app(init_game):

    print(init_game)
    log = log_instance.beidou_create_log("wegamer_init")

    wegamer_spider = WeGameRunSpider(redis_obj=redis_obj,
                                     log=log,
                                     app_name="wegamer_init")

    wegame_s = WegameSpider(redisObject=redis_obj)

    wegamer_spider.get_context(base_func=wegame_s.get_user_text,
                               init_game_id=init_game,
                               redis_conn=None,
                               context=True)


@app.task
def wegamer_spider_user(uin, context):
    log = log_instance.beidou_create_log("wegamer_spider")

    wegamer_spider = WeGameRunSpider(redis_obj=redis_obj,
                                     log=log,
                                     app_name="wegamer_spider")

    redis_num = redis_obj.redis_client(account_login_db)

    wegame_s = WegameSpider(redisObject=redis_obj)

    wegamer_spider.get_context(base_func=wegame_s.get_all_fans,
                               init_game_id=uin,
                               redis_conn=redis_num,
                               context=context)


@app.task
def wegamer_business_friend(account,
                            password,
                            host_tcp,
                            port_tcp):
    log = log_instance.beidou_create_log("wegamer_friend")

    we_gamer_socket = WeGameSocket(host=host_tcp, port=port_tcp)

    try:

        app_data = WegamersLoginInfo(we_gamer_socket)

        wegame_run = WeGameRunBusiness(app_name="wegamer_friend",
                                       log=log,
                                       redis_obj=redis_obj,
                                       we_gamer_socket=we_gamer_socket)

        have_login = app_data.login_info(account, password)

        if have_login:

            wegame_run.we_game_add_user(account=account)

        we_gamer_socket.close()

    except Exception as e:

        print(e)

        we_gamer_socket.close()

    finally:

        we_gamer_socket.close()


@app.task
def wegamer_business_push(account,
                          password,
                          host_tcp,
                          port_tcp):
    log = log_instance.beidou_create_log("wegamer_friend")

    we_gamer_socket = WeGameSocket(host=host_tcp, port=port_tcp)

    try:

        wegamer_push = WeGamePush(app_name="wegamer_push",
                                  redis_obj=redis_obj,
                                  log=log,
                                  push_obj=push_obj,
                                  we_gamer_socket=we_gamer_socket)

        app_data = WegamersLoginInfo(we_gamer_socket)

        have_login = app_data.login_info(account, password)

        if have_login:

            wegamer_push.run_init(account)

        we_gamer_socket.close()

    except Exception as e:

        print(e)

        we_gamer_socket.close()

    finally:

        we_gamer_socket.close()