# -*-coding:utf-8-*-

from __future__ import absolute_import

# import multiprocessing
# from multiprocessing.pool import ThreadPool

from beidoudatastore.appredisdatastore import RedisObject
from beidouloginstance.loginstance import BeibouLog
from beidousynthesize.moot import *
from beidoulogin.login import LoginInfo
from beidoudistribution.celery import app
from beidouotherscript.moot_script import MootOtherJavaScript
from beidouconf.baseconf.beidouredisconf import moot_push_host, moot_push_port, moot_push_password, moot_spider_host, \
    moot_spider_port, moot_spider_password

from beidouconf.baseconf.beidouredisdb import push_moot_user_db,push_moot_uuid_db,uuid_assigned_db


log_instance = BeibouLog()

push_obj = RedisObject(host=moot_push_host, port=moot_push_port, password=moot_push_password)

redis_obj = RedisObject(host=moot_spider_host, port=moot_spider_port, password=moot_spider_password)

app_token_signature = MootOtherJavaScript()


@app.task
def moot_init_app(user_agent, device_id, game):

    log = log_instance.beidou_create_log("moot_init")

    moot_spider = MootRunSpider(redis_obj=redis_obj,
                                log=log,
                                user_agent=user_agent,
                                device_id=device_id,
                                app_token_signature=app_token_signature,
                                app_name="moot_init")

    moot_spider.moot_init_spider(game=game)


@app.task
def moot_spider_user(user_agent, device_id, uuid, use_uuid):
    log = log_instance.beidou_create_log("moot_user")

    moot_spider = MootRunSpider(
                                redis_obj=redis_obj,
                                log=log,
                                user_agent=user_agent,
                                device_id=device_id,
                                app_token_signature=app_token_signature,
                                app_name="moot_user")

    moot_spider.moot_get_user(account=uuid, use_uuid=use_uuid)


@app.task
def moot_business_friend(account,
                         password,
                         user_agent,
                         device_id):
    log = log_instance.beidou_create_log("moot_friend")

    app_data = LoginInfo(log)

    base_header = {
        "deviceId": device_id,
        "DEVICE-TIME-ZONE-ID": "Asia/Shanghai",
        "country": "CN",
        "User-agent": user_agent,
        "version": "20140411",
        "DEVICE-TIME-ZONE-MS-OFFSET": "28800000",
        "language": "zh_CN",
        "Accept-Encoding": "gzip",
        "Host": "usw-api.moot.us",
        "Connection": "Keep-Alive"
    }

    user_no, tokens, data_login = app_data.moot_login(account=account,
                                                      password=password,
                                                      device_id=device_id,
                                                      user_agent=user_agent,
                                                      app_token_signature=app_token_signature)

    moot_friend = MootRunFriend(log=log,
                                redis_obj=redis_obj,
                                user_agent=user_agent,
                                app_name="moot_business",
                                app_token_signature=app_token_signature,
                                device_id=device_id)

    moot_friend.moot_add_friend(account=account,
                                account_user_no=user_no,
                                tokens=tokens,
                                base_header=base_header)


@app.task
def moot_business_push(account,
                       password,
                       device_id,
                       user_agent):
    log = log_instance.beidou_create_log("moot_push")

    base_header = {
        "deviceId": device_id,
        "DEVICE-TIME-ZONE-ID": "Asia/Shanghai",
        "country": "CN",
        "User-agent": user_agent,
        "version": "20140411",
        "DEVICE-TIME-ZONE-MS-OFFSET": "28800000",
        "language": "zh_CN",
        "Accept-Encoding": "gzip",
        "Host": "usw-api.moot.us",
        "Connection": "Keep-Alive"
    }

    moot_push = MootRunPush(app_name="moot_push",
                            redis_obj=redis_obj,
                            log=log,
                            user_agent=user_agent,
                            device_id=device_id,
                            app_token_signature=app_token_signature)

    app_data = LoginInfo(log)

    user_no, tokens, data_login = app_data.moot_login(account=account,
                                                      password=password,
                                                      device_id=device_id,
                                                      user_agent=user_agent,
                                                      app_token_signature=app_token_signature)

    push_account_filter = push_obj.redis_client(push_moot_user_db)

    push_uuid_filter = push_obj.redis_client(push_moot_uuid_db)

    accunt_uuid = redis_obj.redis_client(uuid_assigned_db)

    moot_push.moot_push(account=account,
                        account_user_no=user_no,
                        tokens=tokens,
                        push_account_filter=push_account_filter,
                        push_uuid_filter=push_uuid_filter,
                        is_use_account=True,
                        source_redis=accunt_uuid,
                        base_header=base_header
                        )