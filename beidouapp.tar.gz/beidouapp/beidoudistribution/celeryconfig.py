# -*-coding:utf-8-*-
import pickle
from kombu import Queue
from kombu import Exchange

BROKER_URL = 'redis://:foobared@192.168.100.186:6381/1'
CELERY_RESULT_BACKEND = 'redis://:foobared@192.168.100.186:6381/2'

CELERY_TIMEZONE = 'Asia/Shanghai'
# CELERY_RESULT_SERIALIZER = 'pickle'
# CELERY_ACCEPT_CONTENT = ['pickle']
# CELERY_TASK_SERIALIZER = 'pickle'
CELERY_IMPORTS = (
    'beidoudistribution.aminocelery',
    'beidoudistribution.ifunnycelery',
    'beidoudistribution.mootcelery',
    'beidoudistribution.tumblrcelery',
    'beidoudistribution.wegamercelery',
    'beidoudistribution.task1',
)

CELERY_QUEUES = (
    Queue('default', exchange=Exchange('default'), routing_key='default'),
    Queue('amino_init', exchange=Exchange('amino_init'), routing_key='amino_init'),
    Queue('amino_spider', exchange=Exchange('amino_spider'), routing_key='amino_spider'),
    Queue('amino_friend', exchange=Exchange('amino_friend'), routing_key='amino_friend'),
    Queue('amino_push', exchange=Exchange('amino_push'), routing_key='amino_push'),
    Queue('ifunny_spider', exchange=Exchange('ifunny_spider'), routing_key='ifunny_spider'),
    Queue('ifunny_friend', exchange=Exchange('ifunny_friend'), routing_key='ifunny_friend'),
    Queue('ifunny_push', exchange=Exchange('ifunny_push'), routing_key='ifunny_push'),
    Queue('ifunny_init', exchange=Exchange('ifunny_init'), routing_key='ifunny_init'),
    Queue('moot_spider', exchange=Exchange('moot_spider'), routing_key='moot_spider'),
    Queue('moot_friend', exchange=Exchange('moot_friend'), routing_key='moot_friend'),
    Queue('moot_push', exchange=Exchange('moot_push'), routing_key='moot_push'),
    Queue('moot_init', exchange=Exchange('moot_init'), routing_key='moot_init'),
    Queue('tumblr_spider', exchange=Exchange('tumblr_spider'), routing_key='tumblr_spider'),
    Queue('tumblr_friend', exchange=Exchange('tumblr_friend'), routing_key='tumblr_friend'),
    Queue('tumblr_push', exchange=Exchange('tumblr_push'), routing_key='tumblr_push'),
    Queue('tumblr_init', exchange=Exchange('tumblr_init'), routing_key='tumblr_init'),
    Queue('wegmers_spider', exchange=Exchange('wegmers_spider'), routing_key='wegmers_spider'),
    Queue('wegmers_friend', exchange=Exchange('wegmers_friend'), routing_key='wegmers_friend'),
    Queue('wegmers_push', exchange=Exchange('wegmers_push'), routing_key='wegmers_push'),
    Queue('wegmers_init', exchange=Exchange('wegmers_init'), routing_key='wegmers_init'),
    Queue('wegmers_test', exchange=Exchange('wegmers_test'), routing_key='wegmers_test'),
)

CELERY_ROUTES = {
    'beidoudistribution.aminocelery.amino_init_app': {'queue': 'amino_init', 'routing_key': 'amino_init'},
    'beidoudistribution.aminocelery.amino_spider_user': {'queue': 'amino_spider', 'routing_key': 'amino_spider'},
    'beidoudistribution.aminocelery.amino_business_friend': {'queue': 'amino_friend', 'routing_key': 'amino_friend'},
    'beidoudistribution.aminocelery.amino_business_push': {'queue': 'amino_push', 'routing_key': 'amino_push'},
    'beidoudistribution.fiunnycelery.ifunny_spider_user': {'queue': 'ifunny_spider', 'routing_key': 'ifunny_spider'},
    'beidoudistribution.fiunnycelery.ifunny_business_friend': {'queue': 'ifunny_friend',
                                                               'routing_key': 'ifunny_friend'},
    'beidoudistribution.fiunnycelery.ifunny_business_push': {'queue': 'ifunny_push', 'routing_key': 'ifunny_push'},
    'beidoudistribution.fiunnycelery.ifunny_init_app': {'queue': 'ifunny_init', 'routing_key': 'ifunny_init'},
    'beidoudistribution.mootcelery.moot_spider_user': {'queue': 'moot_spider', 'routing_key': 'moot_spider'},
    'beidoudistribution.mootcelery.moot_business_friend': {'queue': 'moot_friend', 'routing_key': 'moot_friend'},
    'beidoudistribution.mootcelery.moot_business_push': {'queue': 'moot_push', 'routing_key': 'moot_push'},
    'beidoudistribution.mootcelery.moot_init_app': {'queue': 'moot_init', 'routing_key': 'moot_init'},
    'beidoudistribution.tumblrcelery.tumblr_spider_user': {'queue': 'tumblr_spider', 'routing_key': 'tumblr_spider'},
    'beidoudistribution.tumblrcelery.tumblr_business_friend': {'queue': 'tumblr_friend',
                                                               'routing_key': 'tumblr_friend'},
    'beidoudistribution.tumblrcelery.tumblr_business_push': {'queue': 'tumblr_push', 'routing_key': 'tumblr_push'},
    'beidoudistribution.tumblrcelery.tumblr_init_app': {'queue': 'tumblr_init', 'routing_key': 'tumblr_init'},
    'beidoudistribution.wegamercelery.wegamer_spider_user': {'queue': 'wegamers_spider',
                                                              'routing_key': 'wegamers_spider'},
    'beidoudistribution.wegamercelery.wegamer_business_friend': {'queue': 'wegamers_friend',
                                                                  'routing_key': 'wegamers_friend'},
    'beidoudistribution.wegamercelery.wegamer_business_push': {'queue': 'wegamers_push',
                                                                'routing_key': 'wegamers_push'},
    'beidoudistribution.wegamercelery.wegamer_init_app': {'queue': 'wegamers_init', 'routing_key': 'wegamers_init'},
    'beidoudistribution.task1.add': {'queue': 'wegamers_test', 'routing_key': 'wegamers_test'},
}
