# -*-coding:utf-8-*-

from __future__ import absolute_import


from beidousynthesize.tumblr import *
from beidoulogin.login import LoginInfo
from beidoudistribution.celery import app
from beidoudatastore.appredisdatastore import RedisObject
from beidouloginstance.loginstance import BeibouLog
from beidouotherscript.tumblr_script import TumblerBaseJava
from beidouconf.baseconf.beidouredisdb import account_login_db
from beidouconf.baseconf.beidouredisconf import tumblr_push_host, tumblr_push_port, tumblr_push_password, \
    tumblr_spider_host, tumblr_spider_port, tumblr_spider_password

log_instance = BeibouLog()

push_obj = RedisObject(host=tumblr_push_host, port=tumblr_push_port, password=tumblr_push_password)

redis_obj = RedisObject(host=tumblr_spider_host, port=tumblr_spider_port, password=tumblr_spider_password)
tumblr_java = TumblerBaseJava()

@app.task
def tumblr_init_app(init):
    log = log_instance.beidou_create_log("tumblr_friend")
    tumblr_spider = TumblrRunSpider(redis_obj=redis_obj,
                                    log=log, app_name="tumblr_init")

    tumblr_spider.tumblr_init_app(init)


@app.task
def tumblr_spider_user(account):
    log = log_instance.beidou_create_log("tumblr_friend")

    tumblr_spider = TumblrRunSpider(redis_obj=redis_obj,
                                    log=log,
                                    app_name="tumblr_user")

    tumblr_spider.tumblr_spdier_user(account=account)


@app.task
def tumblr_business_friend(account, password,placement_id,context):
    log = log_instance.beidou_create_log("tumblr_friend")

    app_data = LoginInfo(log)

    header = {
        "user-agent": "Tumblr/Android/14.9.0.00",
        "x-version": "device/14.9.0.00/0/6.0.1/tumblr/",
        "x-identifier": "370f2ba6-79ee-4a75-a845-652a2c8fee9f",  # java ramdom uuid
        "x-identifier-date": "",  # timestamp
        "accept-language": "zh-CN",
        "pragma": "no-cache",
        "yx": "63bop7ata0i3i",
        "x-yuser-agent": "YMobile/1.0 (com.tumblr/14.9.0.00; Android/6.0.1; MTC20F; angler; Huawei; Nexus 6P; 5.41; "
                         "2392x1440;)",
        "di": "DI/1.0 (; ; [WIFI])",
        "x-background": "false",
        "x-s-id": "NGUxODZlODgtYTFiOS00NDFhLTkxMTUtNGYzM2IyOTE4ZjVj",  # adv_id is constant
        "x-s-id-enabled": "false",
        "authorization": "OAuth oauth_consumer_key=\"BUHsuO5U9DF42uJtc8QTZlOmnUaJmBJGuU1efURxeklbdiLn9L\", "
                         "oauth_nonce=\"-8662737014390362079\", oauth_signature=\"uwjKKmGWv0e2CfaOT8TS6%2BXpQGQ%3D\", "
                         "oauth_signature_method=\"HMAC-SHA1\", oauth_timestamp=\"1577955467\", oauth_version=\"1.0\"",
        "content-type": "application/x-www-form-urlencoded",
    }

    redis_num = redis_obj.redis_client(account_login_db)

    if not redis_num.get(account + ":login"):

        tum_login_true = app_data.tumblr_auth_email(account,
                                                    password,
                                                    header=header,
                                                    tumbler_base_java=tumblr_java)

        if tum_login_true:

            log.info("{}:{} is auth:chat".format(time.asctime(), account))

            app_data.tumblr_login_by_email(account=account,
                                           password=password,
                                           redis_num=redis_num,
                                           tumbler_base_java=tumblr_java,
                                           header=header)

            log.info("{}:{} login:chat:successful".format(time.asctime(), account))

            if not redis_num.get(account + ":uuid"):
                app_data.tumblr_user_info(account=account,
                                          redis_num=redis_num,
                                          tumbler_base_java=tumblr_java,
                                          header=header)

                log.info("{}:{} get user info:chat:successful".format(time.asctime(), account))

        redis_num.set(account + ":login", "1")

    log.info("{}:{} start push ad".format(time.asctime(), account))

    tumblr_friend = TumblrRunBusiness(log=log,
                                      redis_obj=redis_obj,
                                      app_name="tumblr_business",
                                      tumbler_base_java=tumblr_java)

    # participants = redis_num.get(account + ":uuid").decode("utf-8")

    tumblr_friend.run_tumblr_add(account=account, placement_id=placement_id,context=context)


@app.task
def tumblr_business_push(account,password):
    log = log_instance.beidou_create_log("tumblr_push")
    header = {
        "user-agent": "Tumblr/Android/14.9.0.00",
        "x-version": "device/14.9.0.00/0/6.0.1/tumblr/",
        "x-identifier": "370f2ba6-79ee-4a75-a845-652a2c8fee9f",  # java ramdom uuid
        "x-identifier-date": "",  # timestamp
        "accept-language": "zh-CN",
        "pragma": "no-cache",
        "yx": "63bop7ata0i3i",
        "x-yuser-agent": "YMobile/1.0 (com.tumblr/14.9.0.00; Android/6.0.1; MTC20F; angler; Huawei; Nexus 6P; 5.41; "
                         "2392x1440;)",
        "di": "DI/1.0 (; ; [WIFI])",
        "x-background": "false",
        "x-s-id": "NGUxODZlODgtYTFiOS00NDFhLTkxMTUtNGYzM2IyOTE4ZjVj",  # adv_id is constant
        "x-s-id-enabled": "false",
        "authorization": "OAuth oauth_consumer_key=\"BUHsuO5U9DF42uJtc8QTZlOmnUaJmBJGuU1efURxeklbdiLn9L\", "
                         "oauth_nonce=\"-8662737014390362079\", oauth_signature=\"uwjKKmGWv0e2CfaOT8TS6%2BXpQGQ%3D\", "
                         "oauth_signature_method=\"HMAC-SHA1\", oauth_timestamp=\"1577955467\", oauth_version=\"1.0\"",
        "content-type": "application/x-www-form-urlencoded",
    }

    tumblr_push = TumblrPush(app_name="tumblr_push",
                             redis_obj=redis_obj,
                             log=log,
                             push_obj=push_obj,
                             tumbler_base_java=tumblr_java)

    app_data = LoginInfo(log)

    redis_num = redis_obj.redis_client(account_login_db)

    if not redis_num.get(account + ":login"):

        tum_login_true = app_data.tumblr_auth_email(account,
                                                    password,
                                                    header=header,
                                                    tumbler_base_java=tumblr_java)

        if tum_login_true:

            log.info("{}:{} is auth:chat".format(time.asctime(), account))

            app_data.tumblr_login_by_email(account=account,
                                           password=password,
                                           redis_num=redis_num,
                                           tumbler_base_java=tumblr_java,
                                           header=header)

            log.info("{}:{} login:chat:successful".format(time.asctime(), account))

            if not redis_num.get(account + ":uuid"):
                app_data.tumblr_user_info(account=account,
                                          redis_num=redis_num,
                                          tumbler_base_java=tumblr_java,
                                          header=header)

                log.info("{}:{} get user info:chat:successful".format(time.asctime(), account))

        redis_num.set(account + ":login", "1")

    log.info("{}:{} start push ad".format(time.asctime(), account))

    participants = redis_num.get(account + ":uuid").decode("utf-8")

    tumblr_push.run_tumblr_push(account=account, participants=participants)
