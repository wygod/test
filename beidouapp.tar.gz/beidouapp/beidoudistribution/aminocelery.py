# -*-coding:utf-8-*-

from __future__ import absolute_import
# import multiprocessing
# from multiprocessing.pool import ThreadPool

from beidousynthesize.amino import *
from beidoudistribution.celery import app

log_instance = BeibouLog()

push_obj = RedisObject(host=amino_push_host, port=amino_push_port, password=amino_push_password)

redis_obj = RedisObject(host=amino_spider_host, port=amino_spider_port, password=amino_spider_password)


# thread_pool = ThreadPool(multiprocessing.cpu_count())
@app.task
def amino_init_app(ndcdeviceid,
                   smdeviceid,
                   user_agent):
    log = log_instance.beidou_create_log("amino_spider_user")

    amino_spider = AminoSpider(ndcdeviceid=ndcdeviceid,
                               smdeviceid=smdeviceid,
                               log=log,
                               user_agent=user_agent)

    amino_business = AminoBusiness(ndcdeviceid=ndcdeviceid,
                                   smdeviceid=smdeviceid,
                                   log=log,
                                   user_agent=user_agent)

    amino_spider_info = AminoSpiderInfo(amino_spider=amino_spider,
                                        amino_business=amino_business,
                                        amino_ndc=ndcdeviceid,
                                        amino_sm=smdeviceid,
                                        amino_user_agent=user_agent,
                                        log=log,
                                        redis_obj=redis_obj)

    amino_spider_info.run_init()


@app.task
def amino_spider_user(account,
                      password,
                      ndcdeviceid,
                      smdeviceid,
                      user_agent):
    log = log_instance.beidou_create_log("amino_spider_user")

    amino_spider = AminoSpider(ndcdeviceid=ndcdeviceid,
                               smdeviceid=smdeviceid,
                               log=log,
                               user_agent=user_agent)

    amino_business = AminoBusiness(ndcdeviceid=ndcdeviceid,
                                   smdeviceid=smdeviceid,
                                   log=log,
                                   user_agent=user_agent)

    amino_spider_info = AminoSpiderInfo(amino_spider=amino_spider,
                                        amino_business=amino_business,
                                        amino_ndc=ndcdeviceid,
                                        amino_sm=smdeviceid,
                                        amino_user_agent=user_agent,
                                        log=log,
                                        redis_obj=redis_obj)

    amino_spider_info.add_follow_user(account=account, password=password)


@app.task
def amino_business_friend(account,
                          password,
                          ndcdeviceid,
                          smdeviceid,
                          user_agent):
    log = log_instance.beidou_create_log("amino_friend")

    amino_friend = AminoBusinessFriend(log=log, redis_obj=redis_obj)

    amino_friend.amino_friend(account=account,
                              password=password,
                              amino_ndc=ndcdeviceid,
                              amino_smd=smdeviceid,
                              user_agent=user_agent)


@app.task
def amino_business_push(account,
                        password,
                        ndcdeviceid,
                        smdeviceid,
                        user_agent):
    log = log_instance.beidou_create_log("amino_spider_push")

    amino_spider = AminoSpider(ndcdeviceid=ndcdeviceid,
                               smdeviceid=smdeviceid,
                               log=log,
                               user_agent=user_agent)

    amino_business = AminoBusiness(ndcdeviceid=ndcdeviceid,
                                   smdeviceid=smdeviceid,
                                   log=log,
                                   user_agent=user_agent)

    amino_push = AminoPush(amino_spider=amino_spider,
                           amino_business=amino_business,
                           amino_ndc=ndcdeviceid,
                           amino_sm=smdeviceid,
                           amino_user_agent=user_agent,
                           log=log,
                           redis_obj=redis_obj,
                           push=push_obj)

    amino_push.amino_push_run(account=account, password=password)
