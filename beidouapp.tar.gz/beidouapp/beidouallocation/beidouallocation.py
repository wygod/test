# -*- coding:utf-8 -*-
import uuid
import random

from beidouconf.baseconf.beidouredisdb import *


class BeiDouBase:

    def __init__(self, redisObject):

        self.data = redisObject.redis_client(data_db)

        self.uuid_data = redisObject.redis_client(uuid_data_db)

        self.uuid_member = redisObject.redis_client(uuid_db)

        self.account_uuid = redisObject.redis_client(account_assign_db)

        self.account_hash = redisObject.redis_client(uuid_assigned_db)

        self.account_login = redisObject.redis_client(account_login_db)

    def base_multi_save_func(self, func, game_list_data):#,thread_pool):
        # open_func

        if len(game_list_data) > 0:

            for x in game_list_data:

                func(x[0], x[1])
                # thread_pool.apply_async(func, (x[0], x[1]))

    def base_data_save_func(self, args1, args2):
        # 存数据到redis

        if not self.data.get(args1):

            user_uuid = self.base_change_uuid()

            variable = self.uuid_member.smembers("uuidcontrol")

            if not variable or user_uuid not in variable:
                self.uuid_member.sadd("uuidcontrol", user_uuid)

            self.uuid_data.hset(user_uuid, args1, args2)

            self.data.set(args1, args2)

    def base_process_lock(self, user_name, dispatch_data=None):

        # 分配账号和数据

        uuid_list = dispatch_data

        if not uuid_list:
            uuid_list = self.uuid_member.smembers("uuidcontrol")

        can_use_uuid = list(filter(lambda x: True if not self.account_uuid.get(x) else False, uuid_list))

        user_name_list = [i_user for i_user in user_name if self.account_hash.hlen(i_user[0]) == 0]

        user_len = [self.account_hash.hlen(i_user[0]) for i_user in user_name if self.account_hash.hlen(i_user[0]) != 0]

        min_num = max(user_len) if len(user_len) > 0 else 0

        if 0 < len(user_name_list) < len(user_name):

            if len(can_use_uuid) > 0:

                if len(user_name_list) > 1:

                    self.base_shuffle_random(user_name_list, can_use_uuid)

                else:

                    if len(can_use_uuid) > min_num:

                        temp_list = can_use_uuid[:min_num]

                        for i_temp_ca in temp_list:
                            self.account_uuid.set(i_temp_ca, "1")

                            self.account_hash.hset(user_name_list[0], i_temp_ca, "1")

                        other_list = can_use_uuid[min_num:]

                        self.base_shuffle_random(user_name, other_list)

                    else:

                        for i_temp_ca in can_use_uuid:
                            self.account_uuid.set(i_temp_ca, "1")

                            self.account_hash.hset(user_name_list[0], i_temp_ca, "1")
        else:

            if len(can_use_uuid) > 0:
                self.base_shuffle_random(user_name, can_use_uuid)

    def base_change_uuid(self):

        # 产生uuid

        user_uuid_list = self.uuid_member.smembers("uuidcontrol")

        user_uuid = str(uuid.uuid4())

        if user_uuid_list:

            uuid_init = [i_uuid for i_uuid in
                         map(lambda x: (x.decode("utf-8"), self.uuid_data.hlen(x)), user_uuid_list) if
                         i_uuid[1] < 2000]

            if len(uuid_init) != 0:
                user_uuid = uuid_init[0][0]

        return user_uuid

    def base_shuffle_random(self, user_name_list, uuid_list):

        if len(uuid_list) > 0:

            if len(uuid_list) < len(user_name_list):

                ran_use = random.sample(user_name_list, len(uuid_list))

                for i_use in range(len(uuid_list)):
                    self.account_uuid.set(uuid_list[i_use], "1")

                    self.account_hash.hset(ran_use[i_use], uuid_list[i_use], "1")
            else:

                for i_use in range(len(uuid_list)):
                    self.account_uuid.set(uuid_list[i_use], "1")

                    self.account_hash.hset(user_name_list[i_use % len(user_name_list)], uuid_list[i_use], "1")


class AminoDispatch(BeiDouBase):

    def __init__(self, redisObject):

        super().__init__(redisObject)

        self.account_filter = redisObject.redis_client(account_filter_db)

        self.account_url = redisObject.redis_client(account_url_filter_db)

        self.url_filter = redisObject.redis_client(url_filter_db)

    def amino_topic_save_func(self, data, redis_num, topic_name):

        if data:
            redis_num.hset(topic_name, data[1], data[0])

    def amino_topic_multi(self, game_list_data, func, redis_num, topic_name):#, thread_pool):
        # 多线程存储

        if len(game_list_data) > 0:

            for x in game_list_data:

                func(x, redis_num, topic_name)
                # thread_pool.apply_async(func, (x, redis_num, topic_name))

    def amino_data_save_func(self, args1, args2):
        # 存数据到redis

        if not self.data.get(args1):

            variable = self.uuid_member.smembers("uuidcontrol")

            if not variable or args2 not in variable:
                self.uuid_member.sadd("uuidcontrol", args2)

            self.uuid_data.hset(args2, args1, "1")

            self.data.set(args1, args2)

    def amino_save_func(self, account, data, value="1"):

        # value 1，账号能用，value 0 账号加入最大数目社区

        self.account_url.hset(account, data, value)

        self.url_filter.set(data, value)

        if not self.account_filter.get(account):
            self.account_filter.set(account, value)

    def amino_process_lock(self, amino_account_list, dispatch_data=None):

        if dispatch_data:
            super().base_process_lock(user_name=[i[0] for i in amino_account_list], dispatch_data=dispatch_data)

        super().base_process_lock(user_name=[i[0] for i in amino_account_list])

    def delete_account(self, redis_object, account, log):#,, thread_pool):

        # 如果账号不能使用时，删除账号下数据数据，手动操作

        amino_init_filter_user = redis_object.redis_client(4)

        amino_init_account_url = redis_object.redis_client(11)

        amino_init_filter_url = redis_object.redis_client(12)

        account_url_list = amino_init_account_url.hgetall(account)

        def del_redis(redis_conn, key_url):

            redis_conn.delete(key_url)

        if account_url_list:

            for sub_key in account_url_list:

                del_redis(amino_init_filter_url, sub_key)
                # thread_pool.apply_async(del_redis, (amino_init_filter_url, sub_key))

            amino_init_account_url.hdel(account)

            amino_init_filter_user.delete(account)

            log.info("delete {} url successful".format(account))


class WegamerDispatch:

    def __init__(self, redis_obj):

        self.redis_object = redis_obj

        self.redis_conn = redis_obj.redis_client(account_login_db)

    def get_user_(self, func, data, account, redis_conn):#, thread_pool):

        if len(data) > 0:

            for x in data:

                func(x[0], account, redis_conn)
                # thread_pool.apply_async(func, (x[0], account, redis_conn))

    def write_data(self, data, account, redis_conn):

        if account:

            if not redis_conn.hget(account, data):
                redis_conn.hset(account, data, 0)

        else:

            if not redis_conn.get(data[0]):
                redis_conn.set(data[0], data[1])
