# -*-coding:utf-8-*-
import jpype

from beidouconf.baseconf.beidoubaseversion import jar_java,jvm


class TumblerBaseJava:

    def __init__(self):

        for i_java in jar_java:

            jpype.addClassPath(i_java)

        if not jpype.isJVMStarted():
            jpype.startJVM(jvm, "-Xmx1024M", "-Xms512M")

        java_class = jpype.JClass('com.xp.lib.RequestHeaderSdk')

        self.request_header_sdk = java_class()

    def tumbler_make_login(self, email, password):

        handle_string = self.request_header_sdk.makeLogin(email, password)

        return handle_string

    def tumbler_sig(self, handle_str, args=""):

        sig = self.request_header_sdk.makeSignature(handle_str, args)

        return sig

    def tumbler_oauth_nonce(self):

        oauth_nonce = str(self.request_header_sdk.getPyOauthNonce())

        return oauth_nonce

    def tumbler_make_user_info(self, oauth_token):

        return self.request_header_sdk.makeGetUserInfo(oauth_token)

    def tumbler_make_auth_url(self, email):

        return self.request_header_sdk.makeAuthUrl(email)

    def tumbler_login(self, email, password):

        login_string = self.request_header_sdk.makeLogin(email, password)

        return self.tumbler_sig(login_string)

    def tumbler_following_list(self, token, offset):

        return self.request_header_sdk.makeGetFollowing(token, offset)

    def tumbler_follow_user(self, oauth_token, url, placement_id, context):

        return self.request_header_sdk.makeFollowSomeone(oauth_token, url, placement_id, context)

    def tumbler_blog(self, oauth_token, username, offset):

        return self.request_header_sdk.makeGetSomeoneBlogs(oauth_token, username, offset)

    def tumbler_blog_comment(self, oauth_token, username, blog_id):

        return self.request_header_sdk.makeGetBlogComments(oauth_token, username, blog_id)

    def tumbler_make_get_info(self, oauth_token, username):

        return self.request_header_sdk.makeGetInfo(oauth_token, username)

    def tumbler_participant_info(self, oauth_token, participants, q):

        return self.request_header_sdk.makeParticipantInfo(oauth_token, participants, q)

    def tumbler_participant(self):

        return self.request_header_sdk.getM_Participant()

    def tumbler_get_m(self):

        return self.request_header_sdk.getM_q()

    def tumbler_send_message(self, oauth_token, msg, participants, q, context="TEXT"):

        return self.request_header_sdk.makeSendMessage(oauth_token, msg, participants, q, context)

    def tumbler_timestamp(self):

        return self.request_header_sdk.getPyTimestamp()
