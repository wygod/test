# -*-coding:utf-8-*-
import execjs
from jpype import *

from beidouconf.baseconf.beidoubaseversion import jvm
from beidoudataclean.appdataclean import MootCleanData
from beidouallocation.beidouallocation import BeiDouBase
from beidoudatastore.appredisdatastore import RedisObject
from beidouconf.baseconf.beidoubaseversion import jar_java
from beidouconf.baseconf.beidouredisconf import moot_spider_host,\
    moot_spider_password, moot_spider_port


class MootOtherJavaScript:

    def __init__(self):

        print(jvm)
        self.start_path = jvm


        for i in jar_java:

            addClassPath(i)

        if not isJVMStarted():
            startJVM(self.start_path)


    def signature(self):

        java_init_class = "com.chatgum.testmodule.Test"

        if not isJVMStarted():
            startJVM(self.start_path)

        java_class = JClass(java_init_class)

        java_object = java_class()

        data = java_object.makeSig()

        return data

    def encode_password(self, password):

        java_init_class = "com.chatgum.testmodule.Test"

        if not isJVMStarted():
            startJVM(self.start_path, "-ea")

        java_class = JClass(java_init_class)
        java_object = java_class()

        data = java_object.encodePassword(password)

        return data

    def credential(self, token):

        java_init_class = "com.moot.credential.MootCredential"

        if not isJVMStarted():
            startJVM(self.start_path, "-ea")

        java_class = JClass(java_init_class)
        java_object = java_class()

        data = java_object.a(token)

        return data

    def make_authorization(self, account, refresh_taken):

        java_init_class = "com.chatgum.testmodule.Test"

        if not isJVMStarted():
            startJVM(self.start_path, "-ea")

        java_class = JClass(java_init_class)
        java_object = java_class()
        data = java_object.makeAuthorization(account, refresh_taken)

        return data


class MootOtherJScript:

    def __init__(self):

        self.clean_data = MootCleanData()

        self.data_base = RedisObject(moot_spider_host,
                                     moot_spider_password,
                                     moot_spider_port)

        self.write_data = BeiDouBase(self.data_base)

    def moot_exec_js(self, file_path):
        f = open(file_path, 'r', encoding='UTF-8')

        line = f.readline()

        signature = ''

        while line:
            signature = signature + line

            line = f.readline()

        return signature

    def moot_product_verify(self, file_path, b_tg):
        signature_content = self.moot_exec_js(file_path)

        ctx = execjs.compile(signature_content)

        get_signature = ctx.call('getSignature', b_tg)

        return get_signature

