# -*-coding:utf-8-*-
import json
import socket
import hashlib
import random

from beidoudatastore.appredisdatastore import RedisObject
from beidouallocation.beidouallocation import WegamerDispatch
from beidouconf.beidoubusinessconf.businesstextconf import wegamers_context
from beidouconf.baseconf.beidouredisconf import wegamers_spider_host, \
    wegamers_spider_port, wegamers_spider_password


class WeGameSocket:

    def __init__(self,host, port):

        self.client = socket.socket(socket.AF_INET, socket.SOCK_STREAM)

        self.client.connect((host, port))

    def wegamer_reauth(self,iuin,sessionKey):

        return "ReAuth/;{}/;{}\n".format(iuin,sessionKey).encode("utf-8")

    def wegamer_pre_message(self,iuin,text="hi"):
        #send_pre_message

        return "SendMessage/;{}/;{}\n".format(iuin,text).encode("utf-8")

    def wegamer_group(self,room,user_list):
        #add_group

        return "InviteChatRoom/;{}/;{}\n".format(room,user_list).encode("utf-8")

    def wegamer_send_video(self, uid, media_length, media_play_length,
                   thumb_img_length, pc_media_md5, pc_media_url,
                   pc_thumb_img_md5, pc_thumb_img_url):

        video_info = "SendVideo/;{}/;{}/;{}/;{}/;" \
                     "{}/;{}/;{}/;{}/;\n".format(uid,
                                                 media_length,
                                                 media_play_length,
                                                 thumb_img_length,
                                                 pc_media_md5,
                                                 pc_media_url,
                                                 pc_thumb_img_md5,
                                                 pc_thumb_img_url).encode("utf-8")

        print(video_info)

        return video_info

    def wegamer_send_message(self, data, state=False):
        #send_message

        self.client.send(data)

        if state:

            self.wegamer_recv_message()

    def wegamer_recv_message(self):
        #recv_message

        return self.client.recv(1024)

    def wegamer_conntion(self, message, state):
        #conntion_message

        self.wegamer_send_message(message, state)

        data = self.wegamer_recv_message()

        return data

    def close(self):

        self.client.close()




class WeGameRun:

    def invite_frineds_group(self, groupid):

        init_data = "NewInitData/;81012A03B10000000000000001040600000002A801810118029C0000000000000000188101F3FF0C0000000000000001040100000002040000000001188101F2FF0C0000000000000001040200000002040000000002188101F1FF0C0000000000000001040300000002040000000003188101EFFF0C0000000000000001040500000002040000000004188101EDFF0C0000000000000001040700000002040000000005188101ECFF0C00000000000000010408000000020400000000/;\n"

        if groupid:

            init_data = "NewInitData/;{}/;\n".format(groupid)

        return init_data.encode("utf-8")

    def add_friend(self, user_id, friend_text):

        return "AddFriend/;{}/;{}\n".format(user_id,friend_text).encode("utf-8")


class WegamerBusiness:

    def __init__(self, log, we_gamer_socket):

        self.log = log

        self.we_run = WeGameRun()

        self.we_client = we_gamer_socket

        self.redis_save = RedisObject(host=wegamers_spider_host,
                                      port=wegamers_spider_port,
                                      password=wegamers_spider_password)

        self.bei_dou_base = WegamerDispatch(self.redis_save)

    def get_all_data(self, message, state):

        self.we_client.send_message(message, state)

        data = b''

        while True:

            data = data + self.we_client.recv_message()

            if data.find('\n'.encode("UTF-8")) != -1:

                break

        return data

    def get_user_from(self, account, redis_conn,room_conn):

        in_key = None

        while True:

            get_group = self.we_run.invite_frineds_group(in_key)

            add_detail = self.get_all_data(get_group, state=False)

            add_f = json.loads(add_detail.decode("utf-8"))

            if add_f["iContinueFlag"] == 0:

                break

            room_list = add_f["ChatRoomList"]

            room_list_room = [(i_room.split("/;")[1],i_room.split("/;")[0].split("@")[0]) for i_room in room_list]

            user_list = add_f["UserList"][1:]

            self.bei_dou_base.get_user_(func=self.bei_dou_base.write_data,
                                        data=room_list_room,
                                        redis_conn=room_conn,
                                        account=account)

            self.bei_dou_base.get_user_(func=self.bei_dou_base.write_data,
                                        data=user_list,
                                        redis_conn=redis_conn,
                                        account=account)

            in_key = add_f["tCurrentSynckey"]

    def join_group(self, account, room_name, redis_user, redis_conn):

        data_user = redis_user.hgetall(account)

        room_id = redis_conn.keys()

        room_base_id = list(filter(lambda x:True if x == room_name else False,[i_key.decode("utf-8") for i_key in room_id]))

        user_list = [i_u.decode("utf-8") for i_u in data_user.keys()]

        pre = len(user_list) % 20

        if len(room_base_id) == 0:

            raise Exception("room name must be given")

        if pre != 0:

            index = int(len(user_list) / 20)

            for i in range(index):

                temp_user = ",".join(user_list[(i * 20):((i + 1) * 20)])

                self.we_client.add_group(room_base_id[0], temp_user)

            temp_user = ",".join(user_list[(index * 20):len(user_list)])

            self.we_client.add_group(room_base_id[0], temp_user)

        else:

            index = int(len(user_list) / 20)

            for i in range(index):

                temp_user = ",".join(user_list[(i * 20):((i + 1) * 20)])

                self.we_client.add_group(room_base_id[0], temp_user)

    def add_friend_to_my(self, value):

        add_friend_detail = self.we_run.add_friend(value[1].decode("utf-8"), wegamers_context)

        add_detail = self.we_client.wegamer_conntion(add_friend_detail, state=False)

        add_result = json.loads(add_detail.decode("utf-8"))

        if add_result["ret"] != 0:

            return False

        return True

    # def add_friend_to_my(self, account):
    #
    #     redis_uuid_and_data = self.redis_save.get_redis_object().redis_client(3)
    #
    #     redis_account_data = self.redis_save.get_redis_object().redis_client(6)
    #
    #     redis_account_user = self.redis_save.get_redis_object().redis_client(7)
    #
    #     uuid_list = redis_account_data.hgetall(account)
    #
    #     for uuid_index, uuid_value in uuid_list.items():
    #
    #         if not redis_account_user.get(uuid_index):
    #
    #             temp_uuid = uuid_index.decode("utf-8")
    #
    #             user_id_list = redis_uuid_and_data.hgetall(temp_uuid)
    #
    #             user_id_len = redis_uuid_and_data.hlen(temp_uuid)
    #
    #             user_temp = 0
    #
    #             for user_index, value in user_id_list.items():
    #
    #                 user_temp = user_temp + 1
    #
    #                 if not redis_account_user.get(user_index):
    #
    #                     add_friend_detail = self.we_run.add_friend(value.decode("utf-8"),random.choice(tcp_friend_text))
    #
    #                     add_detail = self.we_client.conntion_message(add_friend_detail,state=False)
    #
    #                     add_result = json.loads(add_detail.decode("utf-8"))
    #
    #                     if add_result["ret"] != 0:
    #
    #                         break
    #
    #                     redis_account_user.set(value.decode("utf-8"),"1")
    #
    #             if user_id_len == user_temp:
    #
    #                 redis_account_user.set(uuid_index,1)
