# -*-coding:utf-8-*-

import time
import copy

from beidouconf.baseconf.beidouredisdb import *


class BeiDouBusiness:

    def __init__(self,
                 redisObject,
                 log,
                 app_name,
                 push_account_filter=None,
                 push_uuid_filter=None):

        self.is_push = False

        self.log = log

        self.app_name = app_name

        self.uuid_data = redisObject.redis_client(uuid_data_db)

        self.uuid_member = redisObject.redis_client(uuid_db)

        self.account_login = redisObject.redis_client(account_login_db)

        if push_account_filter and push_uuid_filter:

            self.account_filter = push_account_filter

            self.account_uuid_filter = push_uuid_filter

            self.is_push = True

        else:

            self.account_uuid = redisObject.redis_client(uuid_assigned_db)

            self.account_filter = redisObject.redis_client(assigned_friend_db)

            self.account_uuid_filter = redisObject.redis_client(account_uuid_assigned_db)

    def beidou_follow(self,
                      account,
                      uuid_keys,
                      func):

        first_temp_len = self.account_uuid_filter.get(uuid_keys)

        uuid_filter_len = first_temp_len.decode("utf-8") if first_temp_len else 0

        temp_len = self.uuid_data.hlen(uuid_keys)

        if uuid_filter_len < temp_len:

            temp_i = 0

            for (user_key_id, user_key_value) in self.uuid_data.hgetall(uuid_keys).items():

                if not self.account_filter.get(user_key_id):

                    self.log.info(
                        "{}:{}:push:{}:try to start push ad to {}".format(time.asctime(),
                                                                          self.app_name,
                                                                          account,
                                                                          user_key_id))

                    status = func((user_key_id, user_key_value,uuid_keys))

                    if status:

                        temp_i = temp_i + 1

                        user_time = time.strftime('%Y-%m-%d %H:%M:%S', time.localtime(time.time()))

                        self.account_filter.set(user_key_id, user_time)

                        self.log.info("{}:{}:push:{}:try to start push ad to {}".format(time.asctime(),
                                                                                        self.app_name,
                                                                                        account,
                                                                                        user_key_id))

            if temp_len == temp_i and temp_len > 1900:
                self.account_uuid_filter.set(uuid_keys, temp_i)

                self.log.info(
                    "{}:{}:push:{}:try to start push ad to {}".format(time.asctime(), self.app_name, account,
                                                                      uuid_keys))

    def base_add_user(self,
                      account,
                      func,
                      is_use_account=False,
                      source_redis=None):

        if self.is_push:

            if is_use_account:

                if source_redis:

                    init_account_have_user = source_redis.hgetall(account)

                    if init_account_have_user:

                        for user_id_keys, user_id_user in init_account_have_user.items():
                            self.beidou_follow(account=account, uuid_keys=user_id_keys, func=func)

                else:

                    raise Exception("data must be given")

            else:

                init_account_have_user = self.uuid_data.smembers("uuidcontrol")

                if init_account_have_user:

                    self.log.info("{}:{}:push:{}:try to start push ad".format(time.asctime(),
                                                                              self.app_name,
                                                                              account))

                    for user_id_keys in init_account_have_user:
                        self.beidou_follow(account=account, uuid_keys=user_id_keys, func=func)

                    self.log.info("{}:{}:push:{}:try to start push ad finish".format(time.asctime(),
                                                                                     self.app_name,
                                                                                     account))
        else:

            init_account_have_user = self.account_uuid.hgetall(account)

            if init_account_have_user:

                self.log.info("{}:{}:push:{}:try to start add friend".format(time.asctime(),
                                                                             self.app_name,
                                                                             account))

                for user_id_keys, user_id_user in init_account_have_user.items():
                    self.beidou_follow(account=account, uuid_keys=user_id_keys, func=func)

                self.log.info("{}:{}:push:{}:try to start add friend".format(time.asctime(),
                                                                             self.app_name,
                                                                             account))
