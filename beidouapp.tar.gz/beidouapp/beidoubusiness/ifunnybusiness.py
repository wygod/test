# -*-coding:utf-8-*-

import ssl
import time
import json
import random
import requests
from datetime import datetime
from urllib.parse import urlencode
from websocket import create_connection
from requests_toolbelt import MultipartEncoder

from beidoudataclean.appdataclean import IfunnyCleanData

from beidouconf.beidoubusinessconf.businesstextconf import ifunny_context


class IfunnyBusiness:

    def __init__(self, base_authorization, log, user_agent):

        self.log = log

        self.user_agent = user_agent

        self.clean_data = IfunnyCleanData()

        self.header = {
            "accept-language": "zh-CN",
            "applicationstate": "1",
            "accept": "application/json,image/webp,video/mp4",
            "ifunny-project-id": "iFunny",
            "accept-encoding": "gzip",
            "user-agent": user_agent
        }

        self.base_authorization = base_authorization

        self.header["authorization"] = self.base_authorization


    def ifunny_subscribers(self,
                           user_id,
                           authorization_bearer):

        # 追随某个人

        self.log.info("{}:get {}:successful".format(time.asctime(), user_id))

        subscribers_url = "https://api.ifunny.mobi/v4/users/{}/subscribers".format(user_id)

        gmt_format = '%a, %d %b %Y %H:%M:%S GMT'

        subscribers_header = {
            "applicationstate": "1",
            "authorization": "Bearer {}".format(authorization_bearer),
            "accept-language": "zh-Hans-CN",
            "accept": "application/json,image/webp,video/mp4",
            "ifunny-project-id": "iFunny",
            "accept-encoding": "gzip",
            "if-modified-since": datetime.utcnow().strftime(gmt_format),
            "user-agent": self.user_agent
        }

        subscribers_data = requests.put(url=subscribers_url, headers=subscribers_header, verify=False)

        self.log.info("{}:get {} requests code {}".format(time.asctime(), user_id, subscribers_data.status_code))

        return json.loads(subscribers_data.text)

    def ifunny_chat_id(self,
                       access_token,
                       user_id):

        # 获取聊天的charUrl,

        self.log.info("{}:get {} chatUrl".format(time.asctime(), user_id))

        chat_url = "https://api.ifunny.mobi/v4/chats"

        chat_header = {
            "accept": "application/json,image/webp,video/mp4",
            "accept-language": "zh-CN",
            "ifunny-project-id": "iFunny",
            "applicationstate": "1",
            "authorization": "Bearer {}".format(access_token),
            "accept-encoding": "gzip",
            "user-agent": self.user_agent
        }

        m = MultipartEncoder(
            fields={
                "chat_type": "chat",
                "users": user_id
            })

        chat_header["content-type"] = m.content_type

        send_message = requests.post(url=chat_url, headers=chat_header, data=m, verify=False)

        if send_message.status_code == 200:
            self.log.info("{}:get {} chatUrl:successful".format(time.asctime(), user_id))

            chat_url_session = json.loads(send_message.text)["data"]

            return chat_url_session["chatUrl"]

        return None

    def ifunny_message(self,
                       myself,
                       user_id,
                       access_token,
                       bearer,
                       redis_con,
                       new=None):

        # 发送信息给某一个人

        self.log.info("{}:{} send message to {} chatUrl".format(time.asctime(), myself, user_id))

        i_funny_message_url = "wss://ws-afb3a55b-8275-4c1e-aea8-309842798187.sendbird.com/?p=Android&pv=27&sv=3.0.97&ai=AFB3A55B-8275-4C1E-AEA8-309842798187&user_id={}&access_token={}".format(
            myself, access_token)

        i_funny_message_header = {
            "User-Agent": "Jand/3.0.97",
            "Request-Sent-Timestamp": int(time.time() * 1000),
            "Upgrade": "websocket",
            "Connection": "Upgrade",
            "Sec-WebSocket-Version": "13",
            "Host": "ws-afb3a55b-8275-4c1e-aea8-309842798187.sendbird.com",
            "Accept-Encoding": "gzip"
        }

        bear_ = redis_con.hget(myself + ":chat_id", user_id)

        if not bear_:

            bear_ = self.ifunny_chat_id(bearer, user_id)

            if bear_:

                redis_con.hset(myself + ":chat_id", user_id, bear_)

            else:

                bear_ = None

        else:

            bear_ = bear_.decode("utf-8")

        self.log.info("{}:{} send message to {} chatUrl {}".format(time.asctime(), myself, user_id, bear_))

        if bear_:

            ws = create_connection(i_funny_message_url, headers=i_funny_message_header,
                                   sslopt={"cert_reqs": ssl.CERT_NONE})

            data = ws.recv()

            t = int(time.time() * 1000)


            if new:
                ts = new

            i_funny_message_data = "MESG{\"channel_url\": \"" + \
                                   bear_ + "\",\"message\": \"" + \
                                   ifunny_context + "\", \"data\": \"{\\\"local_id\\\":" + \
                                   str(random.randint(111111111, 999999999)) \
                                   + "}\", \"mention_type\": \"users\", \"req_id\": \"" \
                                   + str(t) + "\"}\n"

            ws.send(i_funny_message_data)

            data_next = ws.recv()

            ws.close()

            self.log.info("{}:{} send message to {} :successful".format(time.asctime(), myself, user_id, bear_))

            return True

        else:

            self.log.info("{}:{} send message to {} : fail".format(time.asctime(), myself, user_id, bear_))

            return False

    def ifuuny_get_key(self,
                       myself,
                       access_token,
                       redis_conn):

        # 获取用户聊天的key

        url = "wss://ws-afb3a55b-8275-4c1e-aea8-309842798187.sendbird.com/?p=Android&pv=22&sv=3.0.97&ai=AFB3A55B-8275-4C1E-AEA8-309842798187&user_id={}&access_token={}".format(
            myself, access_token)

        header = {
            "User-Agent": "Jand/3.0.97",
            "Request-Sent-Timestamp": str(int(time.time() * 1000)),
            "Upgrade": "websocket",
            "Connection": "Upgrade",
            "Sec-WebSocket-Key": "H93uS6zXIpyksflSJO7Msw==",
            "Sec-WebSocket-Version": "13",
            "Host": "ws-afb3a55b-8275-4c1e-aea8-309842798187.sendbird.com",
            "Accept-Encoding": "gzip"
        }

        try:

            ws = create_connection(url, headers=header, sslopt={"cert_reqs": ssl.CERT_NONE})

            data = ws.recv()

            key = json.loads(data.replace("LOGI", ""))["key"]

            redis_conn.set(myself + ":account_key", key)

            ws.close()

            self.log.info("{} get Key:{}".format(myself, key))

        except Exception as e:

            self.log.info("{} get Key:fail".format(myself))

    def ifunny_photo_object(self,
                            myself,
                            redis_conn,
                            chat_group_curl,
                            photo_path, photo_name,
                            post_type="video/mp4"):

        # 生成上传文件的地址

        self.log.info("{} try to upload file to server".format(myself))

        key = redis_conn.get(myself + ":account_key").decode("utf-8")

        video_host = "https://api-afb3a55b-8275-4c1e-aea8-309842798187.sendbird.com/v3/storage/file"

        header_video = {
            "accept": "application/json",
            "user-agent": "Jand/3.0.97",
            "sendbird": "Android,22,3.0.97,AFB3A55B-8275-4C1E-AEA8-309842798187",
            "session-key": key,
            "request-sent-timestamp": str(int(time.time() * 1000)),
            "accept-encoding": "gzip"
        }

        def open_photo(file_path):

            open_object = open(file_path, "rb").read()

            photo_size = open_object.__sizeof__()

            return open_object, photo_size

        photo_object, size_of = open_photo(photo_path + photo_name)

        m = MultipartEncoder(
            fields={
                "file": (photo_name, photo_object, post_type),
                "thumbnail1": (None, "780,780", "text/plain; charset=utf-8"),
                "thumbnail2": (None, "320,320", "text/plain; charset=utf-8"),
                "channel_url": (None, chat_group_curl, "text/plain; charset=utf-8")
            })

        header_video['Content-Type'] = m.content_type

        try:

            da = requests.post(url=video_host, headers=header_video, data=m, verify=False)

            d_text = json.loads(da.text)

            send_photo = "FILE{\"channel_url\":\"" + chat_group_curl + "\",\"url\":\"" + d_text["url"] + "\"" + \
                         ",\"name\":\"" + photo_name + "\",\"type\": \"" + post_type + "\",\"size\":" + str(size_of) + \
                         ",\"custom\":\"{\\\"local_id\\\":" + str(random.randint(111111111, 999999999)) + \
                         "}\",\"thumbnails\":[{\"real_height\":" + str(d_text["thumbnails"][0]["real_height"]) + \
                         ",\"url\":\"" + d_text["thumbnails"][0]["url"] + \
                         "\",\"height\":" + str(d_text["thumbnails"][0]["height"]) + \
                         ",\"width\":" + str(d_text["thumbnails"][0]["width"]) + \
                         ",\"real_width\":" + str(d_text["thumbnails"][0]["real_width"]) + \
                         "},{\"real_height\":" + str(d_text["thumbnails"][1]["real_height"]) + ",\"url\":\"" + \
                         d_text["thumbnails"][1][
                             "url"] + \
                         "\",\"height\":" + str(d_text["thumbnails"][1]["height"]) + ",\"width\":" + str(
                d_text["thumbnails"][1]["width"]) \
                         + ",\"real_width\":" + str(d_text["thumbnails"][1]["real_width"]) + "}],\"req_id\":\"" + str(
                int(time.time() * 1000)) + "\"}\n"

            self.log.info("{} try to upload file to server:successful".format(myself))

            return send_photo

        except Exception as e:

            self.log.info("{} try to upload file to server:fail".format(myself))

            return None

    def ifunny_send_photo(self,
                          i_funny,
                          myself,
                          user_id,
                          access_token,
                          messenger_token,
                          redis_conn,
                          photo_name,
                          photo_path,
                          post_type,
                          bother="Two"):

        # 发送图片 视频

        self.log.info("{} try to send to user_id {}".format(myself, user_id))

        if not redis_conn.get(myself + ":account_key"):
            self.ifuuny_get_key(access_token=messenger_token, myself=myself, redis_conn=redis_conn)

        key = redis_conn.get(myself + ":account_key").decode("utf-8")

        i_funny_message_url = "wss://ws-afb3a55b-8275-4c1e-aea8-309842798187.sendbird.com/?p=Android&pv=22&sv=3.0.97&ai=AFB3A55B-8275-4C1E-AEA8-309842798187&key={}".format(
            key)

        i_funny_message_header = {
            "User-Agent": "Jand/3.0.97",
            "Request-Sent-Timestamp": int(time.time() * 1000),
            "Upgrade": "websocket",
            "Connection": "Upgrade",
            "Sec-WebSocket-Version": "13",
            "Host": "ws-afb3a55b-8275-4c1e-aea8-309842798187.sendbird.com",
            "Accept-Encoding": "gzip"
        }

        t = int(time.time() * 1000)

        bear_ = redis_conn.hget(myself + ":id", user_id)

        if not bear_:

            bear_ = i_funny.ifunny_chat_id(access_token, user_id)

            redis_conn.hset(myself + ":id", user_id, bear_)

        else:

            bear_ = bear_.decode("utf-8")

        self.log.info("{} try to send to user_id {} chatUrl {}".format(myself, user_id, bear_))

        ws = create_connection(i_funny_message_url,
                               headers=i_funny_message_header,
                               sslopt={"cert_reqs": ssl.CERT_NONE})

        ts = ifunny_context

        if bother == "all":

            i_funny_message_photo = self.ifunny_photo_object(myself=myself,
                                                             redis_conn=redis_conn,
                                                             photo_name=photo_name,
                                                             chat_group_curl=bear_,
                                                             photo_path=photo_path,
                                                             post_type=post_type)

            ws.send(i_funny_message_photo)

            time.sleep(2)

            i_funny_message_text = "MESG{\"channel_url\": \"" + \
                                   bear_ + "\",\"message\": \"" + \
                                   ts + "\", \"data\": \"{\\\"local_id\\\":" + \
                                   str(random.randint(111111111, 999999999)) \
                                   + "}\", \"mention_type\": \"users\", \"req_id\": \"" \
                                   + str(t) + "\"}\n"

            ws.send(i_funny_message_text)

            time.sleep(1)

            ws.close()

            self.log.info("{} try to send video or photo to user_id {}:successful".format(myself, bear_))

            return True

        if bother == "text":

            i_funny_message_text = "MESG{\"channel_url\": \"" + \
                                   bear_ + "\",\"message\": \"" + \
                                   ts + "\", \"data\": \"{\\\"local_id\\\":" + \
                                   str(random.randint(111111111, 999999999)) \
                                   + "}\", \"mention_type\": \"users\", \"req_id\": \"" \
                                   + str(t) + "\"}\n"

            ws.send(i_funny_message_text)

            time.sleep(1)

            ws.close()

            self.log.info("{} try to send video or photo to user_id {}:successful".format(myself, bear_))

            return True

        if bother == "video":

            i_funny_message_photo = self.ifunny_photo_object(myself=myself,
                                                             redis_conn=redis_conn,
                                                             photo_name=photo_name,
                                                             chat_group_curl=bear_,
                                                             photo_path=photo_path,
                                                             post_type=post_type)

            ws.send(i_funny_message_photo)

            time.sleep(2)

            ws.close()

            return True
