#-*-coding:utf-8-*-

import json
import uuid
import time
import random
import requests
from requests.exceptions import SSLError,ProxyError

from beidoudataclean.appdataclean import AminoCleanData

class AminoBusiness:

    def __init__(self, ndcdeviceid, smdeviceid, user_agent, log):

        self.clean_data = AminoCleanData()

        self.ndcdeviceid = ndcdeviceid

        self.smdeviceid = smdeviceid

        self.user_agent = user_agent

        self.log = log

    def amino_followed(self, community_id, uid, sid):
        # 追随某一社区

        self.log.info(
            "{}:try to join {}".format(time.asctime(), community_id))

        amino_follow_url = "https://service.narvii.com/api/v1/{}/s/user-profile/{}/member".format(community_id,
                                                                                                  uid)  # 代表是到某一个数据下

        amino_follow_header = {
            "NDCLANG": "en",
            "AUID": uid,
            "NDCDEVICEID": self.ndcdeviceid,
            "SMDEVICEID": self.smdeviceid,
            "Accept-Language": "zh-CN",
            "User-Agent": self.user_agent,
            "Host": "service.narvii.com",
            "Connection": "Keep-Alive",
            "Accept-Encoding": "gzip",
            "Content-Type": "application/x-www-form-urlencoded",
            "NDCAUTH": "sid={}".format(sid)
        }

        followed = requests.post(url=amino_follow_url, headers=amino_follow_header, verify=False)

        followed_json = json.loads(followed.text)

        if followed_json["api:message"] == "OK":

            self.log.info(
                "{}:join {}:successful".format(time.asctime(), community_id))

            return True

        else:

            self.log.info(
                "{}:join {}:fail".format(time.asctime(), community_id))

            return False


    def have_join(self, uid, sid, func, **kwargs):#, thread_pool):
        # 检查已经加入的社区
        account = kwargs["account"]

        base_conn = kwargs["base_conn"]

        self.log.info(
            "{}:try to get community {} joined ".format(time.asctime(), account))

        page_spa = base_conn.get("{}:{}:have_join".format(account, uid)).decode("utf-8") if base_conn.get(
            "{}:{}:have_join".format(account, uid)) else 0

        stop_time = None

        have_join_header = {
            "NDCLANG": "en",
            "AUID": uid,
            "NDCDEVICEID": self.ndcdeviceid,
            "SMDEVICEID": self.smdeviceid,
            "Accept-Language": "zh-CN",
            "User-Agent": self.user_agent,
            "Host": "service.narvii.com",
            "Connection": "Keep-Alive",
            "Accept-Encoding": "gzip",
            "NDCAUTH": "sid={}".format(sid)
        }

        while True:

            # time.sleep(random.randint(1,3))

            url = "https://service.narvii.com/api/v1/g/s/community/joined?size=20&size=20&start={}".format(page_spa)

            if stop_time:
                url = "https://service.narvii.com/api/v1/g/s/community/joined?size=20&size=20&start={}&stoptime={}".format(
                    page_spa, stop_time.replace(":", "%3A"))
            try:

                have_followed = requests.get(url=url, headers=have_join_header, verify=False)

                have_followed_json = json.loads(have_followed.text)

                if len(have_followed_json["communityList"]) == 0:
                    break

                have_result = self.clean_data.clean_theme_pack(data=have_followed_json["communityList"])

                for sub_have_join in have_result:

                    func(account, sub_have_join[1])
                    # thread_pool.apply_async(func, (account, sub_have_join[1], account_url, url_redis, account_redis))

                base_conn.set("{}:{}:have_join".format(account, uid), page_spa)

                self.log.info(
                    "{}:try to get community {} joined,{}:successful ".format(time.asctime(), account, page_spa))

                page_spa = int(page_spa) + 20

                stop_time = have_followed_json["api:timestamp"]


            except SSLError as e:

                self.log.info(
                    "{}:try to get community {} joined,{}:sslerror ".format(time.asctime(), account, page_spa))

                break


    def amino_chat(self, account, auid, community_id, uid, sig, sid, redis_num, context=None):
        # 给某一用户发消息

        self.log.info(
            "{}:{} try to send message to {}".format(time.asctime(), account, auid))

        amino_url_chat = "https://service.narvii.com/api/v1/{}/s/chat/thread".format(community_id)

        amino_url_header = {
            "NDCLANG": "en",
            "ndc-submit-token": str(uuid.uuid4()),
            "AUID": auid,
            "NDC-MSG-SIG": sig,
            "NDCDEVICEID": self.ndcdeviceid,
            "SMDEVICEID": self.smdeviceid,
            "Accept-Language": "zh-CN",
            "Content-Type": "application/json; charset=utf-8",
            "User-Agent": self.user_agent,
            "Host": "service.narvii.com",
            "Connection": "Keep-Alive",
            "Accept-Encoding": "gzip",
            "NDCAUTH": "sid={}".format(sid)
        }

        context_offer = {"type": 0, "inviteeUids": [uid],
                         "initialMessageContent": "Hi, I think we have something in common. Can we follow each beidouother?",
                         "timestamp": int(time.time() * 1000)}

        if context:

            context_offer["initialMessageContent"] = context

        chat_result = requests.post(url=amino_url_chat, headers=amino_url_header,
                                    data=json.dumps(context_offer), verify=False)

        chat_json = json.loads(chat_result.text)

        if chat_json["api:message"] == "OK":

            self.log.info(
                "{}:{} try to send message to {}:successful".format(time.asctime(), account, auid))

            redis_num.hset(account + "chat", uid, chat_json["thread"]["threadId"] + "#" + community_id)

            return True

        else:

            self.log.info(
                "{}:{} try to send message to {}:fail:info: {}".format(time.asctime(), account, auid,
                                                                       chat_json["api:message"]))

            return False


    def chat_last_message(self,account, auid, community, thread_id, sid):
        # 获取最新的聊天信息

        self.log.info(
            "{}:{} try to get last message {}".format(time.asctime(), account, auid))

        chat_new_url = "https://service.narvii.com/api/v1/{}/s/chat/thread/{}".format(community, thread_id)

        chat_new_header = {
            "NDCLANG": "en",
            "AUID": auid,
            "NDCDEVICEID": self.ndcdeviceid,
            "SMDEVICEID": self.smdeviceid,
            "Accept-Language": "zh-CN",
            "User-Agent": self.user_agent,
            "Host": "service.narvii.com",
            "Connection": "Keep-Alive",
            "Accept-Encoding": "gzip",
            "NDCAUTH": "sid={}".format(sid)
        }

        chat_result = requests.get(url=chat_new_url, header=chat_new_header, verify=False)

        chat_result_json = json.loads(chat_result.text)

        chat_info = chat_result_json["thread"]["lastMessageSummary"]

        if chat_info["uid"] != auid:

            self.log.info(
                "{}:{} try to get last message {}:fail".format(time.asctime(), account, auid))

            return True

        else:

            self.log.info(
                "{}:{} try to get last message {}:successful".format(time.asctime(), account, auid))

            return False


    def create_no_exist(self, auid, uid, sid):
        # 创建一个聊天的进程

        self.log.info(
            "{}:{} try to create thread for chatting".format(time.asctime(), auid))

        thread_url = "https://service.narvii.com/api/v1/g/s/chat/thread?type=exist-single&cv=1.2&q={}".format(uid)

        thread_header = {
            "NDCLANG": "en",
            "AUID": auid,
            "NDCDEVICEID": self.ndcdeviceid,
            "SMDEVICEID": self.smdeviceid,
            "Accept-Language": "zh-CN",
            "User-Agent": self.user_agent,
            "Host": "service.narvii.com",
            "Connection": "Keep-Alive",
            "Accept-Encoding": "gzip",
            "NDCAUTH": "sid={}".format(sid)
        }

        thread_data = requests.get(url=thread_url, header=thread_header, verify=False)

        thread_json = json.loads(thread_data.text)

        if "Sorry" in thread_json["api:message"]:

            self.log.info(
                "{}:{} try to create thread for chatting:fail".format(time.asctime(), auid))

            return False

        else:

            self.log.info(
                "{}:{} try to create thread for chatting:successful".format(time.asctime(), auid))

            return True


    def chat_to_other(self, account, auid, community, uid, sig, sid, redis_num, text_data):
        # 给其他人发消息
        self.log.info(
            "{}:{} try to chat {}".format(time.asctime(), account, auid))

        thread_id = redis_num.hget(account + "chat", uid).decode("utf-8")

        chat_url_other = "https://service.narvii.com/api/v1/{}/s/chat/thread/{}/message".format(community, thread_id)

        chat_header = {
            "NDCLANG": "en",
            "ndc-submit-token": str(uuid.uuid4()),
            "AUID": auid,
            "NDC-MSG-SIG": sig,
            "NDCDEVICEID": self.ndcdeviceid,
            "SMDEVICEID": self.smdeviceid,
            "Accept-Language": "zh-CN",
            "Content-Type": "application/json; charset=utf-8",
            "User-Agent": self.user_agent,
            "Host": "service.narvii.com",
            "Connection": "Keep-Alive",
            "Accept-Encoding": "gzip",
            "NDCAUTH": "sid={}".format(sid)
        }

        data = {
            "type": 0,
            "content": text_data,
            "clientRefId": random.randint(100000000, 999999999),
            "attachedObject": "null",
            "timestamp": int(time.time() * 1000)
        }

        chat_data = requests.post(url=chat_url_other, headers=chat_header, data=json.dumps(data), verify=False)

        chat_json_data = json.loads(chat_data.text)

        if chat_json_data["api:statuscode"] == 0:

            self.log.info(
                "{}:{} try to chat {}:successful".format(time.asctime(), account, auid))

            return True

        else:

            self.log.info(
                "{}:{} try to chat {}:fail".format(time.asctime(), account, auid))

            return False
