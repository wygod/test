# -*-coding:utf-8-*-

import ssl
import time
import json
import random
import requests

from beidouconf.beidoupushconf.pushvideorphoto import moot_image_url
from beidouconf.beidoupushconf.pushtextconf import moot_push_context
from beidouconf.baseconf.beidouredisdb import account_login_db, data_send_db,\
    uuid_data_db, account_uuid_assigned_db,uuid_assigned_db


class MootBusiness:

    def __init__(self, log,
                 user_agent,
                 device_id,
                 redis_obj,
                 app_token_signature):

        self.log = log

        self.redis_obj = redis_obj

        self.device_id = device_id

        self.user_agent = user_agent

        self.app_token_signature = app_token_signature

        self.account_login = self.redis_obj.redis_client(account_login_db)

    def moot_follow_user(self,
                         user_key,
                         account_user_no,
                         tokens):

        print(user_key)

        follow_friend_url = "https://usw-api.moot.us/following"

        follow_friend_header = {"DEVICE-TIME-ZONE-ID": "Asia/Shanghai", "country": "CN", "User-agent": self.user_agent,
                                "version": "20140411", "DEVICE-TIME-ZONE-MS-OFFSET": "28800000", "language": "zh_CN",
                                "Accept-Encoding": "gzip", "Content-Type": "application/json; charset=UTF-8",
                                "Host": "usw-api.moot.us", "Connection": "Keep-Alive", "deviceid": self.device_id,
                                "signature": self.app_token_signature.signature(),
                                "Authorization": self.app_token_signature.make_authorization(account_user_no, tokens)}

        follow_friend_data = {"userNo": user_key}

        follow_data = requests.post(url=follow_friend_url, headers=follow_friend_header,
                                    data=json.dumps(follow_friend_data), verify=False)

        result = json.loads(follow_data.text)

        if "data" in result.keys():

            if result["data"]["success"]:

                return True

            else:
                return False

        return False

    def moot_send_video(self,
                        message_channel_no,
                        user_no,
                        tokens,
                        imgae_url):
        url = "https://usw-api.moot.us/v1.2/messages"

        header = {"deviceId": self.device_id, "DEVICE-TIME-ZONE-ID": "Asia/Shanghai", "country": "CN",
                  "User-agent": self.user_agent, "version": "20140411", "DEVICE-TIME-ZONE-MS-OFFSET": "28800000",
                  "language": "zh_CN", "Accept-Encoding": "gzip",
                  "Authorization": self.app_token_signature.make_authorization(account=user_no, refresh_taken=tokens),
                  "Content-Type": "application/json; charset=UTF-8", "Host": "usw-api.moot.us",
                  "Connection": "keep-alive", "signature": self.app_token_signature.signature()}

        data_from = {
            "content": {
                "stillImageUrl": imgae_url,
                "imageUrl": imgae_url,
                "metadata": {
                    "height": 480,
                    "width": 480
                },
                "type": "GIPHY"
            },
            "receiverUserNo": 0,
            "messageChannelNo": message_channel_no
        }

        result = requests.post(url=url, headers=header, data=json.dumps(data_from), verify=False)

        result_json = json.loads(result.text)

        if int(result_json["data"]["messageChannelNo"]) == int(message_channel_no):

            return True

        else:

            return False

    def moot_choice_message(self,
                            user_id,
                            redis_use_conn,
                            speech_craft_init_word):
        index = redis_use_conn.get(user_id + ":word_1")

        if index:

            speech_craft_init_use = list(
                filter(lambda x: True if x[1] == int(index) else False, speech_craft_init_word))

            return speech_craft_init_use[0]

        else:

            context_speed = random.choice(speech_craft_init_word)

            redis_use_conn.set(user_id + ":word_1", context_speed[1])

            return context_speed[0]

    def moot_send_message(self,
                          messageChannelNo,
                          account_user_no,
                          tokens,
                          data):
        message_header = {"deviceId": self.device_id, "DEVICE-TIME-ZONE-ID": "Asia/Shanghai", "country": "CN",
                          "User-agent": self.user_agent, "version": "20140411",
                          "DEVICE-TIME-ZONE-MS-OFFSET": "28800000", "language": "zh_CN", "Accept-Encoding": "gzip",
                          "Host": "usw-api.moot.us", "Connection": "keep-alive",
                          "signature": self.app_token_signature.signature(),
                          "Authorization": self.app_token_signature.make_authorization(account_user_no, tokens),
                          "Content-Type": "application/json; charset=UTF-8"}

        message_url = "https://usw-api.moot.us/v1.2/messages"

        message_data = {"content": {"text": random.choice(["hi,nice to meet you",
                                                           "hello,i are finding partner"]), "type": "TEXT"},
                        "receiverUserNo": 0,
                        "messageChannelNo": messageChannelNo}

        if data is not None:

            if isinstance(data, list):

                message_data["content"]["text"] = data

            elif isinstance(data, str):

                message_data["content"]["text"] = data

            else:

                pass

        message_result = requests.post(url=message_url, headers=message_header, data=json.dumps(message_data),
                                       verify=False)

        json_message_data = json.loads(message_result.text)

        if json_message_data["data"]["messageChannelNo"] == int(messageChannelNo):

            return True

        else:

            return False

    def moot_channel_no(self,
                        user_k,
                        base_header,
                        account_user_no,
                        tokens):

        channel_header = base_header

        channel_data = {"receiverUserNo": user_k}

        channel_url = "https://usw-api.moot.us/channels"

        channel_header["signature"] = self.app_token_signature.signature()

        channel_header["Authorization"] = self.app_token_signature.make_authorization(
            account_user_no, tokens)

        channel_header["Content-Type"] = "application/json; charset=UTF-8"

        channel_result = requests.post(url=channel_url, headers=channel_header,
                                       data=json.dumps(channel_data),
                                       verify=False)

        channel_data_form = json.loads(channel_result.text)

        if channel_result.status_code == 200:
            message_channel_no = channel_data_form["data"]["messageChannelNo"]

            return message_channel_no

    def moot_push_ad(self,
                     user_k,
                     base_header,
                     account_user_no,
                     tokens,
                     bother="all"):

        message_channel_no = self.account_login.get(user_k[0])

        if not message_channel_no:

            message_channel_no = self.moot_channel_no(
                user_k[0].decode("UTF-8"),
                base_header,
                account_user_no,
                tokens)

            if message_channel_no:
                self.account_login.set(user_k[0], message_channel_no)
        else:

            message_channel_no = message_channel_no.decode("UTF-8")

        if message_channel_no:

            if bother in ["all", "text", "video"]:

                if bother == "all":

                    flag_video = self.moot_send_video(message_channel_no, account_user_no, tokens, moot_image_url)

                    flag = self.moot_send_message(message_channel_no, account_user_no, tokens, moot_push_context)

                    if flag and flag_video:

                        return True

                    else:

                        return False

                elif bother == "text":

                    flag = self.moot_send_message(message_channel_no, account_user_no, tokens, moot_push_context)

                    if flag:

                        return True

                    else:

                        return False

                else:

                    flag_video = self.moot_send_video(message_channel_no, account_user_no, tokens, moot_image_url)

                    if flag_video:

                        return True

                    else:

                        return False

            else:

                raise Exception("bother must be one of [all,text,video]")


class BeiDouBusinessMoot:

    def __init__(self,
                 log,
                 app_name,
                 user_agent,
                 device_id,
                 redis_obj,
                 app_token_signature):

        self.log = log

        self.app_name = app_name

        self.redis_obj = redis_obj

        self.send_data = self.redis_obj.redis_client(data_send_db)

        self.uuid_data = self.redis_obj.redis_client(uuid_data_db)

        self.account_uuid = self.redis_obj.redis_client(uuid_assigned_db)

        self.moot_business = MootBusiness(app_token_signature=app_token_signature,
                                          device_id=device_id,
                                          log=self.log,
                                          redis_obj=self.redis_obj,
                                          user_agent=user_agent)

        self.account_login = self.redis_obj.redis_client(account_login_db)

        self.account_uuid_filter = self.redis_obj.redis_client(account_uuid_assigned_db)

    def beidou_moot(self,
                    account,
                    account_user_no,
                    tokens,
                    follow_func,
                    send_func,
                    data,
                    base_header):

        uuid_list = self.account_uuid.hgetall(account)

        num = 1 if not self.account_login.get(account + ":fans_num") \
            else int(self.account_login.get(account + ":fans_num").decode("utf-8"))

        following_num = 1 if not self.account_login.get(account + ":follow_num") \
            else int(self.account_login.get(account + ":follow_num").decode("utf-8"))

        if not self.account_login.get(account + ":fans_num"):
            self.account_login.set(account + ":fans_num", num)

            self.account_login.expire(account + ":fans_num", 86380)

        num_follow = 1 if not self.account_login.get(account + ":add_num") \
            else self.account_login.get(account + ":add_num").decode(
            "utf-8")

        if not self.account_login.get(account + ":follow_num"):
            self.account_login.set(account + ":follow_num", num_follow)

            self.account_login.expire(account + ":follow_num", 86380)

        num_flag = False

        first = 0

        if num < 600:

            for i_uuid_key, i_uuid_value in uuid_list.items():

                self.log.info("{} is exec".format(account))

                user_id = self.uuid_data.hgetall(i_uuid_key)

                for user_k, key in user_id.items():

                    if following_num < 5000:

                        num_follow = int(self.account_login.get(account + ":add_num").decode("utf-8")) if self.account_login.get(account + ":add_num") else 0

                        if int(num_follow) > 49:

                            if first == 0:
                                first = first + 1

                                self.account_login.expire(account + "add_num", 86380)

                            continue

                        else:

                            follow_func(user_k.decode("utf-8"))
                            self.account_login.set(account + ":follow_num", following_num + 1)

                            self.account_login.set(account + "add_num", num_follow + 1)

                            time.sleep(1)

                    try:

                        if not self.send_data.get(user_k):

                            message_channel_no = self.account_login.get(user_k)

                            if not message_channel_no:

                                message_channel_no = self.moot_business.moot_channel_no(user_k.decode("UTF-8"),
                                    base_header,
                                    account_user_no,
                                    tokens)

                                if message_channel_no:
                                    self.account_login.set(user_k, message_channel_no)

                            flag = send_func(message_channel_no)

                            if flag:

                                num = num + 1

                                self.account_login.set(account + ":fans_num", num)

                                self.account_login.expire(account, 86400)

                                self.send_data.set(user_k, key)

                                if num > 600:
                                    num_flag = True

                                    break

                                self.log.info("{} send ok".format(account))

                            self.log.info("{} fail".format(account))

                    except Exception as e:
                        self.log.info("{} is fail".format(account))
                        print(e)
                        num_flag = True
                        break

                if num_flag:
                    break






