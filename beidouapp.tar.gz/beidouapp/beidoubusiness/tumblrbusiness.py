# -*-coding:utf-8-*-
import time
import uuid
import json
import random
import requests
from urllib import parse
from requests_toolbelt import MultipartEncoder
from requests.exceptions import ProxyError, SSLError

from beidouotherscript.tumblr_script import TumblerBaseJava
from beidouconf.baseconf.beidouredisdb import account_login_db,data_send_db
from beidouconf.beidoupushconf.pushvideorphoto import tumblr_photo_video_name, tumblr_photo_video_path


class TumblrBusiness:

    def __init__(self, log, tumbler_base_java, redis_obj):

        self.log = log

        self.redis_obj = redis_obj

        self.tumbler_base_java = tumbler_base_java

        self.account_login = self.redis_obj.redis_client(account_login_db)

        self.account_filter = self.redis_obj.redis_client(data_send_db)

    def tumblr_add_user(self, email, url, placement_id, context):

        # 添加用户

        self.log.info("{}:{} try to get {}:{}".format(time.asctime(), email, url, placement_id))

        oauth_token = self.account_login.get(email + ":oauth_token").decode("utf-8")

        oauth_token_secret = self.account_login.get(email + ":oauth_token_secret").decode("utf-8")

        handle_string = self.tumbler_base_java.tumbler_follow_user(oauth_token, url, placement_id, context)

        sig = self.tumbler_base_java.tumbler_sig(handle_string, oauth_token_secret)

        add_user_header = {
            "user-agent": "Tumblr/Android/14.9.0.00",
            "x-version": "device/14.9.0.00/0/6.0.1/tumblr/",
            "x-identifier": "370f2ba6-79ee-4a75-a845-652a2c8fee9f",  # java ramdom uuid
            "x-identifier-date": "",  # timestamp
            "accept-language": "zh-CN",
            "pragma": "no-cache",
            "yx": "63bop7ata0i3i",
            "x-yuser-agent": "YMobile/1.0 (com.tumblr/14.9.0.00; Android/6.0.1; MTC20F; angler; Huawei; Nexus 6P; 5.41; 2392x1440;)",
            "di": "DI/1.0 (; ; [WIFI])",
            "x-background": "false",
            "x-s-id": "NGUxODZlODgtYTFiOS00NDFhLTkxMTUtNGYzM2IyOTE4ZjVj",  # adv_id is constant
            "x-s-id-enabled": "false",
            "authorization": "OAuth oauth_consumer_key=\"BUHsuO5U9DF42uJtc8QTZlOmnUaJmBJGuU1efURxeklbdiLn9L\", oauth_nonce=\"-8662737014390362079\", oauth_signature=\"uwjKKmGWv0e2CfaOT8TS6%2BXpQGQ%3D\", oauth_signature_method=\"HMAC-SHA1\", oauth_timestamp=\"1577955467\", oauth_version=\"1.0\"",
            "content-type": "application/x-www-form-urlencoded",
        }

        oauth_nonce = self.tumbler_base_java.tumbler_oauth_nonce()

        add_user_header[
            'authorization'] = "OAuth oauth_consumer_key=\"BUHsuO5U9DF42uJtc8QTZlOmnUaJmBJGuU1efURxeklbdiLn9L\", oauth_nonce=\"" \
                               + oauth_nonce + "\", oauth_signature=\"" + sig + \
                               "\", oauth_signature_method=\"HMAC-SHA1\", oauth_timestamp=\"" + str(
            self.tumbler_base_java.tumbler_timestamp()) + \
                               "\", oauth_token=\"" + oauth_token + "\", oauth_version=\"1.0\""

        add_user_header['x-identifier-date'] = str(int(time.time()))

        from_data = {'url': url, 'placement_id': placement_id, 'context': context}

        response = requests.post("https://api-http2.tumblr.com/v2/user/follow",
                                 headers=add_user_header, data=parse.urlencode(from_data),
                                 verify=False)

        if response.status_code == 200:

            self.log.info("{}:{} try to get {}:{}：finish".format(time.asctime(), email, url, placement_id))

            return True

        else:

            self.log.info("{}:{} try to get {}:{}:fail".format(time.asctime(), email, url, placement_id))

            return False

    def tumblr_get_q(self, email, username):

        # 获取验证的q

        oauth_token = self.account_login.get(email + ":oauth_token").decode("utf-8")

        oauth_token_secret = self.account_login.get(email + ":oauth_token_secret").decode("utf-8")

        handle_string = self.tumbler_base_java.tumbler_make_get_info(oauth_token, username)

        sig = self.tumbler_base_java.tumbler_sig(handle_string, oauth_token_secret)

        get_q_header = {
            "user-agent": "Tumblr/Android/14.9.0.00",
            "x-version": "device/14.9.0.00/0/6.0.1/tumblr/",
            "x-identifier": "370f2ba6-79ee-4a75-a845-652a2c8fee9f",  # java ramdom uuid
            "x-identifier-date": "",  # timestamp
            "accept-language": "zh-CN",
            "pragma": "no-cache",
            "yx": "63bop7ata0i3i",
            "x-yuser-agent": "YMobile/1.0 (com.tumblr/14.9.0.00; Android/6.0.1; MTC20F; angler; Huawei; Nexus 6P; 5.41; 2392x1440;)",
            "di": "DI/1.0 (; ; [WIFI])",
            "x-background": "false",
            "x-s-id": "NGUxODZlODgtYTFiOS00NDFhLTkxMTUtNGYzM2IyOTE4ZjVj",  # adv_id is constant
            "x-s-id-enabled": "false",
            "authorization": "OAuth oauth_consumer_key=\"BUHsuO5U9DF42uJtc8QTZlOmnUaJmBJGuU1efURxeklbdiLn9L\", oauth_nonce=\"-8662737014390362079\", oauth_signature=\"uwjKKmGWv0e2CfaOT8TS6%2BXpQGQ%3D\", oauth_signature_method=\"HMAC-SHA1\", oauth_timestamp=\"1577955467\", oauth_version=\"1.0\"",
            "content-type": "application/x-www-form-urlencoded",
        }

        oauth_nonce = self.tumbler_base_java.tumbler_oauth_nonce()

        get_q_header[
            'authorization'] = "OAuth oauth_consumer_key=\"BUHsuO5U9DF42uJtc8QTZlOmnUaJmBJGuU1efURxeklbdiLn9L\", oauth_nonce=\"" \
                               + oauth_nonce + "\", oauth_signature=\"" + sig + \
                               "\", oauth_signature_method=\"HMAC-SHA1\", oauth_timestamp=\"" + str(
            self.tumbler_base_java.tumbler_timestamp()) + \
                               "\", oauth_token=\"" + oauth_token + "\", oauth_version=\"1.0\""

        get_q_header['x-identifier-date'] = str(int(time.time()))

        response = requests.get(
            "https://api-http2.tumblr.com/v2/blog/" + username + ".tumblr.com/info?is_full_blog_info=false&blog_name=iwannafuckyexiu&prefetch%5B0%5D=&fields%5Bblogs%5D=name%2Cdescription%2Ctitle%2Ctheme%2Cis_nsfw%2Cis_adult%2Cshare_following%2Cshare_likes%2C%3Ffollowed%2C%3Fcan_message%2Cuuid%2C%3Fis_blocked_from_primary%2C%3Fask%2C%3Fask_anon%2C%3Fcan_submit%2C%3Fcan_send_fan_mail%2C%3Fcan_subscribe%2Csubscribed%2C%3Fsubmission_page_title%2C%3Fsubmission_terms%2Cseconds_since_last_activity%2C%3Favatar",
            headers=get_q_header, verify=False)

        return json.loads(response.text)

    def tumblr_pre_send_massage(self, email, participants, q):

        self.log.info("{}:{} try to send pre message {}:{}".format(time.asctime(), email, participants, q))

        oauth_token = self.account_login.get(email + ":oauth_token").decode("utf-8")

        oauth_token_secret = self.account_login.get(email + ":oauth_token_secret").decode("utf-8")

        handle_string = self.tumbler_base_java.tumbler_participant_info(oauth_token, participants, q)

        sig = self.tumbler_base_java.tumbler_sig(handle_string, oauth_token_secret)

        pre_send_massage_header = {
            "user-agent": "Tumblr/Android/14.9.0.00",
            "x-version": "device/14.9.0.00/0/6.0.1/tumblr/",
            "x-identifier": "370f2ba6-79ee-4a75-a845-652a2c8fee9f",  # java ramdom uuid
            "x-identifier-date": "",
            "accept-language": "zh-CN",
            "pragma": "no-cache",
            "yx": "63bop7ata0i3i",
            "x-yuser-agent": "YMobile/1.0 (com.tumblr/14.9.0.00; Android/6.0.1; MTC20F; angler; Huawei; Nexus 6P; 5.41; 2392x1440;)",
            "di": "DI/1.0 (; ; [WIFI])",
            "x-background": "false",
            "x-s-id": "NGUxODZlODgtYTFiOS00NDFhLTkxMTUtNGYzM2IyOTE4ZjVj",  # adv_id is constant
            "x-s-id-enabled": "false",
            "authorization": "OAuth oauth_consumer_key=\"BUHsuO5U9DF42uJtc8QTZlOmnUaJmBJGuU1efURxeklbdiLn9L\", oauth_nonce=\"-8662737014390362079\", oauth_signature=\"uwjKKmGWv0e2CfaOT8TS6%2BXpQGQ%3D\", oauth_signature_method=\"HMAC-SHA1\", oauth_timestamp=\"1577955467\", oauth_version=\"1.0\"",
            "content-type": "application/x-www-form-urlencoded",
        }

        oauth_nonce = self.tumbler_base_java.tumbler_oauth_nonce()

        pre_send_massage_header[
            'authorization'] = "OAuth oauth_consumer_key=\"BUHsuO5U9DF42uJtc8QTZlOmnUaJmBJGuU1efURxeklbdiLn9L\", oauth_nonce=\"" \
                               + oauth_nonce + "\", oauth_signature=\"" + sig + \
                               "\", oauth_signature_method=\"HMAC-SHA1\", oauth_timestamp=\"" + str(
            self.tumbler_base_java.tumbler_timestamp()) + \
                               "\", oauth_token=\"" + oauth_token + "\", oauth_version=\"1.0\""

        pre_send_massage_header['x-identifier-date'] = str(int(time.time()))

        participants = self.tumbler_base_java.tumbler_participant()

        q = self.tumbler_base_java.tumbler_get_m()

        response = requests.get(
            "https://api-http2.tumblr.com/v2/conversations/participant_info?participant=" + \
            participants + "&" + "q=" + q,
            headers=pre_send_massage_header, verify=False)

        if response.status_code == 200:

            self.log.info("{}:{} try to send pre message {}:{}:finish".format(time.asctime(), email, participants, q))

            return True

        else:

            self.log.info("{}:{} try to send pre message {}:{}:fail".format(time.asctime(), email, participants, q))

            return False

    def tumblr_list_message(self, email, participant, q):

        # 获取用户聊天列表

        self.log.info("{}:{} try to send pre message {}".format(time.asctime(), email, participant))

        chat_url = "https://api-http2.tumblr.com/v2/conversations?participant={}".format(participant.replace(":", "%"))

        oauth_token = self.account_login.get(email + ":oauth_token").decode("utf-8")

        oauth_token_secret = self.account_login.get(email + ":oauth_token_secret").decode("utf-8")

        handle_string = self.tumbler_base_java.tumbler_participant_info(oauth_token, participant, q)

        sig = self.tumbler_base_java.tumbler_sig(handle_string, oauth_token_secret)

        send_massage_header = {
            "user-agent": "Tumblr/Android/14.9.0.00",
            "Host": "api.tumblr.com",
            "x-version": "device/14.9.0.00/0/6.0.1/tumblr/",
            "x-identifier": "370f2ba6-79ee-4a75-a845-652a2c8fee9f",  # java ramdom uuid
            "x-identifier-date": "",  # timestamp
            "accept-language": "zh-CN",
            "pragma": "no-cache",
            "yx": "63bop7ata0i3i",
            "x-yuser-agent": "YMobile/1.0 (com.tumblr/14.9.0.00; Android/6.0.1; MTC20F; angler; Huawei; Nexus 6P; 5.41; 2392x1440;)",
            "di": "DI/1.0 (; ; [WIFI])",
            "x-background": "false",
            "x-s-id": "NGUxODZlODgtYTFiOS00NDFhLTkxMTUtNGYzM2IyOTE4ZjVj",  # adv_id is constant
            "x-s-id-enabled": "false",
            "authorization": "OAuth oauth_consumer_key=\"BUHsuO5U9DF42uJtc8QTZlOmnUaJmBJGuU1efURxeklbdiLn9L\", oauth_nonce=\"-8662737014390362079\", oauth_signature=\"uwjKKmGWv0e2CfaOT8TS6%2BXpQGQ%3D\", oauth_signature_method=\"HMAC-SHA1\", oauth_timestamp=\"1577955467\", oauth_version=\"1.0\"",
            "content-type": "application/x-www-form-urlencoded",
        }

        oauth_nonce = self.tumbler_base_java.tumbler_oauth_nonce()

        send_massage_header[
            'authorization'] = "OAuth oauth_consumer_key=\"BUHsuO5U9DF42uJtc8QTZlOmnUaJmBJGuU1efURxeklbdiLn9L\", oauth_nonce=\"" \
                               + oauth_nonce + "\", oauth_signature=\"" + sig + \
                               "\", oauth_signature_method=\"HMAC-SHA1\", oauth_timestamp=\"" + str(
            self.tumbler_base_java.tumbler_timestamp()) + \
                               "\", oauth_token=\"" + oauth_token + "\", oauth_version=\"1.0\""

        send_massage_header['x-identifier-date'] = str(int(time.time()))

        response = requests.get(chat_url,
                                headers=send_massage_header, verify=False)

        if response.status_code == 200:

            self.log.info("{}:{} try to send pre message {}：finish".format(time.asctime(), email, participant))

            chat_list = json.loads(response.text)

            return chat_list

        else:

            self.log.info("{}:{} try to send pre message {}:fail".format(time.asctime(), email, participant))

            return None

    def tumblr_author(self, handle_string, oauth_token_secret, oauth_token):

        oauth_nonce = self.tumbler_base_java.tumbler_oauth_nonce()

        sig = self.tumbler_base_java.tumbler_sig(handle_string, oauth_token_secret)

        author = "OAuth oauth_consumer_key=\"BUHsuO5U9DF42uJtc8QTZlOmnUaJmBJGuU1efURxeklbdiLn9L\", oauth_nonce=\"" \
                 + oauth_nonce + "\", oauth_signature=\"" + sig + \
                 "\", oauth_signature_method=\"HMAC-SHA1\", oauth_timestamp=\"" + str(
            self.tumbler_base_java.tumbler_timestamp()) + \
                 "\", oauth_token=\"" + oauth_token + "\", oauth_version=\"1.0\""

        return author

    def tumblr_message_to_someone(self, email, participants, q, msg, video=False):

        # 给某个用户发信息

        if not self.account_filter.get(str(q)+":use"):

            msg = msg if msg else "hi"

            send_pre_send_message = self.tumblr_pre_send_massage(email, participants, q)

            oauth_token = self.account_login.get(email + ":oauth_token").decode("utf-8")

            oauth_token_secret = self.account_login.get(email + ":oauth_token_secret").decode("utf-8")

            if send_pre_send_message:

                handle_string = self.tumbler_base_java.tumbler_send_message(oauth_token, msg, participants, q, "TEXT")

                sig = self.tumbler_base_java.tumbler_sig(handle_string, oauth_token_secret)

                send_to_message_header = {
                    "user-agent": "Tumblr/Android/14.9.0.00",
                    # "Host": "api.tumblr.com",
                    "x-version": "device/14.9.0.00/0/6.0.1/tumblr/",
                    "x-identifier": str(uuid.uuid4()),  # java ramdom uuid
                    "accept-language": "zh-CN",
                    "pragma": "no-cache",
                    "yx": "63bop7ata0i3i",
                    "x-yuser-agent": "YMobile/1.0 (com.tumblr/14.9.0.00; Android/6.0.1; MTC20F; angler; Huawei; Nexus 6P; 5.41; 2392x1440;)",
                    "di": "DI/1.0 (; ; [WIFI])",
                    "x-background": "false",
                    "x-s-id": "NGUxODZlODgtYTFiOS00NDFhLTkxMTUtNGYzM2IyOTE4ZjVj",  # adv_id is constant
                    "x-s-id-enabled": "false",
                    "content-type": "application/x-www-form-urlencoded",
                }

                oauth_nonce = self.tumbler_base_java.tumbler_oauth_nonce()

                send_to_message_header[
                    'authorization'] = "OAuth oauth_consumer_key=\"BUHsuO5U9DF42uJtc8QTZlOmnUaJmBJGuU1efURxeklbdiLn9L\", oauth_nonce=\"" \
                                       + oauth_nonce + "\", oauth_signature=\"" + sig + \
                                       "\", oauth_signature_method=\"HMAC-SHA1\", oauth_timestamp=\"" + str(
                    self.tumbler_base_java.tumbler_timestamp()) + \
                                       "\", oauth_token=\"" + oauth_token + "\", oauth_version=\"1.0\""

                send_to_message_header['x-identifier-date'] = str(int(time.time()))

                form_data = {"participant": participants, "participants[1]": participants, "participants[0]": q,
                             "message": msg, "type": "TEXT"}

                response = requests.post(
                    "https://api-http2.tumblr.com/v2/conversations/messages", data=form_data,
                    headers=send_to_message_header, verify=False)

                result = json.loads(response.text)

                self.log.info(str(q) + ":" + str(result["meta"]["status"]))

                if response.status_code == 200 and result["meta"]["status"] == 200:

                    self.log.info("{}:{} send is ok".format(time.asctime(), email))

                    return True

                if result["meta"]["status"] == 429:

                    self.log.info("{}:{} can't use".format(time.asctime(), email))

                    self.account_filter.set(str(q)+":use",429)

                    return False

                elif result["meta"]["status"] == 428:

                    self.account_filter.set(str(q) + ":use", 428)

                    return False

                elif result["meta"]["status"] in [403,404]:

                    return False

                else:

                    self.account_filter.set(str(q) + ":use", 0)

                    self.log.info("{}:{} send is fail".format(time.asctime(), email))

                    return False

            self.account_filter.set(str(q) + ":use", 0)

            return False

        return False
        # send_pre_send_message = self.tumblr_pre_send_massage(email, participants, q)
        #
        # oauth_token = self.account_login.get(email + ":oauth_token").decode("utf-8")
        #
        # oauth_token_secret = self.account_login.get(email + ":oauth_token_secret").decode("utf-8")
        #
        # self.log.info("{}:{} try to send pre message".format(time.asctime(), email))
        #
        # if send_pre_send_message:
        #
        #     self.log.info("{}:{} try to send pre message True".format(time.asctime(), email))
        #
        #     handle_string = self.tumbler_base_java.tumbler_send_message(oauth_token, msg, participants, q, "TEXT")
        #
        #     send_to_message_header = {
        #         "user-agent": "Tumblr/Android/15.5.0.01",
        #         "x-version": "device/15.5.0.01/0/5.1.1/tumblr/",
        #         "x-identifier": "84a1ee44-8e55-4b82-8626-10ece8134816",
        #         "x-identifier-date": "1585721529",
        #         "accept-language": "zh-CN",
        #         "pragma": "no-cache",
        #         "yx": "fjlnvtbt2imuc",
        #         "x-yuser-agent": "YMobile/1.0 (com.tumblr/15.5.0.01; Android/5.1.1; HUAWEIMLA-AL10; HWMLA; HUAWEI; "
        #                          "HUAWEI MLA-AL10; 5.74; 1600x900;)",
        #         "di": "DI/1.0 (460; 07; [WIFI])",
        #         "x-background": "false",
        #         "x-s-id": "YjkwN2M2NjUtNWI1MC00ZDhmLWI4MzUtZjRjODM1ODExMWQ4",
        #         "x-s-id-enabled": "false",
        #         "content-type": "multipart/form-data; boundary=dd4358a5-b16d-4d5c-bdc3-72fb587631d4",
        #         "accept-encoding": "gzip"
        #     }
        #
        #     # if video:
        #     #
        #     #     self.log.info("{}:{} try to send video".format(time.asctime(), email))
        #     #
        #     #     send_to_message_header[
        #     #         'authorization'] = self.tumblr_author(handle_string, oauth_token_secret, oauth_token)
        #     #
        #     #     send_to_message_header['x-identifier-date'] = str(int(time.time()))
        #     #     #
        #         # def open_photo(file_path):
        #         #
        #         #     open_object = open(file_path, "rb").read()
        #         #
        #         #     photo_size = open_object.__sizeof__()
        #         #
        #         #     return open_object, photo_size
        #         #
        #         # photo_object, size_of = open_photo(tumblr_photo_video_path + tumblr_photo_video_name)
        #
        #         # m = MultipartEncoder(
        #         #     fields={
        #         #         "data": ("filename.jpg", photo_object, "image/gif"),
        #         #         "conversation_id": (None, "282859616"),
        #         #         "type": (None, "IMAGE"),
        #         #         "context": (None, "messaging-image-upload"),
        #         #         "participant": (None, q),
        #         #         # "participants[1]": (None,participants),
        #         #         # "participants[0]": (None,q)
        #         #
        #         #     })
        #         #
        #         # send_to_message_header['Content-Type'] = m.content_type
        #         #
        #         # send_to_message_header["accept-encoding"] = "gzip"
        #         #
        #         # response = requests.post("https://api-http2.tumblr.com/v2/conversations/messages", data=m,
        #         #                          headers=send_to_message_header, verify=False)
        #         #
        #         # print(response.text)
        #         #
        #         # time.sleep(random.randint(2, 5))
        #         #
        #         # if response.status_code == 200:
        #         #
        #         #     self.log.info("{}:{} send video is ok".format(time.asctime(), email))
        #         #
        #         # else:
        #         #
        #         #     self.log.info("{}:{} send video is fail".format(time.asctime(), email))
        #
        #     self.log.info("{}:{} try to send message".format(time.asctime(), email))
        #
        #     send_to_message_header['authorization'] = self.tumblr_author(handle_string, oauth_token_secret, oauth_token)
        #
        #     send_to_message_header['x-identifier-date'] = str(int(time.time()))
        #
        #     send_to_message_header['Content-Type'] = "application/x-www-form-urlencoded"
        #
        #     form_data = {"participant": participants, "participants[1]": participants, "participants[0]": q,
        #                  "message": msg, "type": "TEXT"}
        #
        #     response = requests.post(
        #         "https://api-http2.tumblr.com/v2/conversations/messages", data=parse.urlencode(form_data),
        #         headers=send_to_message_header, verify=False)
        #
        #     j_result = json.loads(response.text)
        #
        #     if j_result["meta"]["status"] == 429:
        #         self.log.info("{}:{} can't use".format(time.asctime(), email))
        #
        #         time.sleep(3)
        #
        #     if response.status_code == 200 and j_result["meta"]["status"] == 200:
        #
        #         self.log.info("{}:{} send is ok".format(time.asctime(), email))
        #
        #         return True, 0
        #
        #     else:
        #
        #         self.log.info("{}:{} send is fail".format(time.asctime(), email))
        #
        #         return False, 0
        #
        # return False