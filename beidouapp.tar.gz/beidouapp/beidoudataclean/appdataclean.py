#-*-coding:utf-8-*-
import json
from bs4 import BeautifulSoup


class AminoCleanData:

    #清理爬虫数据

    def __init__(self):

        pass

    def clean_interest_id(self,data):

        temp_clean = []

        if len(data) > 0:

            temp_clean.extend([(i_sub["displayName"],i_sub["interestId"]) for i_sub in data["interestList"]])

        return temp_clean

    def clean_topic(self,data):

        temp_clean = []

        if len(data) > 0:

            temp_clean.extend([(i_sub["storyId"],i_sub["topicId"]) if "storyId" in i_sub.keys() else (i_sub["name"],i_sub["topicId"]) for i_sub in data])

        return temp_clean

    def clean_theme_pack(self,data):

        info_list = []

        if len(data) > 0:

            for i_join in data:

                community_id = i_join["themePack"]["themePackUrl"].rsplit("/")[-1].split("-")[0]

                info_list.append((i_join["membersCount"], community_id))

        return info_list

    def clean_uid(self,data,community_id):

        info_list = []

        if len(data) > 0:

            info_list.extend([(i_join["uid"], community_id) for i_join in data])

        return info_list


class IfunnyCleanData:
    #清理数据

    def __init__(self):

        pass

    def __get_id(self,data):

        return (data["id"],data["nick"])

    def clean_data(self, data):

        temp_clean = []

        if len(data) > 0:

            temp_clean.extend([self.__get_id(i_sub["creator"]) for i_sub in data["items"]])

        return temp_clean


    def clean_items_data(self,data):

        temp_clean = []

        if len(data) > 0:

            temp_clean.extend([self.__get_id(i_sub) for i_sub in data["items"]])

        return temp_clean


class MootCleanData:

    def __init__(self):

        pass

    def game_clean_data(self, data):

        if "data" in data.keys():

            game_data = data["data"]

            return [(game_value["loungeNo"],"loungeNo") for game_value in game_data]

    def app_init_clean(self, data):

        data_user_list = []

        real_data = data["data"]

        print(real_data)

        for key in real_data.keys():

            try:

                if "rankingList" in real_data[key].keys():

                    user = real_data[key]["rankingList"]

                    for i_user in user:

                        user_i = i_user["userNo"]

                        user_name = i_user["userName"]

                        data_user_list.append((user_i,user_name))

            except Exception as e:

                print(e)
                pass

        return data_user_list

    def app_follower_user(self, data):

        data_user_list = []

        real_data = data["data"]

        for key in real_data:

            try:
                user_i = key["userNo"]

                user_name = key["userName"]

                data_user_list.append((user_i, user_name))

            except Exception as e:

                print(e)
                pass

        return data_user_list


class TumblrCleanData:

    def __init__(self):

        pass

    def clean_blog(self,data,items):

        result_list = []

        if data:

            for i_data in data:

                html_content = BeautifulSoup(i_data, "html.parser")

                a = {"a": "data-peepr"}

                try:

                    data_peepr = html_content.find(a)

                    i_sub_data = json.loads(data_peepr["data-peepr"])

                    result_list.append((i_sub_data["tumblelog"],i_sub_data["postId"]+":postId"+":{}".format(items)))

                except Exception as e:

                    print(e)

                    continue

        return result_list


    def clean_hot_use(self,data):

        result_list = []

        if data:

            result_list.extend([(i_data["blog_name"], i_data["blog_uuid"]+"#roomId") for i_data in data])

        return result_list


class WegamersCleanData:

    #清理爬取数据

    def __init__(self):

        pass

    def game_clean(self, list_data):

        context = list_data["obj"]["list"]

        game_data = []

        if len(context) != 0:
            game_data.extend([(i_game["GameItemId"], i_game["GameItemName"]) for i_game in context])

        return game_data

    def clean_book(self, list_data):

        context_list = []

        context = list_data["obj"]["communityContentList"]

        if len(context) != 0:

            for i_context in context:
                temp_context = i_context["newContentBuf"]["Buff"]

                uin = temp_context["Uin"]

                user_name = temp_context["Username"]

                context_list.append((uin, user_name))

        return context_list

    def clean_fnas(self, list_data):

        context_list = []

        context = list_data["obj"]["list"]

        if len(context) != 0:
            context_list.extend(
                [(i_context["Uin"], i_context["UserName"], i_context["NickName"]) for i_context in context])

        return context_list
