# -*-coding:utf-8-*-
import random

from beidoudatastore.appredisdatastore import RedisObject
from beidoudistribution import aminocelery

from beidouallocation.beidouallocation import BeiDouBase
from beidouconf.beidouaccount.accountpassword import amino_account_add_list, amino_account_list
from beidouconf.beidoudeviceconf.deviceconf import amino_ndcdeviceid_and_smdeviceid
from beidouconf.baseconf.beidouredisconf import amino_spider_host, amino_spider_port, amino_spider_password

redis_obj = RedisObject(host=amino_spider_host, port=amino_spider_port, password=amino_spider_password)

account_lock = BeiDouBase(redis_obj)

account_lock.base_process_lock(amino_account_add_list)

for account_password in amino_account_add_list:
    account, password = account_password

    ndcdeviceid, smdeviceid, user_agent = random.choice(amino_ndcdeviceid_and_smdeviceid)

    aminocelery.amino_business_friend.apply_async(args=[account,
                                                        password,
                                                        ndcdeviceid,
                                                        smdeviceid,
                                                        user_agent],
                                                  queue="amino_friend", routing_key="amino_friend")
