# -*-coding:utf-8-*-
import random

from beidoudistribution import mootcelery
from beidouconf.baseconf.beidouredisdb import uuid_db
from beidoudatastore.appredisdatastore import RedisObject

from beidouconf.beidoudeviceconf.deviceconf import moot_machine_match
from beidouconf.baseconf.beidouredisconf import moot_spider_host, moot_spider_port, moot_spider_password


moot_conn = RedisObject(host=moot_spider_host, port=moot_spider_port, password=moot_spider_password)

moot_list = moot_conn.redis_client(uuid_db)

keys_list = moot_list.smembers("uuidcontrol")


for uuid in keys_list:

    device_id, user_agent = random.choice(moot_machine_match)

    mootcelery.moot_spider_user.apply_async(args=[user_agent, device_id, uuid,True,],
                                            queue="moot_spider", routing_key="moot_spider")
