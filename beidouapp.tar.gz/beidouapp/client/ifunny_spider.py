# -*-coding:utf-8-*-
import random

from beidoudistribution import ifunnycelery
from beidouconf.baseconf.beidouredisdb import uuid_db
from beidoudatastore.appredisdatastore import RedisObject
from beidouconf.beidoudeviceconf.deviceconf import ifunny_device_match
from beidouconf.baseconf.beidouredisconf import ifunny_spider_host, ifunny_spider_port, ifunny_spider_password

redis_obj = RedisObject(host=ifunny_spider_host, port=ifunny_spider_port, password=ifunny_spider_password)

ifunny_conn = RedisObject(host=ifunny_spider_host, port=ifunny_spider_port, password=ifunny_spider_password)

ifunny_list = ifunny_conn.redis_client(uuid_db)

keys_list = ifunny_list.smembers("uuidcontrol")

for uuid in keys_list:

    base_authorization, user_agent = random.choice(ifunny_device_match)

    ifunnycelery.ifunny_spider_user.apply_async(args=[uuid.decode("utf-8"), user_agent, base_authorization],
                                                queue="ifunny_friend", routing_key="ifunny_friend")