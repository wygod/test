# -*-coding:utf-8-*-
#test is ok
import multiprocessing
from multiprocessing.pool import ThreadPool

from beidoudistribution import wegamercelery
from beidouloginstance.loginstance import BeibouLog
from beidouspider.wegamerspider import WegameSpider
from beidoudatastore.appredisdatastore import RedisObject
from beidouconf.baseconf.beidouredisdb import account_login_db
from beidouconf.baseconf.beidouredisconf import wegamers_spider_host, wegamers_spider_port, wegamers_spider_password

log_instance = BeibouLog()

thread_pool = ThreadPool(multiprocessing.cpu_count())

redis_obj = RedisObject(host=wegamers_spider_host, port=wegamers_spider_port, password=wegamers_spider_password)

wegamer_list = redis_obj.redis_client(account_login_db)

wegame_init = WegameSpider(redisObject=redis_obj)

log = log_instance.beidou_create_log("wegamer_spider")

base_topic = b'init_game'

if base_topic not in wegamer_list.keys():
    wegame_init.get_game_abb()

init = wegamer_list.hgetall(base_topic.decode("utf-8"))

for keys in init:

    wegamercelery.wegamer_init_app.apply_async(args=[keys.decode("UTF-8")],queue="wegamers_init", routing_key="wegamers_init")
