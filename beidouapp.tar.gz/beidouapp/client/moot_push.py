# -*-coding:utf-8-*-
import random

from beidoudistribution import mootcelery

from beidouconf.beidoudeviceconf.deviceconf import moot_machine_match
from beidouconf.beidouaccount.accountpassword import moot_account_push_list



for account_password in moot_account_push_list:
    account, password = account_password

    device_id, user_agent = random.choice(moot_machine_match)

    mootcelery.moot_business_push.apply_async(args=[account,
                                                    password,
                                                    device_id,
                                                    user_agent],
                                              queue="moot_push", routing_key="moot_push")
