# -*-coding:utf-8-*-
import random

from beidoudistribution import aminocelery

from beidouconf.beidoudeviceconf.deviceconf import amino_ndcdeviceid_and_smdeviceid


ndcdeviceid, smdeviceid, user_agent = random.choice(amino_ndcdeviceid_and_smdeviceid)

aminocelery.amino_init_app.apply_async(args=[ndcdeviceid, smdeviceid, user_agent],
                                         queue="amino_init", routing_key="amino_init")
