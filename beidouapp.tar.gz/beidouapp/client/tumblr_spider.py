# -*-coding:utf-8-*-
import random

from beidoudistribution import tumblrcelery
from beidouconf.baseconf.beidouredisdb import uuid_db
from beidoudatastore.appredisdatastore import RedisObject
from beidouconf.baseconf.beidouredisconf import tumblr_spider_host, tumblr_spider_port, tumblr_spider_password


redis_obj = RedisObject(host=tumblr_spider_host, port=tumblr_spider_port, password=tumblr_spider_password)

tumblr_list = redis_obj.redis_client(uuid_db)

keys_list = tumblr_list.smembers("uuidcontrol")


for uuid in keys_list:
    tumblrcelery.tumblr_spider_user.apply_async(args=[uuid.decode("utf-8"), True],
                                                queue="tumblr_spider", routing_key="tumblr_spider")
