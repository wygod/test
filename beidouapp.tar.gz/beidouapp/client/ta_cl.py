#-*-coding:utf-8-*-
import time
import random
import multiprocessing
from multiprocessing.pool import ThreadPool

from beidoudistribution import task1

thread_pool = ThreadPool(multiprocessing.cpu_count())

old_time = time.time()
#0.0010346314907073975
#0.0006190786361694335
#0.0024088058471679686
for i in range(100):

    print(i)


    temp = task1.add.apply_async(args=[i],queue="wegamers_test", routing_key="wegamers_test")

    print(temp.get())

print((time.time() - old_time)/1000)