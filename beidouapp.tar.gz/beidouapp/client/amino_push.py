#-*-coding:utf-8-*-
import time
import random
from beidoudistribution import aminocelery
from beidouconf.beidouaccount.accountpassword import amino_account_push_list
from beidouconf.beidoudeviceconf.deviceconf import amino_ndcdeviceid_and_smdeviceid


for account_password in amino_account_push_list:

    account, password = account_password

    ndcdeviceid, smdeviceid, user_agent = random.choice(amino_ndcdeviceid_and_smdeviceid)

    aminocelery.amino_business_push.apply_async(args=[account, password, ndcdeviceid,
                                                      smdeviceid, user_agent],
                                                queue="amino_push", routing_key="amino_push")