# -*-coding:utf-8-*-
import random

from beidoudistribution import tumblrcelery
from beidouloginstance.loginstance import BeibouLog
log_instance = BeibouLog()


log = log_instance.beidou_create_log("tumblr_spider")

init = ["trending", "staff-picks", "text", "photos", "gifs", "quotes", "chats", "audio", "video", "asks"]
for keys in init:

    tumblrcelery.tumblr_init_app.apply_async(args=[keys],
                                         queue="tumblr_init_app", routing_key="tumblr_init_app")
