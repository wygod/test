# -*-coding:utf-8-*-
import random

from beidoudistribution import ifunnycelery

from beidouconf.beidoudeviceconf.deviceconf import ifunny_device_match

base_authorization, user_agent = random.choice(ifunny_device_match)

ifunnycelery.ifunny_init_app.apply_async(args=[user_agent,base_authorization],
                                         queue="ifunny_init", routing_key="ifunny_init")
