# -*-coding:utf-8-*-
import random
import multiprocessing
from multiprocessing.pool import ThreadPool
from beidoudistribution import wegamercelery
from beidouloginstance.loginstance import BeibouLog
from beidouconf.baseconf.beidouredisdb import uuid_db
from beidoudatastore.appredisdatastore import RedisObject
from beidouconf.baseconf.beidouredisconf import wegamers_spider_host, wegamers_spider_port, wegamers_spider_password, \
    wegamers_push_host, wegamers_push_port, wegamers_push_password

log_instance = BeibouLog()

thread_pool = ThreadPool(multiprocessing.cpu_count())

redis_obj = RedisObject(host=wegamers_spider_host, port=wegamers_spider_port, password=wegamers_spider_password)

wegamer_conn = RedisObject(host=wegamers_spider_host, port=wegamers_spider_port, password=wegamers_spider_password)

wegamer_list = wegamer_conn.redis_client(uuid_db)

keys_list = wegamer_list.smembers("uuidcontrol")

log = log_instance.beidou_create_log("wegamer_spider")

for uuid in keys_list:
    wegamercelery.wegamer_spider_user.apply_async(args=[uuid.decode("utf-8"),
                                                        False, log,
                                                        redis_obj, thread_pool],
                                                  queue="wegamers_friend", routing_key="wegamers_friend")
