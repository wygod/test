# -*-coding:utf-8-*-
import random

from beidoudistribution import aminocelery

from beidouconf.beidoudeviceconf.deviceconf import amino_ndcdeviceid_and_smdeviceid
from beidouconf.beidouaccount.accountpassword import amino_account_push_list


for account_password in amino_account_push_list:

    account, password = account_password

    ndcdeviceid, smdeviceid, user_agent = random.choice(amino_ndcdeviceid_and_smdeviceid)

    aminocelery.amino_spider_user.apply_async(args=[account, password, ndcdeviceid, smdeviceid, user_agent],
                                              queue="amino_spider", routing_key="amino_spider")
