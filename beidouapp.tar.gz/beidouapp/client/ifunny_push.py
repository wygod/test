# -*-coding:utf-8-*-
import random

from beidouallocation.beidouallocation import BeiDouBase
from beidoudatastore.appredisdatastore import RedisObject
from beidoudistribution import ifunnycelery
from beidouconf.beidoudeviceconf.deviceconf import ifunny_device_match
from beidouconf.beidouaccount.accountpassword import ifunny_account_push_list, ifunny_account_list
from beidouconf.baseconf.beidouredisconf import ifunny_spider_host, ifunny_spider_port, ifunny_spider_password
redis_obj = RedisObject(host=ifunny_spider_host, port=ifunny_spider_port, password=ifunny_spider_password)

account_lock = BeiDouBase(redis_obj)

account_lock.base_process_lock(ifunny_account_list)

for account_password in ifunny_account_push_list:
    account, password = account_password

    basic, user_agent = random.choice(ifunny_device_match)

    ifunnycelery.ifunny_business_push.apply_async(args=[account, password, user_agent, basic],
                                                  queue="ifunny_push", routing_key="ifunny_push")