# -*-coding:utf-8-*-
from beidouallocation.beidouallocation import BeiDouBase
from beidoudatastore.appredisdatastore import RedisObject
from beidoudistribution import tumblrcelery

from beidouconf.beidouaccount.accountpassword import tumblr_account_add_list
from beidouconf.beidoubusinessconf.businesstextconf import tumblr_context

from beidouconf.baseconf.beidouredisconf import tumblr_spider_host, tumblr_spider_port, tumblr_spider_password

redis_obj = RedisObject(host=tumblr_spider_host, port=tumblr_spider_port, password=tumblr_spider_password)

account_lock = BeiDouBase(redis_obj)

account_lock.base_process_lock([i[0] for i in tumblr_account_add_list])
for account_password in tumblr_account_add_list:
    account, password = account_password

    tumblrcelery.tumblr_business_friend.apply_async(args=[account,
                                                          password,"",tumblr_context],
                                                    queue="tumblr_friend", routing_key="tumblr_friend")
