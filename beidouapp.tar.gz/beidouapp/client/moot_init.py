# -*-coding:utf-8-*-
import random
import multiprocessing
from multiprocessing.pool import ThreadPool

from beidoudistribution import mootcelery
from beidouspider.mootspider import MootSpider
from beidouloginstance.loginstance import BeibouLog
from beidoudatastore.appredisdatastore import RedisObject
from beidouconf.baseconf.beidouredisdb import account_login_db
from beidouotherscript.moot_script import MootOtherJavaScript
from beidouconf.beidoudeviceconf.deviceconf import moot_machine_match
from beidouconf.baseconf.beidouredisconf import moot_spider_host, moot_spider_port, moot_spider_password

log_instance = BeibouLog()

thread_pool = ThreadPool(multiprocessing.cpu_count())

app_token_signature = MootOtherJavaScript()

moot_conn = RedisObject(host=moot_spider_host, port=moot_spider_port, password=moot_spider_password)

moot_list = moot_conn.redis_client(account_login_db)

device_id, user_agent = random.choice(moot_machine_match)

log = log_instance.beidou_create_log("moot_spider_game")

moot_init = MootSpider(app_token_signature=app_token_signature,
                       device_id=device_id,
                       log=log,
                       redis_obj=moot_conn,
                       user_agent=user_agent)

if b"init_moot_game" not in moot_list.keys():
    moot_init.moot_spider_game(moot_list, "init_moot_game")

game_id_list = moot_list.hgetall("init_moot_game")

for keys, value in game_id_list.items():
    mootcelery.moot_init_app.apply_async(args=[user_agent, device_id, keys],
                                         queue="moot_init_app", routing_key="moot_init_app")
