# -*-coding:utf-8-*-
import random

from beidoudistribution import wegamercelery
from beidouallocation.beidouallocation import BeiDouBase
from beidoudatastore.appredisdatastore import RedisObject
from beidouconf.beidoudeviceconf.deviceconf import wegame_host_tcp
from beidouconf.beidouaccount.accountpassword import wegamer_account_push_list, wegamer_account_list
from beidouconf.baseconf.beidouredisconf import ifunny_spider_host, ifunny_spider_port, ifunny_spider_password

redis_obj = RedisObject(host=ifunny_spider_host, port=ifunny_spider_port, password=ifunny_spider_password)

account_lock = BeiDouBase(redis_obj)

account_lock.base_process_lock(wegamer_account_list)

for account_password in wegamer_account_push_list:
    account, password = account_password

    host_tcp, port_tcp = random.choice(wegame_host_tcp)
    wegamercelery.wegamer_business_push.apply_async(args=[account,
                                                          password,host_tcp,port_tcp],
                                                    queue="wegamers_push", routing_key="wegamers_push")
