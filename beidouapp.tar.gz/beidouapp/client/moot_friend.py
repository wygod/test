# -*-coding:utf-8-*-
import random

from beidoudistribution import mootcelery
from beidouconf.beidoudeviceconf.deviceconf import moot_machine_match
from beidouconf.beidouaccount.accountpassword import moot_account_add_list


for account_password in moot_account_add_list:
    account, password = account_password

    device_id, user_agent = random.choice(moot_machine_match)

    mootcelery.moot_business_friend.apply_async(args=[account,
                                                      password,
                                                      user_agent,
                                                      device_id],
                                                queue="moot_friend", routing_key="moot_friend")
