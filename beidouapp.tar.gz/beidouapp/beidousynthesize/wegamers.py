# -*-coding:utf-8-*-
import time
import json
from functools import partial

from beidouspider.wegamerspider import WegameSpider
from beidouallocation.beidouallocation import BeiDouBase
from beidoubusiness.beidoubusiness import BeiDouBusiness
from beidoubusiness.wegamersbusiness import WegamerBusiness
from beidouconf.beidoupushconf.pushtextconf import wegame_push_context
from beidouconf.beidoupushconf.pushvideorphoto import wegame_video_info
from beidouconf.baseconf.beidouredisdb import data_db, url_filter_db, \
    push_tumblr_user_db, push_tumblr_uuid_db, account_assign_db, uuid_assigned_db


class WeGameRunBusiness:

    def __init__(self, app_name, log, redis_obj, we_gamer_socket):
        self.log = log

        self.app_name = app_name

        self.redis_obj = redis_obj

        self.data = self.redis_obj.redis_client(data_db)

        self.bei_dou_base = BeiDouBusiness(redisObject=self.redis_obj,
                                           app_name=self.app_name,
                                           log=self.log)

        self.room_data = self.redis_obj.redis_client(url_filter_db)

        self.we_gamer_socket = we_gamer_socket

        self.we_game_business = WegamerBusiness(we_gamer_socket=we_gamer_socket,
                                                log=log)

    def we_game_add_user(self, account):
        self.bei_dou_base.base_add_user(account=account, func=self.we_game_business.add_friend_to_my)


class WeGameRunSpider:

    def __init__(self,
                 log,
                 redis_obj,
                 app_name):
        self.log = log

        self.app_name = app_name

        self.redis_obj = redis_obj

        self.data = self.redis_obj.redis_client(data_db)

        self.account_login = self.redis_obj.redis_client(data_db)

        self.bei_dou_base = BeiDouBusiness(redisObject=self.redis_obj,
                                           app_name=self.app_name,
                                           log=self.log)
        self.we_game = WegameSpider(redisObject=self.redis_obj)

        self.bei_base = BeiDouBase(self.redis_obj)

        #
        # self.wegame_spider = wegameSpider
        #
        # self.init_info = redisObject.redis_client(1)
        #
        # self.user_conn = redisObject.redis_client(3)
        #
        # self.redis_verification = redisObject.redis_client(4)
        #
        # self.redis_ver = redisObject.redis_client(8)

    def get_context(self, base_func, init_game_id, redis_conn, context=True):

        if context:

            if not self.account_login.hget("book_id", init_game_id[1]):

                try:

                    base_func(func=self.bei_base.base_multi_save_func,
                              get_id=init_game_id[1],
                              redis_conn=redis_conn)

                    self.account_login.hset("book_id", init_game_id[1], "1")

                except Exception as e:

                    print(e)

        else:

            try:

                total_num = self.we_game.get_fans_num(init_game_id[0].decode("utf-8"))

                last_page = int(
                    self.account_login.hget(init_game_id[0], "total").decode("utf-8")) \
                    if self.account_login.hget(init_game_id[0], "total") else 0

                if last_page == 0:
                    self.account_login.hset(init_game_id[0], "total", total_num)

                base_func(func=self.bei_base.base_multi_save_func,
                          get_id=init_game_id[0],
                          redis_conn=redis_conn)

            except Exception as e:

                print(e)


class WeGamePush:

    def __init__(self, app_name, log, redis_obj, push_obj, we_gamer_socket):

        self.log = log

        self.redis_obj = redis_obj

        self.data = self.redis_obj.redis_client(data_db)

        self.we_gamer_socket = we_gamer_socket

        self.room_data = self.redis_obj.redis_client(url_filter_db)

        self.we_game_business = WegamerBusiness(log=self.log,
                                                we_gamer_socket=we_gamer_socket)

        self.push_obj = push_obj

        self.push_uuid_filter = self.push_obj.redis_client(push_tumblr_uuid_db)

        self.push_account_filter = self.push_obj.redis_client(push_tumblr_user_db)

        self.account_uuid = self.redis_obj.redis_client(uuid_assigned_db)

        self.push = BeiDouBusiness(app_name=app_name,
                                   redisObject=self.redis_obj,
                                   log=self.log,
                                   push_uuid_filter=self.push_uuid_filter,
                                   push_account_filter=self.push_account_filter)

    def we_game_push(self, value):

        send_video = self.we_gamer_socket.wegamer_send_video(uid=value[1].decode("utf-8"),
                                                             media_length=wegame_video_info["media_length"],
                                                             media_play_length=wegame_video_info["media_play_length"],
                                                             thumb_img_length=wegame_video_info["thumb_img_length"],
                                                             pc_media_md5=wegame_video_info["pc_media_md5"],
                                                             pc_media_url=wegame_video_info["pc_media_url"],
                                                             pc_thumb_img_md5=wegame_video_info["pc_thumb_img_md5"],
                                                             pc_thumb_img_url=wegame_video_info["pc_thumb_img_url"])

        video_result = self.we_gamer_socket.wegamer_conntion(send_video, state=False)

        video_json_result = json.loads(video_result.decode("utf-8"))

        if video_json_result["ret"] == 0:

            self.log.info("{}:send video to {} successful".format(time.asctime(), value))

        else:

            self.log.info("{}:send video to {} fail".format(time.asctime(), value))

        send_message = self.we_gamer_socket.wegamer_pre_message(iuin=value[1].decode("utf-8"),
                                                                text=wegame_push_context)

        add_detail = self.we_gamer_socket.wegamer_conntion(send_message, state=False)

        add_result = json.loads(add_detail.decode("utf-8"))

        if add_result["ret"] != 0:
            self.log.info("{}:send text to {} fail".format(time.asctime(), value))

            return False

        self.log.info("{}:send text to {} successful".format(time.asctime(), value))

        return True

    def run_init(self, account):

        self.push.base_add_user(account=account,
                                func=self.we_game_push,
                                is_use_account=True,
                                source_redis=self.account_uuid)
