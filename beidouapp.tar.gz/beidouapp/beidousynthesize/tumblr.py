# -*-coding:utf-8-*-
import time
from functools import partial

from beidouspider.tumblrspider import TumblrSpider
from beidouspider.beidouspider import BeiDouSpider
from beidouallocation.beidouallocation import BeiDouBase
from beidoubusiness.tumblrbusiness import TumblrBusiness
from beidoubusiness.beidoubusiness import BeiDouBusiness

from beidouconf.beidoupushconf.pushtextconf import tumblr_push_context
from beidouconf.baseconf.beidouredisdb import data_db, url_filter_db,\
    push_tumblr_user_db, push_tumblr_uuid_db, account_assign_db,uuid_assigned_db


class TumblrRunBusiness:

    def __init__(self, app_name, log, redis_obj,tumbler_base_java):

        self.log = log

        self.redis_obj = redis_obj

        self.data = self.redis_obj.redis_client(data_db)

        self.room_data = self.redis_obj.redis_client(url_filter_db)

        self.tumblr_business = TumblrBusiness(log=self.log,
                                              redis_obj=redis_obj,
                                              tumbler_base_java=tumbler_base_java)

        self.push = BeiDouBusiness(app_name=app_name,
                                   redisObject=self.redis_obj,
                                   log=self.log)

    def tumblr_add(self, value, account, context, placement_id):

        flag = False

        try:

            follow_state = self.tumblr_business.tumblr_add_user(email=account,
                                                                url=value[0].decode("utf-8") + ".tumblr.com",
                                                                placement_id=placement_id, context=context)

            return follow_state

        except Exception as e:

            print(e)

            self.log.info(
                "{}:{} push ad {}:fail".format(time.asctime(), account,
                                               value[0]))

        return flag

    def run_tumblr_add(self, account, context,placement_id):

        tumblr_run = partial(self.tumblr_add,
                             account=account,
                             context=context,
                             placement_id=placement_id)

        self.push.base_add_user(account=account,
                                func=tumblr_run)


class TumblrRunSpider:

    def __init__(self,
                 log,
                 redis_obj,
                 app_name):
        self.log = log

        self.redis_obj = redis_obj

        self.bei_dou_spider = BeiDouSpider(app_name=app_name,
                                           log=self.log,
                                           redisObject=self.redis_obj)

        self.tumbler_base_user_info = TumblrSpider(log=self.log,
                                                   redis_obj=self.redis_obj)

        self.bai_dou_base = BeiDouBase(self.redis_obj)

    def tumblr_run_spider_user(self, *value):
        if "postId" in value[1].decode("utf-8"):
            temp_data = value[1].decode("utf-8").split(":")

            fla = self.tumbler_base_user_info.spider_hot_user(value[0].decode("utf-8"), temp_data[0],
                                                              temp_data[-1])

            return fla

        return False

    def tumblr_spdier_user(self, account):

        tumblr_spider = partial(self.tumblr_run_spider_user)

        self.bei_dou_spider.beidou_spider_follow(account=account, func=tumblr_spider)

    def tumblr_init_app(self, init):

        self.tumbler_base_user_info.tumblr_init_data(init)


class TumblrPush:

    def __init__(self, app_name, log, redis_obj, push_obj, tumbler_base_java):

        self.log = log

        self.redis_obj = redis_obj

        self.data = self.redis_obj.redis_client(data_db)

        self.room_data = self.redis_obj.redis_client(url_filter_db)

        self.tumblr_business = TumblrBusiness(log=self.log,
                                              redis_obj=redis_obj,
                                              tumbler_base_java=tumbler_base_java)

        self.push_obj = push_obj

        self.push_uuid_filter = self.push_obj.redis_client(push_tumblr_uuid_db)

        self.push_account_filter = self.push_obj.redis_client(push_tumblr_user_db)

        self.account_uuid = self.redis_obj.redis_client(uuid_assigned_db)

        self.push = BeiDouBusiness(app_name=app_name,
                                   redisObject=self.redis_obj,
                                   log=self.log,
                                   push_uuid_filter=self.push_uuid_filter,
                                   push_account_filter=self.push_account_filter)

    def tumblr_push(self, value, account, participants):

        flag = False

        try:

            if self.data.get(value[0]) and "roomId" in self.data.get(value[0]).decode("utf-8"):

                uuid_user = self.data.get(value[0]).decode("utf-8").split("")[0]

                fla = self.tumblr_business.tumblr_message_to_someone(account, participants, uuid_user,
                                                                                  tumblr_push_context)

                if fla:
                    flag = True

            else:

                if self.room_data.get(value[0]):

                    print("after")

                    fla = self.tumblr_business.tumblr_message_to_someone(account,
                                                                                      participants,
                                                                                      self.room_data.get(
                                                                                          value[0]).decode(
                                                                                          "utf-8"),
                                                                                      tumblr_push_context)

                    if fla:
                        flag = True

                else:

                    q = self.tumblr_business.tumblr_get_q(account, value[0].decode("utf-8"))

                    if q:

                        fla = self.tumblr_business.tumblr_message_to_someone(account, participants,
                                                                                          q["response"]["blog"]["uuid"],
                                                                                          tumblr_push_context)

                        self.room_data.set(value[0], q["response"]["blog"]["uuid"])

                        if fla:

                            flag = True

        except Exception as e:

            print(e)

            self.log.info(
                "{}:{} push ad {}:fail".format(time.asctime(), account,
                                               value[0]))

        return flag

    def run_tumblr_push(self, account, participants):

        tumblr_run = partial(self.tumblr_push,
                             account=account,
                             participants=participants)

        self.push.base_add_user(account=account,
                                func=tumblr_run,
                                is_use_account=True,
                                source_redis=self.account_uuid)