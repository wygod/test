# -*-coding:utf-8-*-

import time
import json
import copy
import requests
from functools import partial
from datetime import datetime

from beidouspider.mootspider import MootSpider
from beidouspider.beidouspider import BeiDouSpider
from beidoubusiness.beidoubusiness import BeiDouBusiness
from beidouconf.beidoupushconf.pushvideorphoto import moot_image_url
from beidouconf.beidoubusinessconf.businesstextconf import moot_context
from beidoubusiness.mootbusiness import MootBusiness, BeiDouBusinessMoot
from beidouconf.beidoubusinessconf.businesstextconf import moot_one, moot_two, moot_three


class MootRunSpider:

    def __init__(self,
                 log,
                 user_agent,
                 device_id,
                 redis_obj,
                 app_token_signature,
                 app_name):
        self.log = log

        self.redis_obj = redis_obj

        self.device_id = device_id

        self.user_agent = user_agent

        self.app_token_signature = app_token_signature

        self.moot_spider = MootSpider(log=self.log,
                                      user_agent=self.user_agent,
                                      device_id=self.device_id,
                                      redis_obj=self.redis_obj,
                                      app_token_signature=self.app_token_signature)

        self.spider_moot = BeiDouSpider(app_name=app_name,
                                        log=self.log,
                                        redisObject=self.redis_obj)

    def moot_run_friend(self, *user):
        print(user)
        fla = self.moot_spider.moot_follower_user(user=user[0].decode("UTF-8"))

        return fla

    def moot_get_user(self, account, use_uuid):

        self.spider_moot.beidou_spider_follow(account=account, func=self.moot_run_friend)

    def moot_init_spider(self, game):
        self.moot_spider.moot_game_something(game=game)

        return True


class MootRunFriend:

    def __init__(self,
                 log,
                 app_name,
                 user_agent,
                 device_id,
                 redis_obj,
                 app_token_signature):

        self.log = log

        self.redis_obj = redis_obj

        self.device_id = device_id

        self.user_agent = user_agent

        self.app_token_signature = app_token_signature

        self.business_moot = BeiDouBusinessMoot(log=self.log,
                                                app_name=app_name,
                                                user_agent=self.user_agent,
                                                device_id=self.device_id,
                                                redis_obj=self.redis_obj,
                                                app_token_signature=self.app_token_signature)

        self.moot_business = MootBusiness(log=self.log,
                                          user_agent=self.user_agent,
                                          device_id=self.device_id,
                                          redis_obj=self.redis_obj,
                                          app_token_signature=self.app_token_signature)

        self.context_choice = self.redis_obj.redis_client(15)

    def moot_add_friend(self,
                        account,
                        account_user_no,
                        tokens,
                        base_header):

        follow_func = partial(self.moot_business.moot_follow_user,
                              account_user_no=account_user_no,
                              tokens=tokens)

        send_func = partial(self.moot_business.moot_send_message,
                            data=moot_context,
                            tokens=tokens,
                            account_user_no=account_user_no)

        self.business_moot.beidou_moot(account=account,
                                       account_user_no=account_user_no,
                                       base_header=base_header,
                                       tokens=tokens,
                                       data=moot_context,
                                       send_func=send_func,
                                       follow_func=follow_func)

    def moot_map_room(self, user_id, account_user_no, tokens, base_header, pl_day):

        context_list = []

        flag = False

        message_no = None

        f_text = [(moot_one, 0), (moot_two, 1), (moot_three, 2)]

        while True:

            try:

                temp_header = base_header

                temp_header["signature"] = self.app_token_signature.signature()

                temp_header["Authorization"] = self.app_token_signature.make_authorization(account_user_no, tokens)

                temp_header["Content-Type"] = "application/json; charset=UTF-8"

                if message_no:

                    message_url = "https://usw-api.moot.us/v1.2/channels/\
                    {}?navigationType=MORE&direction=BEFORE&limit=30&messageNo={}".format(user_id, message_no)

                    data_text = requests.get(message_url, headers=temp_header, verify=False)

                    context_list_text = json.loads(data_text.text)

                    message_no = context_list_text["paging"]["next"]["navigationType"]

                    if context_list_text["data"]:

                        temp_data = context_list_text["data"]

                        for i in temp_data:
                            at_time = i["createdAt"]

                            de_status = i["deleted"]

                            u_id = i["user"]["id"]

                            message_channel_no = i["messageChannelNo"]

                            context_list.append((u_id, de_status, at_time, message_channel_no))
                else:

                    break

                time.sleep(0.2)

                flag = True

            except Exception as e:

                print(e)

        if flag:

            context = self.moot_business.moot_choice_message(user_id=user_id,
                                                             redis_use_conn=self.context_choice,
                                                             speech_craft_init_word=f_text)

            if len(context_list) == 0:

                message_channel_no = self.moot_business.moot_channel_no(user_id.decode("utf-8"),
                                                                        base_header,
                                                                        account_user_no,
                                                                        tokens)

                flag = self.moot_business.moot_send_message(message_channel_no, account_user_no, tokens, context[0])

            else:

                my_user_return_info = list(filter(lambda x: False if x[0] == int(user_id) else True, context_list))

                other_user_return_info = list(filter(lambda x: False if x[0] != int(user_id) else True, context_list))

                other_user = list(map(lambda x: datetime.strptime(x[2], "%Y-%m-%d %H:%M:%S"), other_user_return_info))

                other_info_message_time = max(other_user)

                days = datetime.now() - other_info_message_time

                if len(my_user_return_info) > 0:

                    user_i = list(map(lambda x: datetime.strptime(x[2], "%Y-%m-%d %H:%M:%S"), my_user_return_info))

                    info_message_time = max(user_i)

                    if other_info_message_time <= info_message_time:

                        other_index = other_user.index(other_info_message_time)

                        if (other_index + 1) < len(context):
                            self.moot_business.moot_send_message(context_list[0][-1], account_user_no, tokens, context[other_index + 1])

                else:

                    if days.days > pl_day:
                        self.moot_business.moot_send_message(context_list[0][-1], account_user_no, tokens, context[0])


class MootRunPush:

    def __init__(self,
                 log,
                 app_name,
                 user_agent,
                 device_id,
                 redis_obj,
                 app_token_signature):

        self.log = log

        self.app_name = app_name

        self.redis_obj = redis_obj

        self.device_id = device_id

        self.user_agent = user_agent

        self.app_token_signature = app_token_signature

        self.business_moot = BeiDouBusinessMoot(log=self.log,
                                                app_name=app_name,
                                                user_agent=self.user_agent,
                                                device_id=self.device_id,
                                                redis_obj=self.redis_obj,
                                                app_token_signature=self.app_token_signature)

        self.moot_business = MootBusiness(log=self.log,
                                          user_agent=self.user_agent,
                                          device_id=self.device_id,
                                          redis_obj=self.redis_obj,
                                          app_token_signature=self.app_token_signature)

    def moot_push(self,
                  account,
                  account_user_no,
                  tokens,
                  push_account_filter,
                  push_uuid_filter,
                  is_use_account,
                  source_redis,
                  base_header):

        moot_video_message = partial(self.moot_business.moot_push_ad,
                                     account_user_no=account_user_no,
                                     tokens=tokens,base_header=base_header,
                                     bother="text")

        beidoubusiness = BeiDouBusiness(app_name=self.app_name,log=self.log,
                                        redisObject=self.redis_obj,
                                        push_account_filter=push_account_filter,
                                        push_uuid_filter=push_uuid_filter)

        beidoubusiness.base_add_user(account=account, func=moot_video_message,
                                     is_use_account=is_use_account,
                                     source_redis=source_redis)
