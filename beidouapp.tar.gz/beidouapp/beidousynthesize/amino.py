# -*-coding:utf-8-*-
import time
import random
import logging
from functools import partial

from beidoulogin.login import LoginInfo
from beidouconf.baseconf.beidouredisdb import *
from beidouconf.baseconf.beidouredisconf import *
from beidouconf.baseconf.beidoubaseversion import pl_day
from beidouspider.aminospider import AminoSpider
from beidouspider.beidouspider import BeiDouSpider
from beidouloginstance.loginstance import BeibouLog
from beidoubusiness.aminobusiness import AminoBusiness
from beidoubusiness.beidoubusiness import BeiDouBusiness
from beidoudatastore.appredisdatastore import RedisObject
from beidouallocation.beidouallocation import AminoDispatch
from beidouconf.beidouaccount.accountpassword import amino_account_list
from beidouconf.beidoudeviceconf.deviceconf import amino_ndcdeviceid_and_smdeviceid
from beidouconf.beidoubusinessconf.businesstextconf import amino_one, amino_two, amino_three


class AminoBusinessFriend:

    def __init__(self, log, redis_obj):

        self.log = log

        self.redis_object = redis_obj

        self.account_login = self.redis_object.redis_client(account_login_db)

    def amino_add_user(self,value, amino_download, account, auid, sig, sid, redis_num):

        community_id, uid = value[0].decode("UTF-8"),value[1].decode("UTF-8")

        is_chat = amino_download.amino_chat(account=account, auid=auid,
                                            community_id=community_id,
                                            uid=uid,
                                            sig=sig,
                                            sid=sid,
                                            redis_num=redis_num)

        status = amino_download.amino_followed(community_id=community_id,
                                               uid=uid,
                                               sid=sid)

        if status:

            self.log.info(
                "{}:{}:push:{}:try to start add friend to {}:successful".format(time.asctime(),
                                                                                "amino",
                                                                                account,
                                                                                community_id))

            if is_chat:
                self.log.info(
                    "{}:{}:push:{}:try to chat with friend ad to {}:successful".format(time.asctime(),
                                                                                       "amino",
                                                                                       account,
                                                                                       community_id))

            return True

        else:

            return False

    def amino_friend(self, account,
                     password,
                     amino_ndc,
                     amino_smd,
                     user_agent,
                     amino_business_down):

        login = LoginInfo(self.log)

        if not self.account_login.get(account + ":amino_login_info"):
            login.amino_login(account, password,
                              amino_ndc, amino_smd,
                              user_agent, self.account_login)

            self.account_login.set(account + ":amino_login_info", "1")

            self.account_login.expire(account + ":amino_login_info", 24 * 60 * 60)

        sid = self.account_login.get(account + ":sid").decode("utf-8")

        sig = self.account_login.get(account + ":secret").decode("utf-8")

        auid = self.account_login.get(account + ":auid").decode("utf-8")

        beidoubusiness = BeiDouBusiness(app_name="amino",
                                        log=self.log,
                                        redisObject=self.redis_object)

        amino_friend = partial(self.amino_add_user,
                               amino_download=amino_business_down,
                               account=account,
                               auid=auid,
                               sig=sig,
                               sid=sid,
                               redis_num=self.account_login)

        beidoubusiness.base_add_user(account=account,
                                     func=amino_friend)


class AminoBusinessChat:

    def __init__(self, redis_obj):

        self.redis_object = redis_obj

        self.chat_filter = self.redis_object.redis_client(account_chat_db)

        self.account_login = self.redis_object.redis_client(account_login_db)

        self.log = self.log = BeibouLog().beidou_create_log(app_name="AminoBusinessChat")

    def send_choice_message(self, user_id, redis_use_conn, speech_craft_init_word):
        # 获取已发送的己方文本

        index = redis_use_conn.get(user_id + ":word_1")

        if index:

            speech_craft_init_use = list(
                filter(lambda x: True if x[1] == int(index) else False, speech_craft_init_word))

            return speech_craft_init_use[0]

        else:

            context_speed = random.choice(speech_craft_init_word)

            redis_use_conn.set(user_id + ":word_1", context_speed[1])

            return context_speed[0]

    def map_room(self, account, password, log):

        # 自动回复聊天功能，但暂停使用

        f_text = [(amino_one, 0), (amino_two, 1), (amino_three, 2)]

        ndcdeviceid, smdeviceid, user_agent = random.choice(amino_ndcdeviceid_and_smdeviceid)

        login = LoginInfo(log)

        amino_download = AminoBusiness(ndcdeviceid, smdeviceid, user_agent, log)

        sid = self.account_login.get(account + ":sid").decode("utf-8")

        sig = self.account_login.get(account + ":secret").decode("utf-8")

        auid = self.account_login.get(account + ":auid").decode("utf-8")

        if not self.account_login.get(account + ":amino_login_info"):
            login.amino_login(account, password, ndcdeviceid, smdeviceid, user_agent, self.account_login)

            self.account_login.set(account + ":amino_login_info", "1")

            self.account_login.expire(account + ":amino_login_info", 24 * 60 * 60)

        if not self.chat_filter.get(account):

            uid_chat_list = self.account_login.hgetall(account + "chat")

            for key, value in uid_chat_list.items():

                thread_id, community_id = value.decode("utf-8").split("#")

                have_return = amino_download.chat_last_message(auid=auid,
                                                               thread_id=thread_id,
                                                               sid=sid,
                                                               community=community_id)
                if have_return:

                    if not self.chat_filter.get(thread_id):

                        context = self.send_choice_message(user_id=thread_id, redis_use_conn=self.chat_filter,
                                                           speech_craft_init_word=f_text)

                        have_send = amino_download.chat_to_other(account=account, auid=auid,
                                                                 community=community_id, uid=key.decode("utf-8"),
                                                                 sig=sig, sid=sid, redis_num=self.account_login,
                                                                 text_data=context[0])
                        if have_send:
                            self.chat_filter.set(thread_id, 0)

                            self.chat_filter.set(thread_id + "send", 1)

                            self.chat_filter.expire(thread_id + "send", pl_day * 24 * 60 * 60)

                    else:

                        index = int(self.chat_filter.get(thread_id).decode("utf-8")) + 1 if self.chat_filter.get(
                            thread_id) else 0

                        context = self.send_choice_message(user_id=thread_id, redis_use_conn=self.chat_filter,
                                                           speech_craft_init_word=f_text)

                        if index < len(context):

                            have_send = amino_download.chat_to_other(account=account, auid=auid,
                                                                     community=community_id, uid=key.decode("utf-8"),
                                                                     sig=sig, sid=sid, redis_num=self.account_login,
                                                                     text_data=context[0])
                            if index == 0:

                                self.chat_filter.set(thread_id, 0)

                            else:

                                self.chat_filter.set(thread_id, index)
                        else:

                            if not self.chat_filter.get(thread_id + ":send"):

                                have_send = amino_download.chat_to_other(account=account, auid=auid,
                                                                         community=community_id,
                                                                         uid=key.decode("utf-8"),
                                                                         sig=sig, sid=sid, redis_num=self.account_login,
                                                                         text_data=context[0])
                                if have_send:
                                    self.chat_filter.set(thread_id, 0)

                                    self.chat_filter.set(thread_id + "send", 1)

                                    self.chat_filter.expire(thread_id + "send", pl_day * 24 * 60 * 60)


class AminoSpiderInfo:

    def __init__(self,
                 amino_spider,
                 amino_business,
                 amino_ndc,
                 amino_sm,
                 amino_user_agent,
                 log,
                 redis_obj):

        self.log = log

        self.kwargs = {}

        self.amino_sm = amino_sm

        self.amino_ndc = amino_ndc

        self.amino_spider = amino_spider

        self.amino_business = amino_business

        self.amino_user_agent = amino_user_agent

        self.amino_save = AminoDispatch(redis_obj)

        self.url_filter = redis_obj.redis_client(url_filter_db)

        self.account_login = redis_obj.redis_client(account_login_db)

        self.account_filter = redis_obj.redis_client(account_filter_db)

        self.account_url = redis_obj.redis_client(account_url_filter_db)

        self.amino_login_function = LoginInfo(self.log)

        self.kwargs["base_conn"] = self.account_login

        self.kwargs["account_url"] = self.account_url

        self.kwargs["url_redis"] = self.url_filter

        self.kwargs["account_redis"] = self.account_filter

    def amino_init_topic(self):

        func = partial(self.amino_save.amino_topic_multi,
                       func=self.amino_save.amino_topic_save_func)

        topic_name = "community_class"

        if not self.account_login.get("amino"):
            self.amino_spider.init_base_communities_class(func, redis_num=self.account_login, topic_name=topic_name)

            self.account_login.set("amino", 1)

            self.account_login.expire("amino", 3 * 24 * 60 * 60)

        amino_list = self.account_login.hgetall(topic_name)

        sub_topic_name = "sub_community"

        for key, value in amino_list.items():
            self.amino_spider.init_base_sub_topic(key.decode("utf-8"),
                                                  func,
                                                  self.account_login,
                                                  sub_topic_name)

            # self.thread_pool.apply_async(self.amino_spider.init_base_sub_topic,
            #                              (key.decode("utf-8"),
            #                               func,
            #                               self.account_login,
            #                               sub_topic_name))

    def amino_update_community_url(self):

        func = partial(self.amino_save.amino_topic_multi,
                       func=self.amino_save.amino_topic_save_func)

        sub_topic_name = "sub_community"

        amino_list = self.account_login.hgetall(sub_topic_name)

        for key, value in amino_list.items():
            self.amino_spider.amino_park_url(key.decode("utf-8"), func, self.account_login, "community_url")
            # self.thread_pool.apply_async(self.amino_spider.amino_park_url,
                                         # (key.decode("utf-8"), func, self.account_login, "community_url"))

    def join_park(self, account, key_url):

        is_join = self.amino_spider.join_amino_park(account=account, amino_community_join_id=key_url,
                                                    redis_num=self.account_login)

        if is_join:

            self.log.info("{}:join {}".format(account, key_url))

            if not self.account_url.hget(account, key_url):
                self.amino_save.amino_save_func(account, key_url)

        if is_join is None:

            if not self.account_url.hget(account, key_url):
                self.amino_save.amino_save_func(account, key_url, "0")

        return is_join

    def map_join_park(self, account_url_list, account):

        num = 0

        for sub_account_url in account_url_list:
            data = self.join_park(account, sub_account_url)

            # data = self.thread_pool.apply_async(self.join_park, (account, sub_account_url))

            if data is None:
                num = 99

                self.log.info("{} have join 99 community".format(account))

                break

            if data:
                num = num + 1

        return num

    def check_community(self, account):

        sid = self.account_login.get(account + ":sid").decode("utf-8")

        auid = self.account_login.get(account + ":auid").decode("utf-8")

        self.kwargs["account"] = account

        self.amino_business.have_join(uid=auid,
                                      sid=sid,
                                      func=self.amino_save.amino_save_func,
                                      **self.kwargs)

    def amino_distribution(self, sample_n, account=None):

        sub_topic_name = "community_url"

        amino_list = self.account_login.hgetall(sub_topic_name)

        community_list = [key.decode("utf-8") for key, value in amino_list.items()]

        real_account = [account] if account else amino_account_list

        filter_user_account = [filter_user for filter_user in real_account if
                               not self.account_login.get(filter_user[0])]

        self.log.info("account {}".format(len(filter_user_account)))

        # 为账号分配社区，不同账号可以加入相同社区，总体保证所有的社区都有账号加入

        if filter_user_account:

            for key in filter_user_account:

                accounts, password = key

                self.log.info("{} start beidoudistribution url".format(account))

                if not self.account_login.get(accounts + ":amino_login_info"):
                    self.log.info("{} start beidoudistribution url and beidoulogin".format(account))

                    self.amino_login_function.amino_login(amino_account=accounts,
                                                          amino_password=password,
                                                          amino_ndcdeviceid=self.amino_ndc,
                                                          amino_smdeviceid=self.amino_sm,
                                                          amino_user_agent=self.amino_user_agent,
                                                          amino_redis_num=self.account_login)

                    self.account_login.set(accounts + ":amino_login_info", 1)

                    self.account_login.expire(accounts + ":amino_login_info", 24 * 60 * 60)

                    self.log.info("{} start beidoudistribution url and beidoulogin:successful".format(account))

                have_join_len = self.account_url.hlen(accounts)

                if have_join_len == 0:
                    self.check_community(account=accounts)

                    have_join_len = self.account_url.hlen(accounts)

                    self.log.info("{} join {} community".format(account, have_join_len))

                if have_join_len >= sample_n:
                    self.log.info("{} join {} community".format(account, 0))

                    continue

                filter_community_list = [filter_url for filter_url in community_list if
                                         not self.account_url.get(filter_url)]

                if filter_community_list:

                    min_value = min(sample_n, len(filter_community_list))

                    account_url = random.sample(filter_community_list, min(min_value, len(filter_community_list)))

                    map_join_is_true = self.map_join_park(account_url_list=account_url, account=accounts)

                    self.account_filter.set(accounts, min(min_value, map_join_is_true))

                    self.log.info("{} join {} community".format(account, min(min_value, map_join_is_true)))

                    filter_user_account.remove(key)

                else:

                    min_value = min(sample_n, len(filter_community_list))

                    account_url = random.sample(community_list, min(min_value, len(community_list)))

                    map_join_is_true = self.map_join_park(account_url_list=account_url, account=accounts)

                    self.account_filter.set(accounts, min(min_value, map_join_is_true))

                    self.log.info("{} join {} community".format(account, min(min_value, map_join_is_true)))

                    filter_user_account.remove(key)
        else:

            accounts, password = random.choice(real_account)

            have_join_len = self.account_url.hlen(accounts)

            if have_join_len == 0:
                self.check_community(account=accounts)

                have_join_len = self.account_url.hlen(accounts)

                self.log.info("{} join {} community".format(account, have_join_len))

            if have_join_len < sample_n:

                temp_amino_len = int(self.account_filter.get(accounts).decode("utf-8")) if self.account_filter.get(
                    accounts) else have_join_len

                if temp_amino_len < sample_n:

                    sam_n = sample_n - temp_amino_len

                    filter_community_list = [filter_url for filter_url in community_list if
                                             not self.account_url.hget(accounts, filter_url)]

                    if filter_community_list:
                        account_url = random.sample(community_list, min(sam_n, len(community_list)))

                        filter_community_list.extend(account_url)

                        # 加入选定的社区

                        map_join_is_true = self.map_join_park(account_url_list=filter_community_list, account=accounts)

                        self.account_filter.set(accounts, temp_amino_len + map_join_is_true)

                        self.log.info("{} join {} community".format(account, temp_amino_len + map_join_is_true))

    def amino_follow_user(self,account, password):

        # 获取用户粉丝

        func = partial(self.amino_save.base_multi_save_func,
                       func=self.amino_save.amino_data_save_func)

        # account, password = ('direknfqrh@gmail.com', "beidou01")random.choice(amino_account_list)

        if not self.account_login.get(account + ":amino_login_info"):
            self.log.info("{}:{} try beidoulogin ".format(time.asctime(), account))

            self.amino_login_function.amino_login(amino_account=account,
                                                  amino_password=password,
                                                  amino_ndcdeviceid=self.amino_ndc,
                                                  amino_smdeviceid=self.amino_sm,
                                                  amino_user_agent=self.amino_user_agent,
                                                  amino_redis_num=self.account_login)

            self.account_login.set(account + ":amino_login_info", 1)

            self.account_login.expire(account + ":amino_login_info", 24 * 60 * 60)

            self.log.info("{}:{} beidoulogin:successful ".format(time.asctime(), account))

        account_url_item = self.account_url.hgetall(account)

        self.log.info("{}:{} data".format(time.asctime(), len(account_url_item)))

        for key in account_url_item.keys():

            time.sleep(random.randint(1, 3))

            sid = self.account_login.get(account + ":sid").decode("utf-8")

            auid = self.account_login.get(account + ":auid").decode("utf-8")

            self.log.info("{}:{} try to get {} user".format(time.asctime(), account, key.decode("utf-8")))

            have_friend = self.amino_spider.amino_community_user(communty=key.decode("utf-8"),
                                                                 auid=auid,
                                                                 sid=sid,
                                                                 func=func,
                                                                 redis_num=self.account_login)

            if have_friend:
                time.sleep(random.randint(10, 30) * 60)

                continue

            self.account_login.set(key.decode("utf-8") + ":update", "1")

            self.account_login.expire(key.decode("utf-8") + ":update", 3)

            self.log.info("{}:{} try to get {} user:successful".format(time.asctime(), account, key.decode("utf-8")))

    def run_init(self):

        if not self.account_login.get("amino_init"):
            self.log.info("{} amino init".format(time.asctime()))

            self.amino_init_topic()

            self.amino_update_community_url()

            self.account_login.set("amino_init", "1")

            self.account_login.expire("amino_init", 7 * 24 * 60 * 60)

            self.log.info("{} amino init:successful".format(time.asctime()))
        #
        # # 最大能加入的社区是100
        #
        self.amino_distribution(99)

        # 加入社区后，获取社区成员及其追随成员
    def add_follow_user(self, account, password):

        self.amino_follow_user(account, password)


class AminoRunSpider(AminoSpiderInfo):

    def __init__(self,
                 amino_spider,
                 amino_business,
                 amino_ndc,
                 amino_sm,
                 amino_user_agent,
                 log,
                 redis_obj):

        super().__init__(amino_spider,
                         amino_business,
                         amino_ndc,
                         amino_sm,
                         amino_user_agent,
                         log,
                         redis_obj)

        self.log = BeibouLog().beidou_create_log("AminoRunSpider")

        self.redis_object = RedisObject(host=amino_spider_host,
                                        port=amino_spider_port,
                                        password=amino_spider_password)

        self.amino_save = AminoDispatch(self.redis_object)

        self.beidou_spider = BeiDouSpider(redisObject=self.redis_object,
                                          log=self.log,
                                          app_name="AminoRunSpider")

        self.crawled_data = self.redis_object.redis_client(crawled_data_db)

        self.crawled_uuid_data = self.redis_object.redis_client(crawled_uuid_db)

    def run_spider_init(self, account, func, *kwargs):

        i_uuid, i_user_keys = kwargs

        sid = self.account_login.get(account + ":sid").decode("utf-8")

        auid = self.account_login.get(account + ":auid").decode("utf-8")

        fla = self.amino_spider.amino_follow_user(auid=auid,
                                                  community_id=i_uuid.decode("utf-8"),
                                                  sid=sid,
                                                  func=func,
                                                  uid=i_user_keys.decode("utf-8"),
                                                  redis_num=self.account_login)

        return fla

    def run(self):

        account, password = random.choice(amino_account_list)

        amino_func = partial(self.amino_save.base_multi_save_func,func=self.amino_save.amino_data_save_func)

        amino_spider_run = partial(self.run_spider_init, account=account, func=amino_func)

        if not self.account_login.get(account + ":amino_login_info"):
            self.log.info("{}:{}:try to beidoulogin".format(time.asctime(), account))

            self.amino_login_function.amino_login(amino_account=account,
                                                  amino_password=password,
                                                  amino_ndcdeviceid=self.amino_ndc,
                                                  amino_smdeviceid=self.amino_sm,
                                                  amino_user_agent=self.amino_user_agent,
                                                  amino_redis_num=self.account_login)

            self.account_login.set(account + ":amino_login_info", 1)

            self.account_login.expire(account + ":amino_login_info", 24 * 60 * 60)

            self.log.info("{}:{}:try to beidoulogin:successful".format(time.asctime(), account))

        init_class_len = self.account_url.hlen(account)

        if init_class_len == 0:
            self.log.info("{}:{}:try to dispatch".format(time.asctime(), account))

            self.amino_distribution(99)

            self.log.info("{}:{}:try to dispatch:successful".format(time.asctime(), account))

        self.beidou_spider.base_spider_user(account=account, func=amino_spider_run)


class AminoPush:

    def __init__(self,
                 amino_spider,
                 amino_business,
                 amino_ndc,
                 amino_sm,
                 amino_user_agent,
                 log,
                 push,
                 redis_obj):

        self.log = log

        self.push = push

        self.amino_sm = amino_sm

        self.redis_obj = redis_obj

        self.amino_ndc = amino_ndc

        self.amino_spider = amino_spider

        self.amino_business = amino_business

        self.amino_user_agent = amino_user_agent

        self.uuid = self.redis_obj.redis_client(uuid_db)

        self.push_amino_user_filter = self.push.redis_client(push_amino_user_db)

        self.push_amino_uuid_filter = self.push.redis_client(push_amino_uuid_db)

        self.account_login = self.redis_obj.redis_client(account_login_db)

        self.account_filter = self.redis_obj.redis_client(account_filter_db)

        self.account_url = self.redis_obj.redis_client(account_url_filter_db)

        self.url_filter = self.redis_obj.redis_client(url_filter_db)

    def amino_push_ad(self, value, account, auid, sig, sid):

        user_keys, user_id = value[0],value[1]

        f_t = self.amino_business.amino_chat(account=account,
                                             auid=auid,
                                             community_id=user_keys.decode("utf-8"),
                                             uid=user_id.decode("utf-8"),
                                             sig=sig,
                                             sid=sid,
                                             redis_num=self.account_login)

        return f_t

    def amino_push_run(self, account, password):

        amino_spider_info = AminoSpiderInfo(amino_spider=self.amino_spider,
                                            amino_business=self.amino_business,
                                            amino_ndc=self.amino_ndc,
                                            amino_sm=self.amino_sm,
                                            amino_user_agent=self.amino_user_agent,
                                            log=self.log,
                                            redis_obj=self.redis_obj)

        amino_login = LoginInfo(self.log)

        if not self.account_login.get(account + ":amino_login_info"):
            self.log.info("{}:try to beidoulogin".format(account))

            amino_login.amino_login(amino_account=account,
                                    amino_password=password,
                                    amino_ndcdeviceid=self.amino_ndc,
                                    amino_smdeviceid=self.amino_sm,
                                    amino_user_agent=self.amino_user_agent,
                                    amino_redis_num=self.account_login)

            self.account_login.set(account + ":amino_login_info", "1")

            self.account_login.expire(account + ":amino_login_info", 24 * 60 * 60)

            self.log.info("{}:beidoulogin:successful".format(account))

        sid = self.account_login.get(account + ":sid").decode("utf-8")

        sig = self.account_login.get(account + ":secret").decode("utf-8")

        auid = self.account_login.get(account + ":auid").decode("utf-8")

        init_account_have_user = self.account_url.hlen(account)

        if init_account_have_user == 0:
            self.log.info("push:{}:try to start beidoudistribution url".format(account))

            amino_spider_info.amino_distribution(sample_n=99, account=(account, password))

            self.log.info("push:{}:try to start beidoudistribution url:successful".format(account))

        beidoubusiness = BeiDouBusiness(app_name="amino",
                                        log=self.log,
                                        redisObject=self.redis_obj,
                                        push_account_filter=self.push_amino_user_filter,
                                        push_uuid_filter=self.push_amino_uuid_filter)

        amino_push = partial(self.amino_push_ad,
                             account=account,
                             auid=auid,
                             sig=sig,
                             sid=sid)

        beidoubusiness.base_add_user(account=account,
                                     func=amino_push,
                                     is_use_account=True,
                                     source_redis=self.account_url)


if __name__ == "__main__":
    import multiprocessing
    from multiprocessing.pool import ThreadPool

    amino_init = BeibouLog().beidou_create_log("test")

    ndcdeviceid, smdeviceid, user_agent = random.choice(amino_ndcdeviceid_and_smdeviceid)

    amino_spider = AminoSpider(ndcdeviceid, smdeviceid, user_agent, amino_init)

    # thread_pool = ThreadPool(multiprocessing.cpu_count())

    amino_business = AminoBusiness(ndcdeviceid, smdeviceid, user_agent, amino_init)

    redis_obj = RedisObject(host=amino_spider_host,
                            port=amino_spider_port,
                            password=amino_spider_password)

    aminos = AminoSpiderInfo(amino_spider=amino_spider,
                             amino_ndc=ndcdeviceid,
                             amino_sm=smdeviceid,
                             amino_user_agent=user_agent,
                             amino_business=amino_business,
                             log=amino_init,
                             redis_obj=redis_obj)

    aminos.run_init()
