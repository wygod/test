# -*-coding:utf-8-*-
import time
import random

from functools import partial
from beidoulogin.login import LoginInfo
from beidouconf.baseconf.beidouredisdb import *
from beidouspider.ifunnyspider import IfunnySpider
from beidouspider.beidouspider import BeiDouSpider
from beidouconf.beidoupushconf.pushvideorphoto import *
from beidouallocation.beidouallocation import BeiDouBase
from beidoubusiness.beidoubusiness import BeiDouBusiness
from beidoubusiness.ifunnybusiness import IfunnyBusiness
from beidouconf.baseconf.beidouredisdb import push_ifunny_user_db,push_ifunny_uuid_db
from beidouconf.beidouaccount.accountpassword import ifunny_account_list


class IfunnyBusinessFriend:

    def __init__(self, authorization, log, redis_obj, user_agent):

        self.log = log

        self.redis_obj = redis_obj

        self.user_agent = user_agent

        self.authorization = authorization

        self.account_login = self.redis_obj.redis_client(account_login_db)

        self.ifunny_business = IfunnyBusiness(self.authorization,
                                              self.log,
                                              self.user_agent)

    def ifunny_base_add_friend(self, user_key, account, ifunny_chat_mess):

        flag = False

        base_access_token = self.account_login.get(account + "access_token").decode("utf-8")

        status = self.ifunny_business.ifunny_subscribers(user_id=user_key[0].decode("utf-8"),
                                                         authorization_bearer=base_access_token)

        if status["status"] == 200:

            try:

                messenger_token = self.account_login.hget(account, "messenger_token")

                if not messenger_token:

                    messenger_token = ifunny_chat_mess(account=account,
                                                       redis_num=self.account_login,
                                                       user_agent=self.user_agent)

                    if messenger_token:
                        self.account_login.hset(account, "messenger_token", messenger_token)

                else:

                    messenger_token = messenger_token.decode("utf-8")

                myself_id = self.account_login.hget(account, "id").decode("utf-8")

                if messenger_token:

                    fla = self.ifunny_business.ifunny_message(myself=myself_id,
                                                              user_id=user_key[0].decode("utf-8"),
                                                              access_token=messenger_token,
                                                              bearer=base_access_token,
                                                              redis_con=self.account_login)

                    if fla:
                        self.log.info("{} exec {} finish".format(account, user_key))

                    flag = fla

            except Exception as e:

                print(e)

        return flag

    def ifunny_add_friend(self, account, password):

        ifunny_login = LoginInfo(self.log)

        if not self.account_login.get(account+":login_info"):

            ifunny_login.ifunny_login(account=account,
                                      password=password,
                                      authorization=self.authorization,
                                      user_agent=self.user_agent,
                                      redis_num=self.account_login)

            self.account_login.set(account+":login_info","1")

            self.account_login.expire(account+":login_info",24*60*60)

        ifunny_friend_func = partial(self.ifunny_base_add_friend,
                                     account=account,
                                     ifunny_chat_mess=ifunny_login.ifunny_chat_mess)

        ifunny_add_user = BeiDouBusiness(redisObject=self.redis_obj,
                                         log=self.log,
                                         app_name="ifunny_spider")

        ifunny_add_user.base_add_user(account=account, func=ifunny_friend_func)


class IfunnyInitSpider:

    def __init__(self, log, redis_obj, authorization, user_agent):

        self.log = log

        self.redis_obj = redis_obj

        self.user_agent = user_agent

        self.authorization = authorization

        self.ifunny_dispatch = BeiDouBase(redisObject=self.redis_obj)

        self.account_login = self.redis_obj.redis_client(account_login_db)

        self.ifunny_business = IfunnySpider(log=self.log, user_agent=user_agent,
                                            redis_obj=self.redis_obj,
                                            authorization=self.authorization)

    def ifunny_init_spider(self):

        open_save_func = partial(self.ifunny_dispatch.base_multi_save_func,
                                 func=self.ifunny_dispatch.base_data_save_func)

        self.ifunny_business.init_data(func=open_save_func, user_agent=self.user_agent)

    def ifunny_init_user_spider(self, account):

        ifunny_spider_user = BeiDouSpider(redisObject=self.redis_obj,
                                          log=self.log,
                                          app_name="ifunny_spider")

        ifunny_spider_user.beidou_spider_follow(account=account, func=self.ifunny_business.init_user)


class IfunnyPush:

    def __init__(self, authorization, log, redis_obj, user_agent,push_obj):

        self.log = log

        self.redis_obj = redis_obj

        self.user_agent = user_agent

        self.push_obj = push_obj

        self.base_authorization = authorization

        self.account_login = self.redis_obj.redis_client(account_login_db)

        self.ifunny_dispatch = BeiDouBase(redisObject=self.redis_obj)

        self.account_login = self.redis_obj.redis_client(account_login_db)

        self.ifunny_business = IfunnyBusiness(self.base_authorization, self.log, self.user_agent)

        self.push_uuid_filter = self.push_obj.redis_client(push_ifunny_uuid_db)

        self.push_account_filter = self.push_obj.redis_client(push_ifunny_user_db)

    def ifunny_push(self, user_key, account, access_token,
                    ifunny_chat_mess, bother, push_photo_video_name=None,
                    push_photo_video_path=None, push_photo_video_type=None):

        self.log.info("{} try exce {}:finish".format(account, user_key[0]))

        flag = False

        try:

            messenger_token = self.account_login.hget(account, "messenger_token")

            if not messenger_token:

                messenger_token = ifunny_chat_mess(account, self.account_login)

                if messenger_token:
                    self.account_login.hset(account, "messenger_token", messenger_token)

            else:

                messenger_token = messenger_token.decode("utf-8")

            myself_id = self.account_login.hget(account, "id").decode("utf-8")

            if messenger_token:

                flag = self.ifunny_business.ifunny_send_photo(i_funny=self.ifunny_business,
                                                              myself=myself_id,
                                                              user_id=user_key[0].decode("utf-8"),
                                                              messenger_token=messenger_token,
                                                              access_token=access_token,
                                                              redis_conn=self.account_login,
                                                              photo_name=push_photo_video_name,
                                                              photo_path=push_photo_video_path,
                                                              post_type=push_photo_video_type,
                                                              bother=bother)
        except Exception as e:

            self.log.info("{} exce {}:fail".format(account, user_key[0]))

            print(e)

        return flag

    def ifunny_add_push(self, account, login_func, bother):

        push_photo_video_name = None

        push_photo_video_path = None

        push_photo_video_type = None

        if bother == "all":

            push_photo_video_name = ifunny_photo_video_name

            push_photo_video_path = ifunny_photo_video_path

            push_photo_video_type = ifunny_photo_video_type

        access_token = self.account_login.get(account + "access_token").decode("utf-8")

        ifunny_friend_func = partial(self.ifunny_push,
                                     account=account,
                                     access_token=access_token,
                                     bother="all",
                                     ifunny_chat_mess=login_func.ifunny_chat_mess,
                                     push_photo_video_name=push_photo_video_name,
                                     push_photo_video_path=push_photo_video_path,
                                     push_photo_video_type=push_photo_video_type)

        #bother is all{video,text}:text is only text:video is only video

        self.uuid_assigned = self.redis_obj.redis_client(uuid_assigned_db)

        ifunny_add_user = BeiDouBusiness(redisObject=self.redis_obj,
                                         log=self.log,
                                         app_name="ifunny_spider",
                                         push_uuid_filter=self.push_uuid_filter,
                                         push_account_filter=self.push_account_filter)

        ifunny_add_user.base_add_user(account=account,
                                      func=ifunny_friend_func,
                                      is_use_account=True,
                                      source_redis=self.uuid_assigned)
