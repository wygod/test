#-*- coding:utf-8 -*-
#聊天文件
amino_one = ["hi,Nice to meet you",
             "I like traveling. Do you like traveling, too?",
             "Great ~ I think we can be friends and share the interesting things during the trip. I hope you can join the travel group on Facebook and meet more people who like to travel.The name of the group is:China's tourism"]

amino_two = ["Hello, friend. I'm from China. What about you?",
             "Nice to meet you. I'm a Chinese traveler",
             "I hope you can join the travel group on Facebook, you can see the scenery of China,you can know the destination you want to reach if you want to travel to China.The name of the group is: China's tourism"]

amino_three = ["Hello, friend,Nice to meet you.",
               "I am a traveler from China, if you also like to travel I think we can become friends",
               "You can join my group on Facebook: China's tourism.You can share the beautiful scenery around you in the group. If you want to travel to China, you can also check out my post, which will be helpful."]

moot_one = ["hi,Nice to meet you",
             "I like traveling. Do you like traveling, too?",
             "Great ~ I think we can be friends and share the interesting things during the trip. I hope you can join the travel group on Facebook and meet more people who like to travel.The name of the group is:China's tourism"]

moot_two = ["Hello, friend. I'm from China. What about you?",
             "Nice to meet you. I'm a Chinese traveler",
             "I hope you can join the travel group on Facebook, you can see the scenery of China,you can know the destination you want to reach if you want to travel to China.The name of the group is: China's tourism"]

moot_three = ["Hello, friend,Nice to meet you.",
               "I am a traveler from China, if you also like to travel I think we can become friends",
               "You can join my group on Facebook: China's tourism.You can share the beautiful scenery around you in the group. If you want to travel to China, you can also check out my post, which will be helpful."]



ifunny_context = "hello"

wegamers_context = "hi,man are we friend?"

moot_context = ""

tumblr_context = "hi"