# -*- coding:utf-8 -*-

default_host = "172.31.0.36"

default_password = "sentinel"

# 配置文件
# amino爬取数据存储的redis port
amino_spider_port = 6378
# amino广告过滤数据存储的redis port
amino_push_port = 7378
# redis host
amino_push_host = amino_spider_host = default_host
# redis password
amino_push_password = amino_spider_password = default_password

# 配置文件
# ifunny爬取数据存储的redis port
ifunny_spider_port = 6374
# amino广告过滤数据存储的redis port
ifunny_push_port = 7374
# redis host
ifunny_push_host = "172.31.0.247" 
ifunny_spider_host = default_host
# redis password
ifunny_push_password = ifunny_spider_password = "sentinel"#default_password

# 配置文件
# moot爬取数据存储的redis port
moot_spider_port = 6375
# amino广告过滤数据存储的redis port
moot_push_port = 7375
# redis host
moot_push_host = moot_spider_host = default_host
# redis password
moot_push_password = moot_spider_password = default_password

# 配置文件
# tumblr爬取数据存储的redis port
tumblr_spider_port = 6369
# amino广告过滤数据存储的redis port
tumblr_push_port = 7369
# redis host
tumblr_push_host = tumblr_spider_host = "172.31.0.164"#default_host
# redis password
tumblr_push_password = tumblr_spider_password = "sentinel"#default_password

# 配置文件
# wegamers爬取数据存储的redis port
wegamers_spider_port = 6377
# amino广告过滤数据存储的redis port
wegamers_push_port = 7377
# redis host
wegamers_push_host = wegamers_spider_host = default_host
# redis password
wegamers_push_password = wegamers_spider_password = default_password
