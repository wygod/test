# -*-coding:utf-8-*-
# 非广告类
# redis 1 存储数据
data_db = 2

# redis 2 存储uuid 和数据

uuid_data_db = 3

# redis 3 存储uuid

uuid_db = 4

# redis 3 过滤已经爬过用户

crawled_uuid_db = 1

# redis 4 存储分配账号数据

account_assign_db = 1

# redis 5 存储已经分配的uuid

uuid_assigned_db = 5

# redis 6 存储已经加过的好友

assigned_friend_db = 6

# redis 7 存储加过好友uuid

account_uuid_assigned_db = 7

# redis 8 存储已经发过信息的用户

data_send_db = 8

# redis 9 不能使用的账号

account_discarded_db = 9

# redis 10 登陆信息

account_login_db = 10

# redis 11 chat

account_chat_db = 11

# redis 12 url filter(amino):record spider statue

url_filter_db = 12

# redis 13 account_url filter(amino)

account_url_filter_db = 13

# redis 14 account_filter(amino)

account_filter_db = 14

# redis 15 account_filter(amino)

crawled_data_db = 15

# 广告类

# push database
# amino
push_amino_user_db = 1
push_amino_uuid_db = 2

# ifunny
push_ifunny_user_db = 3
push_ifunny_uuid_db = 4

# moot
push_moot_user_db = 5
push_moot_uuid_db = 6

# tumblr
push_tumblr_user_db = 7
push_tumblr_uuid_db = 8

# wegamer
push_wegamer_user_db = 9
push_wegamer_uuid_db = 10

# aritripp
push_aritripp_user_db = 11
push_aritripp_uuid_db = 12
