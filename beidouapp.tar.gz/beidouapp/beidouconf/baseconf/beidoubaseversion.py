# -*- coding:utf-8 -*-
# 初始主题刷新时间
pl_day = 5

jvm = u"/usr/lib/jvm/java-8-openjdk-amd64/jre/lib/amd64/server/libjvm.so"#u"C:/Program Files/Java/jdk1.8.0_231/jre/bin/server/jvm.dll"
#"/home/server/soft/jdk1.8.0_231/jre/lib/amd64/server/libjvm.so"

moot_web_js = "/home/server/beidouapp/beidoulib/jslib/moot/g.js"

jar_java = ["/home/server/beidouapp/beidoulib/javalib/moot_java/com.moot.cre-1.0-SNAPSHOT.jar",
             "/home/server/beidouapp/beidoulib/javalib/moot_java/testModulenew.jar","/home/server/beidouapp/beidoulib/javalib/tumblr_java/commons-codec-1.13.jar",
               "/home/server/beidouapp/beidoulib/javalib/tumblr_java/lib.jar"]
