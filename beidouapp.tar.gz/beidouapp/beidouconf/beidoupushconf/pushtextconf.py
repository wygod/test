#-*- coding:utf-8 -*-
#广告文件
amino_push_context = "http://tx-e.qwerui.com/android/pe/20200310/index.html ,Brand new Pokemon game- Pokémon War is trending now! Featuring nostalgic Nintendo Pokémon, classic royal battle. Meanwhile adding more revolutionary game mode and antagonists to satisfy what you've been longing to be a real Pokémon trainer.No more hesitation, download and plunge into this Pokémon War!"
#"Do you want to fight your friends on a global battlefield?Are you good at defense or offense?Can you beat many with a few?Join the COE and discover more surprises!Click the link below and copy to the browser to download, https://go\.onelink\.me/YBeb/EOEIOS30"


ifunny_push_context = ""

moot_push_context = ""

wegame_push_context = "www.laosiji995.com ,The site features some of the most beautiful women from around the world.You can browse freely and don't worry about anything.One porn experience isn't just about finding the perfect backdrop and the dirtiest porn videos.Many factors determine whether or not you have an unforgettable orgasm."#"http://tx-e.qwerui.com/android/pe/20200310/index.html ,Brand new Pokemon game- Pokémon War is trending now! Featuring nostalgic Nintendo Pokémon, classic royal battle. Meanwhile adding more revolutionary game mode and antagonists to satisfy what you've been longing to be a real Pokémon trainer.No more hesitation, download and plunge into this Pokémon War!"

tumblr_push_context = ""