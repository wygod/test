# -*- coding:utf-8 -*-

ifunny_photo_video_name = "yiux.mp4"
ifunny_photo_video_path = "D:\\Users\\"
ifunny_photo_video_type = "video/mp4"

moot_url = None
moot_image_url = None

tumblr_photo_video_name = None
tumblr_photo_video_path = None

#video 信息

wegame_video_info = {"media_length":989758,
              "media_play_length":14,
              "thumb_img_length":9722,
              "pc_media_md5":"0fdcb47b24deede6412d341f8888c754",
              "pc_media_url":"http://wegamers.176.com/GameIM/Msg/Video/0fdcb47b24deede6412d341f8888c754_5_989758",
              "pc_thumb_img_md5":"66dd156fc923b53d9a5f9617d8942b93",
              "pc_thumb_img_url":"http://wegamers.176.com/GameIM/Msg/Image/66dd156fc923b53d9a5f9617d8942b93_3_9722"}
