# -*- coding:utf-8 -*-
# 账号 密码
amino_account_list = [("direknfqrh@gmail.com", "beidou01"), ("musewctazh@gmail.com", "beidou01"),
                      ("repoltnwru@gmail.com", "beidou01"), ("athlcljgyx@gmail.com", "beidou01"),
                      ("varihqejf@gmail.com", "beidou01"), ("studpecdl@gmail.com", "beidou01"),
                      ("patiwnlyo@gmail.com", "beidou01"), ("cylinrjsk@gmail.com", "beidou01"),
                      ("trolntoazg@gmail.com", "beidou01"), ("foreovfiy@gmail.com", "beidou01"),
                      ("inatbxdiys@gmail.com", "beidou01"), ("empidslfq@gmail.com", "beidou01"),
                      ("activsfxay@gmail.com", "beidou01"), ("trouslspor@gmail.com", "beidou01"),
                      ("finanvotnzg@gmail.com", "beidou01"), ("culticategi@gmail.com", "beidou01"),
                      ("encounxdmw@gmail.com", "beidou01"), ("vegetewnc@gmail.com", "beidou01"),
                      ("sideyqtwdv@gmail.com", "beidou01"), ("atmejzblk@gmail.com", "beidou01"),
                      ("reotbewupyax@gmail.com", "beidou01"), ("evisfcgxkvz@gmail.com", "beidou01"),
                      ("mpagtsicz@gmail.com", "beidou01"), ("ensiauinr@gmail.com", "beidou01"),
                      ("partiqmkgaz@gmail.com", "beidou01"), ("diplokpmu@gmail.com", "beidou01"),
                      ("layouuwrx@gmail.com", "beidou01"), ("threnzclbw@gmail.com", "beidou01"),
                      ("tempselhx@gmail.com", "beidou01")]

amino_account_push_list = [("direknfqrh@gmail.com", "beidou01"), ("musewctazh@gmail.com", "beidou01"),
                           ("repoltnwru@gmail.com", "beidou01"), ("athlcljgyx@gmail.com", "beidou01"),
                           ("varihqejf@gmail.com", "beidou01"), ("studpecdl@gmail.com", "beidou01"),
                           ("patiwnlyo@gmail.com", "beidou01"), ("cylinrjsk@gmail.com", "beidou01"),
                           ("trolntoazg@gmail.com", "beidou01"), ("foreovfiy@gmail.com", "beidou01"),
                           ("inatbxdiys@gmail.com", "beidou01"), ("empidslfq@gmail.com", "beidou01"),
                           ("activsfxay@gmail.com", "beidou01"), ("trouslspor@gmail.com", "beidou01"),
                           ("finanvotnzg@gmail.com", "beidou01"), ("culticategi@gmail.com", "beidou01"),
                           ("encounxdmw@gmail.com", "beidou01"), ("vegetewnc@gmail.com", "beidou01"),
                           ("sideyqtwdv@gmail.com", "beidou01"), ("atmejzblk@gmail.com", "beidou01"),
                           ("reotbewupyax@gmail.com", "beidou01"), ("evisfcgxkvz@gmail.com", "beidou01"),
                           ("mpagtsicz@gmail.com", "beidou01"), ("ensiauinr@gmail.com", "beidou01")]

amino_account_add_list = [("partiqmkgaz@gmail.com", "beidou01"), ("diplokpmu@gmail.com", "beidou01"),
                          ("layouuwrx@gmail.com", "beidou01"), ("threnzclbw@gmail.com", "beidou01"),
                          ("tempselhx@gmail.com", "beidou01")]

ifunny_account_list = [("direknfqrh@gmail.com", "beidou01"), ("athlcljgyx@gmail.com", "beidou01"),
                       ("varihqejf@gmail.com", "beidou01"), ("studpecdl@gmail.com", "beidou01"),
                       ("inatbxdiys@gmail.com", "beidou01"), ("repoltnwru@gmail.com", "beido01"),
                       ("patiwnlyo@gmail.com", "beidou01"), ("cylinrjsk@gmail.com", "beidou01"),
                       ("inatbxdiys@gmail.com", "beidou01"), ("empidslfq@gmail.com", "beidou01"),
                       ("finanvotnzg@gmail.com", "beidou01"), ("culticategi@gmail.com", "beidou01"),
                       ("encounxdmw@gmail.com", "beidou01"), ("vegetewnc@gmail.com", "beidou01"),
                       ("sideyqtwdv@gmail.com", "beidou01"), ("atmejzblk@gmail.com", "beidou01")]

ifunny_account_push_list = [("inatbxdiys@gmail.com", "beidou01"), ("repoltnwru@gmail.com", "beido01"),
                            ("patiwnlyo@gmail.com", "beidou01"), ("cylinrjsk@gmail.com", "beidou01"),
                            ("inatbxdiys@gmail.com", "beidou01"), ("empidslfq@gmail.com", "beidou01"),
                            ("finanvotnzg@gmail.com", "beidou01"), ("culticategi@gmail.com", "beidou01"),
                            ("encounxdmw@gmail.com", "beidou01"), ("vegetewnc@gmail.com", "beidou01"),
                            ("sideyqtwdv@gmail.com", "beidou01"), ("atmejzblk@gmail.com", "beidou01")]

ifunny_account_add_list = [("2667946747@qq.com","sunking,09")]#[("direknfqrh@gmail.com", "beidou01"), ("athlcljgyx@gmail.com", "beidou01"),
                           #("varihqejf@gmail.com", "beidou01")]

moot_account_list = [("direknfqrh@gmail.com", "beidou01"), ("athlcljgyx@gmail.com", "beidou01"),
                     ("varihqejf@gmail.com", "beidou01"), ("studpecdl@gmail.com", "beidou01"),
                     ("inatbxdiys@gmail.com", "beidou01"), ("repoltnwru@gmail.com", "beido01"),
                     ("patiwnlyo@gmail.com", "beidou01"), ("cylinrjsk@gmail.com", "beidou01"),
                     ("inatbxdiys@gmail.com", "beidou01"), ("empidslfq@gmail.com", "beidou01"),
                     ("finanvotnzg@gmail.com", "beidou01"), ("culticategi@gmail.com", "beidou01"),
                     ("encounxdmw@gmail.com", "beidou01"), ("vegetewnc@gmail.com", "beidou01"),
                     ("sideyqtwdv@gmail.com", "beidou01"), ("atmejzblk@gmail.com", "beidou01")]

moot_account_push_list = [("inatbxdiys@gmail.com", "beidou01"), ("repoltnwru@gmail.com", "beido01"),
                          ("patiwnlyo@gmail.com", "beidou01"), ("cylinrjsk@gmail.com", "beidou01"),
                          ("inatbxdiys@gmail.com", "beidou01"), ("empidslfq@gmail.com", "beidou01"),
                          ("finanvotnzg@gmail.com", "beidou01"), ("culticategi@gmail.com", "beidou01"),
                          ("encounxdmw@gmail.com", "beidou01"), ("vegetewnc@gmail.com", "beidou01"),
                          ("sideyqtwdv@gmail.com", "beidou01"), ("atmejzblk@gmail.com", "beidou01")]

moot_account_add_list = [("direknfqrh@gmail.com", "beidou01"), ("athlcljgyx@gmail.com", "beidou01"),
                         ("varihqejf@gmail.com", "beidou01")]

tumblr_account_list = [("tempselhx@gmail.com", "beidou01"), ("layouuwrx@gmail.com", "beidou01"),
                       ("threnzclbw@gmail.com", "beidou01"), ("diplokpmu@gmail.com", "beidou01"),
                       ("partiqmkgaz@gmail.com", "beidou01"), ("ensiauinr@gmail.com", "beidou01"),
                       ("mpagtsicz@gmail.com", "beidou01"), ("evisfcgxkvz@gmail.com", "beidou01"),
                       ("reotbewupyax@gmail.com", "beidou01"), ("atmejzblk@gmail.com", "beidou01"),
                       ("sideyqtwdv@gmail.com", "beidou01"), ("vegetewnc@gmail.com", "beidou01"),
                       ("encounxdmw@gmail.com", "beidou01"), ("finanvotnzg@gmail.com", "beidou01"),
                       ("culticategi@gmail.com", "beidou01"), ("trouslspor@gmail.com", "beidou01"),
                       ("activsfxay@gmail.com", "beidou01"), ("empidslfq@gmail.com", "beidou01"),
                       ("inatbxdiys@gmail.com", "beidou01"), ("foreovfiy@gmail.com", "beidou01"),
                       ("trolntoazg@gmail.com", "beidou01")]

tumblr_account_push_list = [("diplokpmu@gmail.com", "beidou01"),
                            ("partiqmkgaz@gmail.com", "beidou01"), ("ensiauinr@gmail.com", "beidou01"),
                            ("mpagtsicz@gmail.com", "beidou01"), ("evisfcgxkvz@gmail.com", "beidou01"),
                            ("reotbewupyax@gmail.com", "beidou01"), ("atmejzblk@gmail.com", "beidou01"),
                            ("sideyqtwdv@gmail.com", "beidou01"), ("vegetewnc@gmail.com", "beidou01"),
                            ("encounxdmw@gmail.com", "beidou01"), ("finanvotnzg@gmail.com", "beidou01"),
                            ("culticategi@gmail.com", "beidou01"), ("trouslspor@gmail.com", "beidou01"),
                            ("activsfxay@gmail.com", "beidou01"), ("empidslfq@gmail.com", "beidou01"),
                            ("inatbxdiys@gmail.com", "beidou01"), ("foreovfiy@gmail.com", "beidou01"),
                            ("trolntoazg@gmail.com", "beidou01")]

tumblr_account_add_list = [("tempselhx@gmail.com", "beidou01"),
                           ("layouuwrx@gmail.com", "beidou01"),
                           ("threnzclbw@gmail.com", "beidou01")]

wegamer_account_list = [("direknfqrh@gmail.com", "beidou01"), ("studpecdl@gmail.com", "beidou01"),
                        ("cylinrjsk@gmail.com", "beidou01"), ("trolntoazg@gmail.com", "beidou01"),
                        ("repoltnwru@gmail.com", "beidou01"), ("foreovfiy@gmail.com", "beidou01"),
                        ("inatbxdiys@gmail.com", "beidou01"), ("empidslfq@gmail.com", "beidou01"),
                        ("activsfxay@gmail.com", "beidou01"), ("trouslspor@gmail.com", "beidou01"),
                        ("finanvotnzg@gmail.com", "beidou01"), ("culticategi@gmail.com", "beidou01"),
                        ("vegetewnc@gmail.com", "beidou01"), ("sideyqtwdv@gmail.com", "beidou01"),
                        ("atmejzblk@gmail.com", "beidou01"), ("reotbewupyax@gmail.com", "beidou01"),
                        ("evisfcgxkvz@gmail.com", "beidou01"), ("mpagtsicz@gmail.com", "beidou01"),
                        ("ensiauinr@gmail.com", "beidou01"), ("partiqmkgaz@gmail.com", "beidou01"),
                        ("diplokpmu@gmail.com", "beidou01"), ("layouuwrx@gmail.com", "beidou01"),
                        ("threnzclbw@gmail.com", "beidou01"), ("tempselhx@gmail.com", "beidou01")]

wegamer_account_push_list = [("direknfqrh@gmail.com", "beidou01"), ("studpecdl@gmail.com", "beidou01"),
                             ("cylinrjsk@gmail.com", "beidou01"), ("trolntoazg@gmail.com", "beidou01"),
                             ("repoltnwru@gmail.com", "beidou01"), ("foreovfiy@gmail.com", "beidou01"),
                             ("inatbxdiys@gmail.com", "beidou01"), ("empidslfq@gmail.com", "beidou01"),
                             ("activsfxay@gmail.com", "beidou01"), ("trouslspor@gmail.com", "beidou01")]

wegamer_account_add_list = [("finanvotnzg@gmail.com", "beidou01"), ("culticategi@gmail.com", "beidou01"),
                            ("vegetewnc@gmail.com", "beidou01"), ("sideyqtwdv@gmail.com", "beidou01"),
                            ("atmejzblk@gmail.com", "beidou01"), ("reotbewupyax@gmail.com", "beidou01"),
                            ("evisfcgxkvz@gmail.com", "beidou01"), ("mpagtsicz@gmail.com", "beidou01"),
                            ("ensiauinr@gmail.com", "beidou01"), ("partiqmkgaz@gmail.com", "beidou01"),
                            ("diplokpmu@gmail.com", "beidou01"), ("layouuwrx@gmail.com", "beidou01"),
                            ("threnzclbw@gmail.com", "beidou01"), ("tempselhx@gmail.com", "beidou01")]
