#-*- coding:utf-8 -*-

import redis

class RedisObject:

    #存储函数

    def __init__(self, host, port, password):

        self.redis_host = host

        self.redis_port = port

        self.redis_password = password

    def redis_client(self, database):

        redis_connect = redis.Redis(host=self.redis_host,
                                    port=self.redis_port,
                                    password=self.redis_password,
                                    db=database)
        return redis_connect
