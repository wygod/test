#-*-coding:utf-8-*-
import logging
import datetime

from beidouloginstance.logfileconf import log_file

class BeibouLog:

    def __init__(self):

        pass

    def beidou_create_log(self,app_name):

        logging.basicConfig(level=1, format='%(asctime)s %(filename)s[line:%(lineno)d] %(levelname)s %(message)s',
                                    datefmt='%a, %d %b %Y %H:%M:%S',
                                    filename=log_file + app_name + str(
                                        datetime.datetime.strftime(datetime.datetime.now(),
                                                                   "%Y%m%d%H%M")) + ".log",
                                    filemode='w')

        return logging.getLogger(app_name)