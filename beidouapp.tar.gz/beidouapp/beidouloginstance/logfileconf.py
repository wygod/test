#-*- coding:utf-8 -*-

import platform

#日志文件
log_file = "/home/server/log/" if not "windows" in platform.platform().lower() else "D:\\log\\"
