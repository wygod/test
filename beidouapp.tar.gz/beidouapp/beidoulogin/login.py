# -*-coding:utf-8-*-
import sys
import json
import copy
import time
import uuid
import hashlib
import requests
from urllib import parse
from datetime import datetime
from urllib.parse import urlencode
from requests.exceptions import SSLError, ProxyError

from beidouotherscript.tumblr_script import TumblerBaseJava
from beidouotherscript.moot_script import MootOtherJavaScript, MootOtherJScript


class LoginInfo:
    # 登陆功能

    def __init__(self, log):

        self.log = log

    def amino_login(self,
                    amino_account,
                    amino_password,
                    amino_ndcdeviceid,
                    amino_smdeviceid,
                    amino_user_agent,
                    amino_redis_num):

        self.log.info("{} : {} try beidoulogin amino".format(time.asctime(), amino_account))

        login_url = "https://service.narvii.com/api/v1/g/s/auth/login"

        login_header = {
            "NDCLANG": "en",
            "NDC-MSG-SIG": "ATSib2qv0gNMaDEnkP9cpOz9FvWg",
            "ndcdeviceid": amino_ndcdeviceid,
            "smdeviceid": amino_smdeviceid,
            "Accept-Language": "zh-CN",
            "Content-Type": "application/json; charset=utf-8",
            "User-Agent": amino_user_agent,
            "Host": "service.narvii.com",
            "Connection": "Keep-Alive",
            "Accept-Encoding": "gzip"
        }

        login_data = {
            "email": amino_account,
            "v": 2,
            "secret": "0 {}".format(amino_password),
            "deviceID": amino_ndcdeviceid,
            "clientType": 100,
            "action": "normal",
            "timestamp": int(time.time() * 1000)
        }

        login_data = requests.post(url=login_url, headers=login_header, data=json.dumps(login_data), verify=False)

        print(login_data.text)

        if login_data.status_code == 200:
            login_message = json.loads(login_data.text)

            # 获取登陆信息

            auid_init = login_message["auid"]

            uid_init = login_message["account"]["uid"]

            sid_init = login_message["sid"]

            secret_init = login_message["secret"]

            amino_redis_num.set(amino_account + ":auid", auid_init)

            amino_redis_num.set(amino_account + ":uid", uid_init)

            amino_redis_num.set(amino_account + ":sid", sid_init)

            amino_redis_num.set(amino_account + ":secret", secret_init)

            self.log.info("{} : {} beidoulogin successful ".format(time.asctime(), amino_account))

    def ifunny_chat_mess(self,
                         account,
                         redis_num,
                         user_agent):

        # 获取聊天messenger_token

        access_token = redis_num.get(account + "access_token").decode("utf-8")

        url = "https://api.ifunny.mobi/v4/account/activate_chats"

        header = {
            "ApplicationState": "1",
            "Accept-Language": "zh-CN",
            "Accept": "application/json,image/webp,video/mp4",
            "Authorization": "Bearer {}".format(access_token),
            "Host": "api.ifunny.mobi",
            "Connection": "Keep-Alive",
            "Accept-Encoding": "gzip",
            "User-Agent": user_agent
        }

        message = requests.post(url=url, headers=header, verify=False)

        try:

            return json.loads(message.text)["data"]["messenger_token"]

        except Exception as e:

            print(e)

            return None

    def ifunny_access_token(self,
                            account,
                            authorization_bearer,
                            user_agent,
                            redis_num):

        # 获取用户access_token,id

        gmt_format = '%a, %d %b %Y %H:%M:%S GMT'

        access_url = "https://api.ifunny.mobi/v4/account"

        access_header = {
            "applicationstate": "1",
            "authorization": "Bearer {}".format(authorization_bearer),
            "accept-language": "zh-Hans-CN",
            "accept": "application/json,image/webp,video/mp4",
            "ifunny-project-id": "iFunny",
            "accept-encoding": "gzip",
            "if-modified-since": datetime.utcnow().strftime(gmt_format),
            "user-agent": user_agent
        }

        self.log.info("{}:try to get user {} base info".format(time.asctime(), account))

        access_data = requests.get(url=access_url, headers=access_header, verify=False)

        access_data_s = json.loads(access_data.text)

        redis_num.hset(account, "subscriptions", access_data_s["data"]["num"]["subscriptions"])

        redis_num.hset(account, "subscribers", access_data_s["data"]["num"]["subscribers"])

        if "messenger_token" in access_data_s["data"].keys():

            redis_num.hset(account, "messenger_token", access_data_s["data"]["messenger_token"])

            self.log.info("{}:get user {} messenger_token:successful".format(time.asctime(), account))

        else:

            mess_token = self.ifunny_chat_mess(account=account,
                                               redis_num=redis_num,
                                               user_agent=user_agent)

            if mess_token:
                redis_num.hset(account, "messenger_token", mess_token)

                self.log.info("{}:get user {} messenger_token:successful".format(time.asctime(), account))

        redis_num.hset(account, "id", access_data_s["data"]["id"])

        self.log.info("{}:get user {} id:successful".format(time.asctime(), account))

    def ifunny_login(self,
                     account,
                     password,
                     authorization,
                     user_agent,
                     redis_num):

        # 登陆账号

        login_url = "https://api.ifunny.mobi/v4/oauth2/token"

        login_header = {"accept": "application/json", "accept-language": "zh-Hans-CN", "ifunny-project-id": "iFunny",
                        "applicationstate": "1", "content-type": "application/x-www-form-urlencoded",
                        "accept-encoding": "gzip", "user-agent": user_agent,
                        "authorization": authorization}

        login_data = {
            "grant_type": "password",
            "username": account,
            "password": password
        }

        print("is login")

        login_data = requests.post(url=login_url, headers=login_header, data=urlencode(login_data), verify=False)

        login_message = json.loads(login_data.text)

        print(login_message)

        if not 'error' in login_message.keys():

            access_token_init = login_message["access_token"]

            redis_num.set(account + "access_token", access_token_init)

            redis_num.expire(account + "access_token", 24 * 60 * 60)

            self.ifunny_access_token(account=account,
                                     authorization_bearer=access_token_init,
                                     redis_num=redis_num,
                                     user_agent=user_agent)

            self.log.info("{}:get user {} login:successful".format(time.asctime(), account))

            return True

        else:

            self.log.info("{}:get user {} login:fail,{}".format(time.asctime(), account, login_message["error"]))

            return False

    def moot_login(self, account,
                   password,
                   device_id,
                   user_agent,
                   app_token_signature):

        print("go")

        base_header = {
            "deviceId": device_id,
            "DEVICE-TIME-ZONE-ID": "Asia/Shanghai",
            "country": "CN",
            "User-agent": user_agent,
            "version": "20140411",
            "DEVICE-TIME-ZONE-MS-OFFSET": "28800000",
            "language": "zh_CN",
            "Accept-Encoding": "gzip",
            "Host": "usw-api.moot.us",
            "Connection": "Keep-Alive"
        }

        print("login")

        credential = self.moot_token(header=base_header,
                                     app_token_signature=app_token_signature)

        email_signature = app_token_signature.signature()

        password_encode = app_token_signature.encode_password(password)

        print(password_encode)

        email_login = "https://usw-api.moot.us/session/email"

        base_header["credential"] = credential
        base_header["signature"] = email_signature
        base_header["Content-Type"] = "application/json; charset=UTF-8"

        data_email_web = {
            "email": account,
            "password": password_encode,
            "deviceId": device_id,
            "deviceModel": "samsung SM-G955F",
            "deviceType": "8",
            "language": "zh_CN",
            "servicePushAgreement": "false"
        }
        print("loginning")

        try:

            data_email = requests.post(email_login, headers=base_header, data=json.dumps(data_email_web), verify=False)

            print(data_email.text)

            tokens = json.loads(data_email.text)["data"]["authorization"]["token"]

            user_no = json.loads(data_email.text)["data"]["authorization"]["userNo"]

            return user_no, tokens, data_email
        except Exception as e:

            return None, None, None

    def moot_token(self,
                   header,
                   app_token_signature):

        signature = app_token_signature.signature()

        print(signature)

        moot_header = copy.deepcopy(header)

        moot_url = "https://usw-api.moot.us/auth/token"

        moot_header["signature"] = signature

        dat = requests.get(moot_url, headers=moot_header, verify=False)

        print(dat.text)

        token = json.loads(dat.text)["data"]["token"]

        credential = app_token_signature.credential(token)

        print(credential)

        return credential

    def tumblr_auth_email(self,
                          account,
                          password,
                          header,
                          tumbler_base_java):

        # 验证账号，登陆后的账号需要验证

        self.log.info("{}:{} try to auth".format(time.asctime(), account))

        from_data = {"force_mode": 1, 'email': account}

        header['x-identifier'] = str(uuid.uuid4())

        handle_string = tumbler_base_java.tumbler_make_login(account, password)

        sig = tumbler_base_java.tumbler_sig(handle_string)

        oauth_nonce = str(tumbler_base_java.tumbler_oauth_nonce())

        header[
            'authorization'] = "OAuth oauth_consumer_key=\"BUHsuO5U9DF42uJtc8QTZlOmnUaJmBJGuU1efURxeklbdiLn9L\", oauth_nonce=\"" \
                               + oauth_nonce + "\", oauth_signature=\"" + sig + \
                               "\", oauth_signature_method=\"HMAC-SHA1\", oauth_timestamp=\"" + \
                               str(tumbler_base_java.tumbler_timestamp()) + \
                               "\", oauth_version=\"1.0\""

        response = requests.post("https://api.tumblr.com/v2/auth", headers=header,
                                 data=parse.urlencode(from_data), verify=False)

        if response.status_code == 200:

            self.log.info("{}:{} try to auth:successful".format(time.asctime(), account))

            return True

        else:

            self.log.info("{}:{} try to auth:fail".format(time.asctime(), account))

            return False

    def tumblr_user_info(self, account, header, redis_num, tumbler_base_java):

        # 获取用户的基本信息

        self.log.info("{}:{} try to get info".format(time.asctime(), account))

        try:

            oauth_token = redis_num.get(account + ":oauth_token").decode("utf-8")

            oauth_token_secret = redis_num.get(account + ":oauth_token_secret").decode("utf-8")

            handle_string = tumbler_base_java.tumbler_make_user_info(oauth_token)

            sig = tumbler_base_java.tumbler_sig(handle_string, oauth_token_secret)

            oauth_nonce = str(tumbler_base_java.tumbler_oauth_nonce())

            header[
                'authorization'] = "OAuth oauth_consumer_key=\"BUHsuO5U9DF42uJtc8QTZlOmnUaJmBJGuU1efURxeklbdiLn9L\",oauth_nonce=\"" + \
                                   oauth_nonce + "\", oauth_signature=\"" + sig + \
                                   "\", oauth_signature_method=\"HMAC-SHA1\", oauth_timestamp=\"" + \
                                   str(tumbler_base_java.tumbler_timestamp()) + \
                                   "\", oauth_token=\"" + oauth_token + "\", oauth_version=\"1.0\""

            header['x-identifier-date'] = str(time.time())

            header['x-identifier'] = str(uuid.uuid4())

            response = requests.get("https://api.tumblr.com/v2/user/info?force_oauth=false&private_blogs=true",
                                    headers=header, verify=False)

            if response.status_code == 200:
                self.log.info("{}:{} try to get info:successful".format(time.asctime(), account))

                response_dict = json.loads(response.text)

                g_participants = response_dict['response']['user']['crm_uuid']

                redis_num.set(account + ":uuid", g_participants)

        except Exception as e:

            print(e)

    def tumblr_login_by_email(self, account, password, redis_num, header, tumbler_base_java):

        self.log.info("{}:{} try to login".format(time.asctime(), account))

        handle_string = tumbler_base_java.tumbler_make_login(account, password)

        sig = tumbler_base_java.tumbler_sig(handle_string, "")

        oauth_nonce = str(tumbler_base_java.tumbler_oauth_nonce())

        header[
            'authorization'] = "OAuth oauth_consumer_key=\"BUHsuO5U9DF42uJtc8QTZlOmnUaJmBJGuU1efURxeklbdiLn9L\", " \
                               "oauth_nonce=\"" + oauth_nonce + "\", oauth_signature=\"" + sig + "\", " \
                                                                                                 "oauth_signature_method=\"HMAC-SHA1\", oauth_timestamp=\"" + str(
            tumbler_base_java.tumbler_timestamp()) + "\", oauth_version=\"1.0\" "

        header['x-identifier-date'] = str(int(time.time()))

        from_data = {"x_auth_username": account, "x_auth_password": password, 'x_auth_mode': 'client_auth'}

        response = requests.post("https://www.tumblr.com/oauth/access_token",
                                 headers=header,
                                 data=parse.urlencode(from_data), verify=False)

        if response.status_code == 200:
            self.log.info("{}:{} try to login:successful".format(time.asctime(), account))

            token_data = response.text.split("&")

            oauth_token = token_data[0].split("=")[1]

            oauth_token_secret = token_data[1].split("=")[1]

            redis_num.set(account + ":oauth_token", oauth_token)

            redis_num.set(account + ":oauth_token_secret", oauth_token_secret)


class WegamersLoginInfo:

    def __init__(self, we_game_socket):

        self.we_game_socket = we_game_socket

    def login_info(self, account, password):

        password_md5 = hashlib.md5(password.encode("utf-8")).hexdigest()

        login_in = "Login/;{}/;{}\n".format(account, password_md5).encode("utf-8")

        recv_login = self.we_game_socket.wegamer_conntion(message=login_in, state=False).decode("utf-8").strip(
            "\n")

        recv_login_text = json.loads(recv_login)

        print(recv_login_text)

        if int(recv_login_text["ret"]) == 0:

            return True

        else:

            return False

