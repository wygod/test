# -*-coding:utf-8-*-
import time
import json
import random
import requests

from beidouallocation.beidouallocation import BeiDouBase
from beidoudataclean.appdataclean import WegamersCleanData
from beidouallocation.beidouallocation import WegamerDispatch
from beidouconf.baseconf.beidouredisdb import account_login_db


class WegameSpider:

    def __init__(self, redisObject):

        # wegamer spider

        self.clean_data = WegamersCleanData()

        self.bei_dou_base = WegamerDispatch(redis_obj=redisObject)

        self.base_save = BeiDouBase(redisObject=redisObject)

        self.account_login = redisObject.redis_client(account_login_db)

    def game_url(self):

        # get game url

        skip_num = 0

        game_url = "https://api.community.wegamers.com/gameWebApi/web/game/gameList?lang=all&skip={}"

        game_header = {

            "Accept": "application/json, text/plain, */*",
            "Origin": "https://wegamers.com",
            "Referer": "https://wegamers.com/",
            "Sec-Fetch-Mode": "cors",
            "User-Agent": "Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/76.0.3809.132 Safari/537.36"

        }

        while True:

            time.sleep(random.randint(1, 2))

            game_list = requests.get(url=game_url.format(skip_num), headers=game_header, verify=False)

            game_context_list = json.loads(game_list.text)

            iter_page = int(game_context_list["obj"]["nextSkip"])

            if int(game_context_list["obj"]["count"]) == 0 or iter_page == skip_num:
                break

            game_data_init = self.clean_data.game_clean(game_context_list)
            # thread_pool, func, data, account, redis_conn

            self.bei_dou_base.get_user_(redis_conn=self.account_login,
                                        data=game_data_init,
                                        func=self.bei_dou_base.write_data,
                                        account="game_info")#thread_pool=self.thpool,

            skip_num = iter_page

    def get_text_id(self, game_id):

        # get game id

        headers = {
            "Host": "api.community.wegamers.com",
            "Connection": "keep-alive",
            "Accept": "application/json, text/plain, */*",
            "Origin": "https://wegamers.com",
            "User-Agent": "Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/76.0.3809.132 Safari/537.36",
            "Sec-Fetch-Mode": "cors",
            "Sec-Fetch-Site": "same-site",
            "Referer": "https://wegamers.com/",
            "Accept-Encoding": "gzip, deflate, br",
            "Accept-Language": "zh-CN,zh;q=0.9"
        }

        game_text_url = "https://api.community.wegamers.com/gameWebApi/web/game/game.json?id={}".format(game_id)

        abbreviate = requests.get(url=game_text_url, headers=headers, verify=False)

        result = json.loads(abbreviate.text)

        abb = result["name"]

        return game_id, abb

    def get_game_abb(self):

        game_result = []

        if not self.account_login.hgetall("game_info"):
            self.game_url()

        game_info = self.account_login.hgetall("game_info")

        num = 0

        for i_user, i_value in game_info.items():

            if num >100:

                break

            # time.sleep(1)

            try:

                game_result.append(self.get_text_id(i_user.decode("utf-8")))

                num = num + 1

            except Exception as e:

                print(e)

                pass
        self.bei_dou_base.get_user_(redis_conn=self.account_login,
                                    data=game_result,
                                    func=self.bei_dou_base.write_data,
                                    account="init_game")#thread_pool=self.thpool,
        # self.bei_dou_base.write_data(redis_conn=self.account_login,
        #                              data=game_result,
        #                              account="init_game")

    def get_user_text(self, func, get_id, redis_conn=None):

        # get user text

        header = {
            "Accept": "application/json, text/plain, */*",
            "Origin": "https://wegamers.com",
            "Referer": "https://wegamers.com/cq",
            "Sec-Fetch-Mode": "cors",
            "User-Agent": "Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/76.0.3809.132 Safari/537.36"
        }

        context_url = "http://api.community.wegamers.com/gameWebApi/sns/getCommunityContentList?" \
                      "gameid={}&gettype=3&category=0&sorttype=1&lang=lang_all&nextLang=&uin=10000&" \
                      "contentquerytype=1&customid=&skip={}&lastsequence={}"

        skip = 0

        last_sequence = 0

        while True:

            time.sleep(random.randint(1, 5))

            print(context_url.format(get_id, skip, last_sequence))

            user_text_data = requests.get(url=context_url.format(get_id, skip, last_sequence), headers=header,
                                          verify=False)

            context_detail = json.loads(user_text_data.text)

            print(context_detail)

            if "obj" not in context_detail.keys():
                break

            over_page = int(context_detail["obj"]["nextSkip"])

            if int(context_detail["obj"]["count"]) == 0 or skip == over_page:
                break

            user_data = self.clean_data.clean_book(context_detail)

            func(game_list_data=user_data,func=self.base_save.base_data_save_func)#thread_pool=self.thpool,

            skip = over_page

            last_sequence = context_detail["obj"]["nextSequence"]

    def get_fans_num(self, uin):

        fans_url = "http://api.community.wegamers.com/gameWebApi/web/users?uin={}&lang=zh_CN".format(uin)

        headers = {
            "Accept": "application/json, text/plain, */*",
            "Origin": "https://wegamers.com",
            "Sec-Fetch-Mode": "cors",
            "User-Agent": "Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/76.0.3809.132 Safari/537.36"
        }

        fans_num = requests.get(fans_url.format(uin), headers=headers, verify=False)

        fans_num_followed = json.loads(fans_num.text)

        fans_followed = fans_num_followed["obj"]["followingCount"]

        fans_following = fans_num_followed["obj"]["followedCount"]

        return fans_followed + fans_following

    def get_all_fans(self, func, get_id, redis_conn):

        # get use fans

        headers = {
            "Accept": "application/json, text/plain, */*",
            "Origin": "https://wegamers.com",
            "Sec-Fetch-Mode": "cors",
            "User-Agent": "Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/76.0.3809.132 Safari/537.36"
        }

        take = 20

        last_sequence = 0

        skip = 20

        for zero in [0, 1]:

            headers["Referer"] = "https://wegamers.com/attention/{}/{}".format(zero, get_id)

            fan_url = "https://api.community.wegamers.com/gameWebApi/web/followinigUsers?" \
                      "toUin={}&type={}&take={}&skip={}&lastsequence={}"
            while True:

                fans_text_data = requests.get(fan_url.format(get_id, zero, take, skip, last_sequence), headers=headers,
                                              verify=False)

                # <class 'dict'>: {'code': -1, 'msg': 'User not exist'}

                fans_context = json.loads(fans_text_data.text)

                if fans_context["code"] == -1:
                    redis_conn.hset("user_not_exist", get_id, "1")

                    break

                over_page = int(fans_context["obj"]["nextSkip"])

                if fans_context["obj"]["count"] == 0 or skip == over_page:
                    break

                fans_data = self.clean_data.clean_fnas(fans_context)

                func(game_list_data=fans_data,func=self.base_save.base_data_save_func)#thread_pool=self.thpool,

                skip = over_page
