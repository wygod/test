# -*-coding:utf-8-*-

import json
import time
import random
import requests
from requests.exceptions import SSLError, ProxyError

from beidoudataclean.appdataclean import AminoCleanData


class AminoSpider:

    # 爬虫及业务功能

    def __init__(self, ndcdeviceid, smdeviceid, user_agent, log):

        self.log = log

        self.smdeviceid = smdeviceid

        self.user_agent = user_agent

        self.ndcdeviceid = ndcdeviceid

        self.clean_data = AminoCleanData()

    def init_base_communities_class(self, func, redis_num, topic_name):

        # 获取amino初始社区主题信息

        self.log.info("{}:amino try init community_class".format(time.asctime()))

        if not redis_num.get("community_base_info"):

            init_url = "https://service.narvii.com/api/v1/g/s/persona/onboarding-interests?language=en&size=20&pagingType=t"

            init_header = {
                "NDCDEVICEID": self.ndcdeviceid,
                "SMDEVICEID": self.smdeviceid,
                "NDCLANG": "en",
                "Accept-Language": "zh-CN",
                "User-Agent": self.user_agent,
                "Connection": "Keep-Alive",
                "Accept-Encoding": "gzip"
            }

            data_list = requests.get(url=init_url, headers=init_header, verify=False)

            result_data = json.loads(data_list.text)

            if data_list.status_code == 200:
                # 清理数据
                result_clean_data = self.clean_data.clean_interest_id(data=result_data["sections"][0])
                # 保存数据
                func(game_list_data=result_clean_data, redis_num=redis_num, topic_name=topic_name)
                # 设置定期更新为7天

                redis_num.set("community_base_info", "1")

                redis_num.expire("community_base_info", 7 * 24 * 60 * 60)

                self.log.info("{}:amino init community_class successful".format(time.asctime()))

    def init_base_sub_topic(self, community_class, func, redis_num, topic_name):

        # 获取amino子主题

        self.log.info("{}:amino try to get topic".format(time.asctime()))

        if not redis_num.get("community_base_class:" + community_class):

            topic_url = "https://service.narvii.com/api/v1/g/s/interest/{}/topics?pagingType=t&size=25".format(
                community_class)

            topic_header = {
                "NDCDEVICEID": self.ndcdeviceid,
                "SMDEVICEID": self.smdeviceid,
                "NDCLANG": "en",
                "Accept-Language": "zh-CN",
                "User-Agent": self.user_agent,
                "Host": "service.narvii.com",
                "Connection": "Keep-Alive",
                "Accept-Encoding": "gzip"
            }

            topic_result = requests.get(url=topic_url, headers=topic_header, verify=False)

            if topic_result.status_code == 200:
                topic_context = json.loads(topic_result.text)

                # 获取子主题信息

                topic_data = self.clean_data.clean_topic(data=topic_context["topicList"])

                # 保存子主题信息

                func(game_list_data=topic_data, redis_num=redis_num, topic_name=topic_name)

                # 设置更新时间是7天

                redis_num.set("community_base_class:" + community_class, "1")

                redis_num.expire("community_base_class:" + community_class, 7 * 24 * 60 * 60)

                self.log.info("{}:amino finish to get topic".format(time.asctime()))

    def amino_park_url(self, topic_list, func, redis_num, topic_name):

        # 获取amino 主题链接
        self.log.info("{}:amino try to get themeParkUrl".format(time.asctime()))

        if not redis_num.get("park_url:{}".format(topic_list)):

            next_page = None

            size = 20

            amino_park_header = {
                "NDCDEVICEID": self.ndcdeviceid,
                "NDCLANG": "en",
                "Accept-Language": "zh-CN",
                "SMDEVICEID": self.smdeviceid,
                "User-Agent": self.user_agent,
                "Host": "service.narvii.com",
                "Connection": "Keep-Alive",
                "Accept-Encoding": "gzip"
            }

            while True:

                amino_base_url = "https://service.narvii.com/api/v1/g/s/topic/{}/feed/community?language=en&size={}&pagingType=t".format(
                    topic_list, size)

                if next_page:
                    amino_base_url = "https://service.narvii.com/api/v1/g/s/topic/{}/feed/community?language=en&size={}&pagingType=t&pageToken={}".format(
                        topic_list, size, next_page)

                try:

                    time.sleep(random.randint(1, 10) / 10)

                    amino_context = requests.get(url=amino_base_url, headers=amino_park_header, verify=False)

                    context = json.loads(amino_context.text)

                    amino_user_join_info = context["communityList"]

                    if len(amino_user_join_info) == 0:
                        self.log.info("{}:amino get {} successful".format(time.asctime(), topic_list))

                        break

                    # 获取theme_park

                    amino_result_url_list = self.clean_data.clean_theme_pack(data=amino_user_join_info)

                    # 保存theme_park

                    func(game_list_data=amino_result_url_list, redis_num=redis_num, topic_name=topic_name)

                    if "nextPageToken" not in context["paging"].keys():
                        break

                    next_page = context["paging"]["nextPageToken"]

                except ProxyError as e:

                    self.log.info("{}:amino get {},this is ProxyError".format(time.asctime(), topic_list))

            redis_num.set("park_url:{}".format(topic_list), "1")

            redis_num.expire("park_url:{}".format(topic_list), 7 * 24 * 60 * 60)

            self.log.info("{}:amino finish to get {} theme park".format(time.asctime(), topic_list))

    def join_amino_park(self, account, amino_community_join_id, redis_num):

        # 获取amino 主题链接
        self.log.info("{}:{} join {}".format(time.asctime(), account, amino_community_join_id))

        sid = redis_num.get(account + ":sid").decode("utf-8")

        amino_join_url = "https://service.narvii.com/api/v1/{}/s/community/join".format(amino_community_join_id)

        amino_join_header = {
            "NDCDEVICEID": self.ndcdeviceid,
            "NDCLANG": "en",
            "Accept-Language": "zh-CN",
            "SMDEVICEID": self.smdeviceid,
            "User-Agent": self.user_agent,
            "Host": "service.narvii.com",
            "Connection": "Keep-Alive",
            "Accept-Encoding": "gzip",
            "NDCAUTH": "sid={}".format(sid)
        }

        try:

            amino_join = requests.post(url=amino_join_url, headers=amino_join_header, verify=False)

            amino_result = json.loads(amino_join.text)

            if amino_result["api:statuscode"] == 0:

                # 获取amino 主题链接
                self.log.info("{} join {}:successful".format(account, amino_community_join_id))

                return True

            elif amino_result["api:statuscode"] == 826:

                # 获取amino 主题链接
                self.log.info("{} can't use".format(account))

                return None

            else:

                self.log.info("{}:{} join {}:fail".format(time.asctime(), account, amino_community_join_id))

                return False

        except Exception as e:

            self.log.info("{}:{} join {}:fail,because there is exception".format(time.asctime(), account,
                                                                                 amino_community_join_id))

            return False

    def amino_community_user(self, communty, auid, sid, func, redis_num):

        self.log.info(
            "{}:try to get {} user".format(time.asctime(), communty))

        members_num = 10000000

        members_page, space_num = redis_num.get(communty + ":init_page").decode("utf-8").split(":") if redis_num.get(
            communty + ":init_page") else ['0', '25']

        stop_time = None

        base_url = "https://service.narvii.com/api/v1/{}/s".format(communty)

        header = {
            "NDCLANG": "en",
            "AUID": auid,
            "NDCDEVICEID": self.ndcdeviceid,
            "SMDEVICEID": self.smdeviceid,
            "Accept-Language": "zh-CN",
            "User-Agent": self.user_agent,
            "Host": "service.narvii.com",
            "Connection": "Keep-Alive",
            "Accept-Encoding": "gzip",
            "NDCAUTH": "sid={}".format(sid)
        }

        flag = False

        while True:

            time.sleep(random.randint(1, 3))

            user_url = base_url + "/user-profile?type=summary&start={}&size={}".format(members_page, space_num)

            if stop_time:
                user_url = base_url + "/user-profile?type=recent&start={}&size={}&stoptime={}".format(members_page,
                                                                                                      space_num,
                                                                                                      stop_time)
            try:
                members_result = requests.get(url=user_url, headers=header, verify=False)

                members_json = json.loads(members_result.text)

                if "userProfileList" not in members_json.keys() or len(members_json["userProfileList"]) == 0:
                    break

                # 获取社区用户

                user_profile_list = members_json["userProfileList"]

                user_profile = self.clean_data.clean_uid(data=user_profile_list,
                                                         community_id=communty)
                # 保存用户
                func(game_list_data=user_profile)

                self.log.info("{}:get {} page {} user:finish".format(time.asctime(), communty, members_page))

                if members_num == 10000000:
                    members_num = members_json["userProfileCount"]

                stop_time = members_json["api:timestamp"].replace(":", "%3A")

                redis_num.set(communty + ":init_page", str(members_page) + ":" + str(space_num))

                members_page = int(members_page) + int(space_num)

            except ProxyError as e:

                print(e)

                self.log.info("{}:get {} :ProxyError".format(time.asctime(), communty))

                flag = True

                break

            except SSLError as e:

                self.log.info("{}:get {} : SSLError".format(time.asctime(), communty))

                flag = True

                break

        return flag

    def amino_follow_user(self,auid, community_id, uid, sid, func, redis_num):

        self.log.info(
            "{}:try to get {} follow user".format(time.asctime(), community_id))

        members_page, space_num = redis_num.get(community_id + "{}:init_page".format(uid)).decode("utf-8").split(
            ":") if redis_num.get(
            community_id + "{}:init_page".format(uid)) else ["0", "25"]

        stop_time = None

        amino_follow_user_header = {
            "NDCLANG": "en",
            "AUID": auid,
            "NDCDEVICEID": self.ndcdeviceid,
            "SMDEVICEID": self.smdeviceid,
            "Accept-Language": "zh-CN",
            "User-Agent": self.user_agent,
            "Host": "service.narvii.com",
            "Connection": "Keep-Alive",
            "Accept-Encoding": "gzip",
            "NDCAUTH": "sid={}".format(sid)
        }

        while True:

            amino_follow_user_url = "https://service.narvii.com/api/v1/{}/s/user-profile?type=recent&start={}&size={}".format(
                community_id, members_page, space_num)

            if stop_time:
                amino_follow_user_url = "https://service.narvii.com/api/v1/{}/s/user-profile?type=recent&start={}&size={}&stoptime={}".format(
                    community_id, members_page, space_num, stop_time)
            try:
                amino_user_data = requests.get(url=amino_follow_user_url, headers=amino_follow_user_header,
                                               verify=False)

                amino_clean_user_data = json.loads(amino_user_data.text)

                if len(amino_clean_user_data["userProfileList"]) == 0:
                    break

                amino_data = self.clean_data.clean_uid(data=amino_clean_user_data["userProfileList"],
                                                       community_id=community_id)

                # 保存用户的追随用户
                func(game_list_data=amino_data)

                self.log.info("{}:get {} page {} follow user:finish".format(time.asctime(), community_id, members_page))

                stop_time = amino_clean_user_data["api:timestamp"].replace(":", "%3A")

                redis_num.set(community_id + "{}:init_page".format(uid), str(members_page) + ":" + str(space_num))

                members_page = int(members_page) + int(space_num)

            except ProxyError as e:

                self.log.info("{}:get {} follow user:ProxyError".format(time.asctime(), community_id))

                break

            except SSLError as e:

                self.log.info("{}:get {} : SSLError".format(time.asctime(), community_id))

                break


if __name__ == "__main__":
    from beidoulogin.login import LoginInfo
    from beidouconf.baseconf.beidouredisconf import *
    from beidouloginstance.loginstance import BeibouLog
    from beidoudatastore.appredisdatastore import RedisObject
    from beidouconf.beidouaccount.accountpassword import amino_account_list
    from beidouconf.beidoudeviceconf.deviceconf import amino_ndcdeviceid_and_smdeviceid

    amino_down_test = BeibouLog().beidou_create_log("amino_spider_test")

    ndcdeviceid, smdeviceid, user_agent = random.choice(amino_ndcdeviceid_and_smdeviceid)

    amino = AminoSpider(ndcdeviceid, smdeviceid, user_agent, amino_down_test)

    login = LoginInfo(amino_down_test)

    redis_object = RedisObject(host=amino_spider_host, port=amino_spider_port, password=amino_spider_password)

    redis_num = redis_object.redis_client(1)

    account, password = amino_account_list[1]

    login.amino_login(amino_account=account,
                      amino_password=password,
                      amino_ndcdeviceid=ndcdeviceid,
                      amino_smdeviceid=smdeviceid,
                      amino_user_agent=user_agent,
                      amino_redis_num=redis_num)

    # amino.init_base_communities_class()
