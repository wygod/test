# -*-coding:utf-8-*-

import time
import json
import copy
import random
import requests

from beidoudataclean.appdataclean import MootCleanData
from beidouallocation.beidouallocation import BeiDouBase
from beidouconf.baseconf.beidoubaseversion import moot_web_js
from beidouotherscript.moot_script import MootOtherJScript, MootOtherJavaScript


class MootSpider:

    def __init__(self, log,
                 user_agent,
                 device_id,
                 redis_obj,
                 app_token_signature):

        self.log = log

        self.device_id = device_id

        self.user_agent = user_agent

        self.clean_data = MootCleanData()

        self.moot_jscript = MootOtherJScript()

        self.moot_java = MootOtherJavaScript()

        self.moot_dispatch = BeiDouBase(redis_obj)

        self.app_token_signature = app_token_signature

        self.base_header = {
            "deviceId": self.device_id,
            "DEVICE-TIME-ZONE-ID": "Asia/Shanghai",
            "country": "CN",
            "User-agent": self.user_agent,
            "version": "20140411",
            "DEVICE-TIME-ZONE-MS-OFFSET": "28800000",
            "language": "zh_CN",
            "Accept-Encoding": "gzip",
            "Host": "usw-api.moot.us",
            "Connection": "Keep-Alive"
        }

    def moot_token_time(self):

        header = {
            "Host": "moot.us",
            "Connection": "keep-alive",
            "Sec-Fetch-Mode": "cors",
            "User-Agent": "Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/76.0.3809.132 Safari/537.36",
            "Accept": "*/*",
            "Sec-Fetch-Site": "same-origin",
            "Referer": "https://moot.us/gameRatings/",
            "Accept-Encoding": "gzip, deflate, br",
            "Accept-Language": "zh-CN,zh;q=0.9"
        }

        data = requests.get("https://moot.us/", headers=header, verify=False)

        time_l = str(time.time() * 1000).split(".")[0]

        time_s = data.text.split("window.b_timegap = ")[1].split(" - new Date().getTime();")[0]

        time_t = int(time_s) - int(time_l)

        device_id = data.cookies["b_di"]

        return time_t, time_l, device_id

    def moot_spider_game(self, game_redis, game_name):

        b_tg, time_l, device_id = self.moot_token_time()

        get_signature = self.moot_jscript.moot_product_verify(moot_web_js, b_tg)

        game_header = {
            "Accept": "application/json",
            "Origin": "https://moot.us",
            "Referer": "https://moot.us/",
            "Sec-Fetch-Mode": "cors",
            "User-Agent": "Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) "
                          "Chrome/76.0.3809.132 Safari/537.36 "
        }

        game_no_url = "https://apis.naver.com/bang_api/bang_api/v1.2/lounges?gameCategoryNo=&_={}&" \
                      "signature={}%3D%3D&deviceId={}&country=US&language=zh-CN".format(time_l,
                                                                                        get_signature.replace("==", ""),
                                                                                        device_id)

        game_data = requests.get(url=game_no_url, headers=game_header, verify=False)

        game_data_json = json.loads(game_data.text)

        result = self.clean_data.game_clean_data(game_data_json)

        for i_game in result:

            game_redis.hset(game_name, i_game[0], i_game[1])

    def moot_game_something(self, game):

        header = copy.deepcopy(self.base_header)

        time.sleep(random.randint(1, 3))

        header["signature"] = self.app_token_signature.signature()

        more_user_url = "https://usw-api.moot.us/lounges/{}/leaderboard".format(game)

        get_user_list = requests.get(url=more_user_url, headers=header, verify=False)

        result = json.loads(get_user_list.text)

        game_init_list = self.clean_data.app_init_clean(result)

        self.moot_dispatch.base_multi_save_func(func=self.moot_dispatch.base_data_save_func,
                                                game_list_data=game_init_list)

    def moot_follower_user(self, user):

        followering = "https://usw-api.moot.us/users/{}/followings"

        follower = "https://usw-api.moot.us/users/{}/followers"

        follower_next = "https://usw-api.moot.us/users/{}/followers?navigationType=MORE&direction=BEFORE&limit={" \
                        "}&seq={} "

        followering_next = "https://usw-api.moot.us/users/{}/followings?navigationType=MORE&direction=BEFORE&limit={" \
                           "}&seq={} "

        self.log.info("{} is exec".format(user))

        follower_header = copy.deepcopy(self.base_header)

        flag_num = False

        for i_url in [(followering, followering_next), (follower, follower_next)]:

            seq = None

            limit = None

            while True:

                follower_header["signature"] = self.app_token_signature.signature()

                follow_user_url = i_url[0].format(user)

                if seq:

                    follow_user_url = i_url[1].format(user, limit, seq)

                try:

                    user_follower_data = requests.get(url=follow_user_url, headers=follower_header, verify=False)

                    user_follower = json.loads(user_follower_data.text)

                    if len(user_follower["data"]) == 0:
                        break

                    result_data = self.clean_data.app_follower_user(user_follower)

                    self.moot_dispatch.base_multi_save_func(func=self.moot_dispatch.base_data_save_func,
                                                            game_list_data=result_data)

                    seq = user_follower["paging"]["next"]["seq"]

                    limit = user_follower["paging"]["next"]["limit"]

                except Exception as e:

                    print(e)

                    self.log.info("{} happen except".format(user))

            flag_num = flag_num + 1

        self.log.info("{} is finish".format(user))

        return True if flag_num == 2 else False
