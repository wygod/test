# -*-coding:utf-8-*-

import time
import json
import copy
import random
import requests
from requests.exceptions import ProxyError, SSLError

from beidoudataclean.appdataclean import TumblrCleanData
from beidouconf.baseconf.beidouredisdb import account_login_db
from beidouallocation.beidouallocation import BeiDouBase


class TumblrSpider:

    def __init__(self, log, redis_obj):

        self.log = log

        self.redis_obj = redis_obj

        self.clean_data = TumblrCleanData()

        self.account_login = self.redis_obj.redis_client(account_login_db)

        self.tumblr_disptch = BeiDouBase(redisObject=self.redis_obj)

    def tumblr_init_data(self, items="trending"):

        # 初始化爬取的信息

        offset = 0

        page = 1

        limit = 20

        if self.account_login.hget(items, "page"):
            page = self.account_login.hget(items, "page").decode("utf-8")

        if self.account_login.hget(items, "offset"):
            offset = self.account_login.hget(items, "offset").decode("utf-8")

        self.log.info("{}:{} try to get info".format(time.asctime(), items))

        while True:

            if offset < 0:
                break

            try:

                spider_url = "https://www.tumblr.com/svc/discover/posts?offset={}&\
                askingForPage={}&limit={}&type={}&withFormKey=true".format(offset, page, limit, items)

                spider_header = {
                    "accept": "*/*",
                    "accept-encoding": "gzip, deflate",
                    "accept-language": "zh-CN,zh;q=0.9",
                    "referer": "https://www.tumblr.com/explore/{}".format(items),
                    "sec-fetch-mode": "cors",
                    "sec-fetch-site": "same-origin",
                    "user-agent": "Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) "
                                  "Chrome/76.0.3809.132 Safari/537.36",
                    "x-requested-with": "XMLHttpRequest"
                }

                data = requests.get(url=spider_url, headers=spider_header, verify=False)

                result = json.loads(data.text)

                if result["meta"]["status"] != 200 or len(result["response"]["DiscoveryPosts"]["posts"]) == 0:
                    break

                data_html = result["response"]["DiscoveryPosts"]["posts"]

                data_clean_blog = self.clean_data.clean_blog(data_html, items)

                self.tumblr_disptch.base_multi_save_func(func=self.tumblr_disptch.base_data_save_func,
                                                         game_list_data=data_clean_blog)

                self.log.info("{}:{} get {} page".format(time.asctime(), items, page))

                offset = result["response"]["DiscoveryPosts"]["nextOffset"]

                self.account_login.hset(items, "page", page)

                self.account_login.hset(items, "offset", offset)

                page = page + 1

            except ProxyError as e:

                print(e)

                self.log.info("{}:{} get {} page:ProxyError".format(time.asctime(), items, page))

                break

            except SSLError as e:

                self.log.info("{}:{} get {} page:SSLError".format(time.asctime(), items, page))

                break

    def spider_hot_user(self, name, product_id, items):

        hot_user_header = {
            "accept": "application/json, text/javascript, */*; q=0.01",
            "accept-encoding": "gzip, deflate",
            "accept-language": "zh-CN,zh;q=0.9",
            "referer": "https://www.tumblr.com/explore/{}".format(items),
            "sec-fetch-mode": "cors",
            "sec-fetch-site": "same-origin",
            "user-agent": "Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) "
                          "Chrome/76.0.3809.132 Safari/537.36",
            "x-requested-with": "XMLHttpRequest",
            "x-tumblr-form-key": "!1231578629431|2bPzQ1eIA5eD40HtanRItEKi5IE"
        }

        hot_user_url = "https://www.tumblr.com/svc/tumblelog/{}/{}/notes?mode=rollup".format(name, product_id)

        flag = False

        if self.account_login.hget(hash(name), "url"):
            hot_user_url = self.account_login.hget(hash(name), "url").decode("utf-8")

        self.log.info("{}:{} try to get {}:{}".format(time.asctime(), name, product_id, items))

        while True:

            try:

                hot_user_data = requests.get(url=hot_user_url, headers=hot_user_header, verify=False)

                result = json.loads(hot_user_data.text)

                if result["meta"]["status"] != 200 or (not "_links" in result["response"].keys()):
                    break

                data_html = result["response"]["notes"]

                data_clean_blog = self.clean_data.clean_hot_use(data_html)

                self.tumblr_disptch.base_multi_save_func(func=self.tumblr_disptch.base_data_save_func,
                                                         game_list_data=data_clean_blog)

                self.log.info("{}:{} try to get {}:{}:finish".format(time.asctime(), name, product_id, items))

                sub_url = result["response"]["_links"]["next"]["href"]

                hot_user_url = "https://www.tumblr.com" + sub_url

                self.account_login.hset(hash(name), "total_notes", result["response"]["total_notes"])

                self.account_login.hset(hash(name), "url", hot_user_url)

                flag = True

            except ProxyError as e:

                print(e)

                self.log.info("{}:{} get {} page :{}:ProxyError".format(time.asctime(), name, product_id, items))

                break

            except SSLError as e:

                print(e)

                self.log.info("{}:{} get {} page :{}:SSLError".format(time.asctime(), name, product_id, items))

                break

        return flag