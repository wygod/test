# -*-coding:utf-8-*-

import time
import json
import copy
import requests

from beidouconf.baseconf.beidouredisdb import url_filter_db
from beidoudataclean.appdataclean import IfunnyCleanData

from beidouallocation.beidouallocation import BeiDouBase


class IfunnySpider:

    def __init__(self, log, redis_obj, authorization, user_agent=None):

        self.log = log

        self.redis_obj = redis_obj

        self.clean_data = IfunnyCleanData()

        self.header = {
            "accept-language": "zh-CN",
            "applicationstate": "1",
            "accept": "application/json,image/webp,video/mp4",
            "ifunny-project-id": "iFunny",
            "accept-encoding": "gzip",
            "user-agent": user_agent
        }

        self.header["authorization"] = authorization

        self.spider_status = self.redis_obj.redis_client(url_filter_db)

        self.ifunny_dispatch = BeiDouBase(self.redis_obj)

    def init_data(self, func, user_agent):

        #爬取ifunny的基本游戏

        next_page = None

        self.log.info("{}:spider data".format(time.asctime()))

        header = copy.deepcopy(self.header)

        header["user-agent"] = user_agent

        flag = True

        while True:

            try:

                init_url = "https://api.ifunny.mobi/v4/feeds/featured?limit=30"

                if next_page:

                    init_url = init_url + "&next={}".format(next_page)

                result = requests.get(url=init_url, headers=header, verify=False)

                init_data = json.loads(result.text)

                if not init_data["data"]["content"]["paging"]["hasNext"]:

                    break

                self.log.info("{}:spider data {} page:successful".format(time.asctime(),next_page))

                sub_data = init_data["data"]["content"]

                next_page = init_data["data"]["content"]["paging"]["cursors"]["next"]

                if "items" in sub_data.keys():

                    init_result_data = self.clean_data.clean_data(sub_data)

                    func(game_list_data=init_result_data)

            except Exception as e:

                print(e)

                flag = False

        self.log.info("{}:spider data:successful".format(time.asctime()))

        return flag

    def init_spider_user(self, user_id, i_subscribers, header):

        flag = True

        next_page = None

        while True:

            try:

                init_user_url = "https://api.ifunny.mobi/v4/users/{}/{}?limit=30".format(user_id.decode("UTF-8"), i_subscribers)

                if next_page:
                    init_user_url = init_user_url + "&next={}".format(next_page)

                init_user_data = requests.get(url=init_user_url, headers=header, verify=False)

                init_result = json.loads(init_user_data.text)

                if not init_result["data"]["users"]["paging"]["hasNext"]:
                    break

                temp_sub_result = init_result["data"]["users"]

                self.log.info("{}:get {} {} {}:successful".format(time.asctime(), user_id, next_page, i_subscribers))

                init_clean_result = self.clean_data.clean_items_data(temp_sub_result)

                self.ifunny_dispatch.base_multi_save_func(func=self.ifunny_dispatch.base_data_save_func,
                                                          game_list_data=init_clean_result)

                next_page = init_result["data"]["users"]["paging"]["cursors"]["next"]

            except Exception as e:

                print(e)

                flag = False

        return flag

    def init_user(self, user_id, user_agent):

        #获取某一个user_id的追随者和粉丝

        subscribers_list = ["subscriptions","subscribers"]

        self.log.info("{}:get {} follower and following".format(time.asctime(), user_id))

        header = copy.deepcopy(self.header)

        header["user-agent"] = user_agent

        status = self.spider_status.get(user_id.decode("UTF-8")+":init_spider")

        status_code = status.decode("utf-8") if status else None

        if not status_code:

            for i_subscribers in subscribers_list:

                status_sub = self.spider_status.get(user_id.decode("UTF-8") + ":init_spider")

                try:

                    flag = self.init_spider_user(user_id=user_id, i_subscribers=i_subscribers, header=header)

                    if flag:

                        if not status_code:

                            self.spider_status.set(user_id.decode("UTF-8") + ":init_spider", i_subscribers)

                        else:
                            temp_str = status_sub + ":" + i_subscribers

                            self.spider_status.set(user_id.decode("UTF-8")+":init_spider",temp_str)

                        self.log.info("{}:get {} {}:successful".format(time.asctime(), user_id, i_subscribers))

                except Exception as e:

                    print(e)

        else:

            for i_subscribers in subscribers_list:

                if i_subscribers not in status_code:

                    try:

                        flag = self.init_spider_user(user_id=user_id, i_subscribers=i_subscribers, header=header)

                        if flag:

                            temp_str = status_code + ":" + i_subscribers

                            self.spider_status.set(user_id + ":init_spider", temp_str)

                            self.log.info("{}:get {} {}:successful".format(time.asctime(), user_id, i_subscribers))

                    except Exception as e:

                        print(e)