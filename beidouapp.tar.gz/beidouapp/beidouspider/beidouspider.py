# -*-coding:utf-8-*-

import time

from beidouconf.baseconf.beidouredisdb import *


class BeiDouSpider:

    def __init__(self, redisObject, log, app_name):

        self.log = log

        self.app_name = app_name

        self.data = redisObject.redis_client(data_db)

        self.uuid_data = redisObject.redis_client(uuid_data_db)

        self.uuid_member = redisObject.redis_client(uuid_db)

        self.account_login = redisObject.redis_client(account_login_db)

        self.account_uuid = redisObject.redis_client(account_assign_db)

        self.account_filter = redisObject.redis_client(crawled_data_db)

        self.account_uuid_filter = redisObject.redis_client(crawled_uuid_db)

    def beidou_spider_follow(self, account, func):

        first_temp_len = self.account_uuid_filter.get(account)

        temp_len = self.uuid_data.hlen(account)

        uuid_filter_len = first_temp_len.decode("utf-8") if first_temp_len else 0

        if uuid_filter_len < temp_len:

            temp_i = 0

            for (user_key_id, user_key_value) in self.uuid_data.hgetall(account).items():

                user_key_temp = user_key_id.decode("utf-8")

                if not self.account_filter.get(user_key_temp):
                    self.log.info(
                        "{}:{}:push:{}:try to start push ad to {}".format(time.asctime(),
                                                                          self.app_name,
                                                                          account,
                                                                          user_key_id))

                    func(user_key_id, user_key_value)

                    temp_i = temp_i + 1

                    user_time = time.strftime('%Y-%m-%d %H:%M:%S', time.localtime(time.time()))

                    self.account_filter.set(user_key_temp, user_time)

                    self.log.info("{}:{}:push:{}:try to start crawl {}".format(time.asctime(),
                                                                               self.app_name,
                                                                               account,
                                                                               user_key_id))

            if temp_len == temp_i and temp_len > 1900:
                self.account_uuid_filter.set(account, temp_i)

                self.log.info(
                    "{}:{}:push:{}:try to start push ad to {}".format(time.asctime(), self.app_name, account,
                                                                      account))

    def base_spider_user(self, account, func, use_uuid):

        if use_uuid:

            init_account_have_user = self.uuid_data.hgetall(account)

            if init_account_have_user:

                self.log.info("{}:{}:push:{}:try to start add friend".format(time.asctime(),
                                                                             self.app_name,
                                                                             account if account else ""))

                for user_id_keys, user_id_user in init_account_have_user.items():
                    self.beidou_spider_follow(account=account, uuid_keys=user_id_keys, func=func)

                self.log.info("{}:{}:push:{}:try to start add friend".format(time.asctime(),
                                                                             self.app_name,
                                                                             account if account else ""))
        else:

            init_account_have_user = self.account_uuid.hgetall(account)

            if init_account_have_user:

                self.log.info("{}:{}:push:{}:try to start push ad".format(time.asctime(),
                                                                          self.app_name,
                                                                          account))

                for user_id_keys in init_account_have_user:
                    self.beidou_spider_follow(account=account, uuid_keys=user_id_keys, func=func)

                self.log.info("{}:{}:push:{}:try to start push ad finish".format(time.asctime(),
                                                                                 self.app_name,
                                                                                 account))
